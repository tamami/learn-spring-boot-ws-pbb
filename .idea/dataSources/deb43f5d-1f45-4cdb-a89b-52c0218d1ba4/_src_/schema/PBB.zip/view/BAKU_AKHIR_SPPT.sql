create view BAKU_AKHIR_SPPT as
select thn_pajak_sppt, count(kd_propinsi) as "JML SPPT", sum(pbb_yg_harus_dibayar_sppt) as PBB
from sppt
group by thn_pajak_sppt
order by thn_pajak_sppt
