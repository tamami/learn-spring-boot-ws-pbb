create view DAFTAR_OBJEK_KHUSUS_YG_DIPISAH as
select kd_propinsi || kd_dati2 || kd_kecamatan || kd_kelurahan || 
  kd_blok || no_urut || kd_jns_op as nop, nm_wp_sppt, PBB_TERHUTANG_SPPT
from sppt_simulasi
where (nm_wp_sppt like '%XL AX%' or
  nm_wp_sppt like '%INDOSAT%' or
  nm_wp_sppt like '%TELKOMSEL%' or
  nm_wp_sppt like '%PT%KAI%' or
  nm_wp_sppt like '%PG%') AND
  THN_PAJAK_SPPT = '2014'
ORDER BY NOP
