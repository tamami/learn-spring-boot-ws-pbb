create view BAKU_AKHIR_PER_KELURAHAN as
select kd_kecamatan, kd_kelurahan, thn_pajak_sppt, count(kd_propinsi) as KETETAPAN, sum(pbb_yg_harus_dibayar_sppt) as pbb
from sppt
where (status_pembayaran_sppt='0' or status_pembayaran_sppt='1')
group by kd_kecamatan, kd_kelurahan, thn_pajak_sppt
order by kd_kecamatan, kd_kelurahan, thn_pajak_sppt
