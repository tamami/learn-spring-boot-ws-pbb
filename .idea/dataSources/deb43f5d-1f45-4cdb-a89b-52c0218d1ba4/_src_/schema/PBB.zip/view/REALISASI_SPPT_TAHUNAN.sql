create view REALISASI_SPPT_TAHUNAN as
select extract(year from tgl_pembayaran_sppt) as tahun, 
  sum(jml_sppt_yg_dibayar + denda_sppt) as nilai
from pembayaran_sppt
group by extract(year from tgl_pembayaran_sppt)
order by extract(year from tgl_pembayaran_sppt)
