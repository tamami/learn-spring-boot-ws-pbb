create view BAHAN_CETAK_MASSAL as
select objek.kd_kecamatan, objek.kd_kelurahan, kec.nm_kecamatan, 
  kel.nm_kelurahan, count(objek.kd_dati2) as jumlah_nop  
from dat_objek_pajak objek, ref_kecamatan kec, ref_kelurahan kel
where 
  objek.kd_kecamatan = kec.kd_kecamatan and
  objek.kd_kelurahan = kel.kd_kelurahan and
  kec.kd_kecamatan = kel.kd_kecamatan
group by objek.kd_kecamatan, objek.kd_kelurahan, kec.nm_kecamatan, 
  kel.nm_kelurahan
order by objek.kd_kecamatan, objek.kd_kelurahan
