create view UJI_PETIK as
select (kd_propinsi || '.' || kd_dati2 || '.' || kd_kecamatan || '.' ||
  kd_kelurahan || '.' || kd_blok || '-' || no_urut || '.' || kd_jns_op) as NOP,
  nm_wp_sppt, luas_bumi_sppt, luas_bng_sppt, 
  case luas_bumi_sppt when 0 then 0
  else (njop_bumi_sppt / luas_bumi_sppt) 
  end as NJOP_BUMI, 
  case luas_bng_sppt when 0 then 0
  else (njop_bng_sppt / luas_bng_sppt) end as NJOP_BNG, njop_sppt, 
  pbb_yg_harus_dibayar_sppt as PBB
from sppt
where thn_pajak_sppt = '2013' and
  (kd_kecamatan = '030' and 
    (kd_kelurahan = '001' and 
      (kd_blok = '001' and 
        (no_urut = '0002' or 
         no_urut = '0053' or
         no_urut = '0055' or 
         no_urut = '0119' or
         no_urut = '0125' or
         no_urut = '0132' or
         no_urut = '0138' or
         no_urut = '0141' or
         no_urut = '0151' or
         no_urut = '0152') or
       kd_blok = '002' and
        (no_urut = '0005' or
         no_urut = '0012' or
         no_urut = '0014' or
         no_urut = '0027' or 
         no_urut = '0038' or
         no_urut = '0042' or
         no_urut = '0050' or
         no_urut = '0056' or
         no_urut = '0080' or
         no_urut = '0086') or
       kd_blok = '003' and
        (no_urut = '0017' or
         no_urut = '0024' or
         no_urut = '0039' or
         no_urut = '0043' or
         no_urut = '0080' or 
         no_urut = '0081' or
         no_urut = '0099' or
         no_urut = '0105' or
         no_urut = '0112' or
         no_urut = '0121') or
       kd_blok = '004' and
        (no_urut = '0024' or
         no_urut = '0030' or
         no_urut = '0044' or
         no_urut = '0100' or
         no_urut = '0104' or
         no_urut = '0122' or
         no_urut = '0125' or
         no_urut = '0139' or
         no_urut = '0165' or
         no_urut = '0189') or
       kd_blok = '005' and 
        (no_urut = '0045' or
         no_urut = '0061' or
         no_urut = '0106' or
         no_urut = '0107' or
         no_urut = '0111' or
         no_urut = '0114' or
         no_urut = '0148' or
         no_urut = '0153' or
         no_urut = '0157' or
         no_urut = '0183') or
       kd_blok = '006' and
        (no_urut = '0011' or
         no_urut = '0042' or
         no_urut = '0142' or
         no_urut = '0181' or
         no_urut = '0202' or
         no_urut = '0203' or
         no_urut = '0228' or
         no_urut = '0241' or
         no_urut = '0251' or
         no_urut = '0253') or
       kd_blok = '007' and
        (no_urut = '0010' or
         no_urut = '0026' or
         no_urut = '0040' or
         no_urut = '0133' or
         no_urut = '0139' or
         no_urut = '0141' or
         no_urut = '0143' or
         no_urut = '0160' or
         no_urut = '0161' or
         no_urut = '0183') or
       kd_blok = '008' and
        (no_urut = '0024' or
         no_urut = '0053' or 
         no_urut = '0119' or
         no_urut = '0120' or
         no_urut = '0162' or
         no_urut = '0197' or
         no_urut = '0253' or
         no_urut = '0257' or
         no_urut = '0260' or
         no_urut = '0261') or
       kd_blok = '009' and
        (no_urut = '0004' or
         no_urut = '0044' or
         no_urut = '0045' or
         no_urut = '0062' or
         no_urut = '0079' or
         no_urut = '0083' or
         no_urut = '0102' or
         no_urut = '0111' or
         no_urut = '0116' or
         no_urut = '0130') or
       kd_blok = '010' and
        (no_urut = '0036' or
         no_urut = '0057' or
         no_urut = '0066' or
         no_urut = '0076' or
         no_urut = '0105' or
         no_urut = '0144' or
         no_urut = '0148' or
         no_urut = '0210' or
         no_urut = '0271' or
         no_urut = '0310') 
      )      
    )
  )
