create view REKAP_UBAH_SPPT_PER_TGL as
select tgl_terbit_sppt, kd_kecamatan, kd_kelurahan, count(kd_propinsi) SPPT, sum(pbb_yg_harus_dibayar_sppt) nilai
from sppt
group by tgl_terbit_sppt, kd_kecamatan, kd_kelurahan
order by tgl_terbit_sppt desc, kd_kecamatan asc, kd_kelurahan asc
