create view UPLOADER_BPD as
select '028' as kode, kd_propinsi||kd_dati2||kd_kecamatan||kd_kelurahan||kd_blok||no_urut||kd_jns_op as nop,
  thn_pajak_sppt, nm_wp_sppt, pbb_yg_harus_dibayar_sppt as pbb, 0 as denda, tgl_terbit_sppt, nip_pencetak_sppt
from sppt
where thn_pajak_sppt > '2014'
  and status_pembayaran_sppt not like '2'
  and pbb_yg_harus_dibayar_sppt > 0
order by thn_pajak_sppt, tgl_terbit_sppt, kd_kecamatan, kd_kelurahan, kd_blok, no_urut
