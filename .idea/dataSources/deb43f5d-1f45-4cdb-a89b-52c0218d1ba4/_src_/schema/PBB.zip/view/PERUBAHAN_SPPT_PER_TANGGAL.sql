create view PERUBAHAN_SPPT_PER_TANGGAL as
select tgl_terbit_sppt, thn_pajak_sppt, nip_pencetak_sppt, count(kd_propinsi) as "JML SPPT", sum(pbb_yg_harus_dibayar_sppt) as PBB
from sppt
group by tgl_terbit_sppt, thn_pajak_sppt, nip_pencetak_sppt
order by tgl_terbit_sppt desc, thn_pajak_sppt asc, nip_pencetak_sppt asc
