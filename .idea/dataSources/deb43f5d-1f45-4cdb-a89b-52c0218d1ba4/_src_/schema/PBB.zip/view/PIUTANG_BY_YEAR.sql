create view PIUTANG_BY_YEAR as
SELECT 
    thn_pajak_sppt            AS THN,
    COUNT(nm_wp_sppt)         AS JUMLAH_SPPT,
    SUM(pbb_yg_harus_dibayar_sppt) AS POKOK
  FROM sppt
  WHERE status_pembayaran_sppt = '0'
  GROUP BY THN_PAJAK_SPPT
  ORDER BY thn_pajak_sppt
