create view LAPORAN_KLASIFIKASI_NJOP as
select distinct op.kd_propinsi, op.kd_dati2, op.kd_kecamatan, op.kd_kelurahan, op.kd_blok, op.jalan_op, bumi.kd_znt, 
  kelas_tanah.kd_kls_tanah, 
  (kelas_tanah.nilai_min_tanah * 1000) as nilai_min,
  (kelas_tanah.nilai_max_tanah * 1000) as nilai_max,
  (nir.nir * 1000) as nir,
  kec.nm_kecamatan, kel.nm_kelurahan, 
  nir.thn_nir_znt
from dat_objek_pajak op, dat_op_bumi bumi, dat_nir nir, kelas_tanah, ref_kecamatan kec, ref_kelurahan kel  
where nir.thn_nir_znt = '2014'
  and op.kd_kecamatan = '010'
  and op.kd_kelurahan = '001'
  
  and op.kd_propinsi = bumi.kd_propinsi 
  and op.kd_dati2 = bumi.kd_dati2
  and op.kd_kecamatan = bumi.kd_kecamatan
  and op.kd_kelurahan = bumi.kd_kelurahan
  and op.kd_blok = bumi.kd_blok
  and op.no_urut = bumi.no_urut
  and op.kd_jns_op = bumi.kd_jns_op
  
  and op.kd_propinsi = nir.kd_propinsi
  and op.kd_dati2 = nir.kd_dati2
  and op.kd_kecamatan = nir.kd_kecamatan
  and op.kd_kelurahan = nir.kd_kelurahan
  and bumi.kd_propinsi = nir.kd_propinsi
  and bumi.kd_dati2 = nir.kd_dati2
  and bumi.kd_kecamatan = nir.kd_kecamatan
  and bumi.kd_kelurahan = nir.kd_kelurahan
  and bumi.kd_znt = nir.kd_znt
  
  and nir.thn_nir_znt >= kelas_tanah.thn_awal_kls_tanah
  and nir.thn_nir_znt <= kelas_tanah.thn_akhir_kls_tanah
  and nir.nir >= kelas_tanah.nilai_min_tanah
  and nir.nir <= kelas_tanah.nilai_max_tanah
  and kelas_tanah.kd_kls_tanah not in ('XXX','00')
  
  and op.kd_propinsi = kec.kd_propinsi
  and op.kd_dati2 = kec.kd_dati2
  and op.kd_kecamatan = kec.kd_kecamatan
  and bumi.kd_propinsi = kec.kd_propinsi
  and bumi.kd_dati2 = kec.kd_dati2
  and bumi.kd_kecamatan = kec.kd_kecamatan
  and nir.kd_propinsi = kec.kd_propinsi
  and nir.kd_dati2 = kec.kd_dati2 
  and nir.kd_kecamatan = kec.kd_kecamatan
  
  and op.kd_propinsi = kel.kd_propinsi
  and op.kd_dati2 = kel.kd_dati2
  and op.kd_kecamatan = kel.kd_kecamatan
  and op.kd_kelurahan = kel.kd_kelurahan
  and bumi.kd_propinsi = kel.kd_propinsi
  and bumi.kd_dati2 = kel.kd_dati2
  and bumi.kd_kecamatan = kel.kd_kecamatan
  and bumi.kd_kelurahan = kel.kd_kelurahan
  and nir.kd_propinsi = kel.kd_propinsi
  and nir.kd_dati2 = kel.kd_dati2
  and nir.kd_kecamatan = kel.kd_kecamatan
  and nir.kd_kelurahan = kel.kd_kelurahan
  and kec.kd_propinsi = kel.kd_propinsi
  and kec.kd_dati2 = kel.kd_dati2
  and kec.kd_kecamatan = kel.kd_kecamatan 
order by op.kd_blok, bumi.kd_znt
