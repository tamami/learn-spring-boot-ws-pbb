create view DATA_NJOP_BPK_ASK as
select ROWNUM nomor, 
  (sppt.kd_propinsi || '.' || sppt.kd_dati2 || '.' || sppt.kd_kecamatan || '.' || sppt.kd_kelurahan || '.' || 
  sppt.kd_blok || '-' || sppt.no_urut || '.' || sppt.kd_jns_op) as NOP, sppt.nm_wp_sppt, 
  (op.jalan_op || ' ' || op.blok_kav_no_op || ' RT ' || op.rt_op || ' RW ' || op.rw_op || ' ' || ref_kel.nm_kelurahan ||
  ' ' || ref_kec.nm_kecamatan || ' KAB. BREBES') as lokasi,
  sppt.luas_bumi_sppt, sppt.luas_bng_sppt, sppt.njop_bumi_sppt, sppt.njop_bng_sppt
from sppt, dat_objek_pajak op, ref_kecamatan ref_kec, ref_kelurahan ref_kel
where sppt.kd_propinsi = op.kd_propinsi
  and sppt.kd_dati2 = op.kd_dati2
  and sppt.kd_kecamatan = op.kd_kecamatan
  and sppt.kd_kelurahan = op.kd_kelurahan
  and sppt.kd_blok = op.kd_blok
  and sppt.no_urut = op.no_urut
  and sppt.kd_jns_op = op.kd_jns_op
  and sppt.kd_propinsi = ref_kec.kd_propinsi
  and sppt.kd_dati2 = ref_kec.kd_dati2
  and sppt.kd_kecamatan = ref_kec.kd_kecamatan
  and sppt.kd_propinsi = ref_kel.kd_propinsi
  and sppt.kd_dati2 = ref_kel.kd_dati2
  and sppt.kd_kecamatan = ref_kel.kd_kecamatan
  and sppt.kd_kelurahan = ref_kel.kd_kelurahan
  and sppt.thn_pajak_sppt = '2002'
