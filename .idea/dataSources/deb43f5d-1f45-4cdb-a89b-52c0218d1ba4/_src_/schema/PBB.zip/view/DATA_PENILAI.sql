create view DATA_PENILAI as
select sppt.kd_kecamatan||'.'||sppt.kd_kelurahan||'.'||sppt.kd_blok||'.'||sppt.no_urut||'.'||sppt.kd_jns_op as NOP, 
  sppt.nm_wp_sppt, sppt.jln_wp_sppt||' '||sppt.blok_kav_no_wp_sppt||' RT '||sppt.rt_wp_sppt||' RW '||sppt.rw_wp_sppt||' '||
  sppt.kelurahan_wp_sppt||' '||sppt.kota_wp_sppt as ALAMAT_WP, op.jalan_op||' '||op.blok_kav_no_op||' RT '||op.rt_op||' RW '||
  op.rw_op||' '||kel.nm_kelurahan||' '||kec.nm_kecamatan as ALAMAT_OP, sppt.luas_bumi_sppt, sppt.luas_bng_sppt,
  sppt.njop_bumi_sppt as NJOP_BUMI, sppt.njop_bng_sppt as NJOP_BNG
from sppt, dat_objek_pajak op, ref_kelurahan kel, ref_kecamatan kec
where sppt.thn_pajak_sppt='2014' and 
  sppt.kd_kecamatan = op.kd_kecamatan and
  sppt.kd_kelurahan = op.kd_kelurahan and
  sppt.kd_blok = op.kd_blok and
  sppt.no_urut = op.no_urut and
  sppt.kd_jns_op = op.kd_jns_op and
  sppt.kd_kecamatan = kel.kd_kecamatan and
  sppt.kd_kelurahan = kel.kd_kelurahan and
  sppt.kd_kecamatan = kec.kd_kecamatan and
  op.kd_kecamatan = kel.kd_kecamatan and
  op.kd_kelurahan = kel.kd_kelurahan and
  kel.kd_kecamatan = kec.kd_kecamatan
