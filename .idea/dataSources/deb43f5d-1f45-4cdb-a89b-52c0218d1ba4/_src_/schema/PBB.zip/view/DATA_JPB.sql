create view DATA_JPB as
SELECT a.kd_propinsi,
            a.kd_dati2,
            a.kd_kecamatan,
            a.kd_kelurahan,
            b.kd_jpb,
            COUNT (1) jumlah_op,
            SUM (a.total_luas_bumi) total_bumi,
            SUM (a.total_luas_bng) total_bng,
            SUM (a.njop_bumi) njop_bumi,
            SUM (a.njop_bng) njop_bng
       FROM pbb.dat_objek_pajak a, pbb.dat_op_bangunan b
      WHERE     a.kd_propinsi = b.kd_propinsi
            AND a.kd_dati2 = b.kd_dati2
            AND a.kd_kecamatan = b.kd_kecamatan
            AND a.kd_kelurahan = b.kd_kelurahan
            AND a.kd_blok = b.kd_blok
            AND a.no_urut = b.no_urut
            AND a.kd_jns_op = b.kd_jns_op
   GROUP BY a.kd_propinsi,
            a.kd_dati2,
            a.kd_kecamatan,
            a.kd_kelurahan,
            b.kd_jpb
   ORDER BY a.kd_propinsi,
            a.kd_dati2,
            a.kd_kecamatan,
            a.kd_kelurahan,
            b.kd_jpb

