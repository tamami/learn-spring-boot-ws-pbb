create view REF_WILAYAH as
SELECT b.kd_kanwil, b.kd_kppbb, a.kd_propinsi, a.kd_dati2, a.kd_kecamatan,
       a.kd_kelurahan, c.nm_kppbb, d.nm_kanwil, e.nm_propinsi, a.nm_kelurahan
  FROM pbb.ref_kelurahan a,
       pbb.ref_adm_kppbb b,
       pbb.ref_kppbb c,
       pbb.ref_kanwil d,
       pbb.ref_propinsi e,
       pbb.ref_dati2 f,
       pbb.ref_kecamatan g
 WHERE a.kd_propinsi = b.kd_propinsi
   AND a.kd_dati2 = b.kd_dati2
   AND b.kd_kanwil = c.kd_kanwil
   AND b.kd_kppbb = c.kd_kppbb
   AND b.kd_kanwil = d.kd_kanwil
   AND a.kd_propinsi = e.kd_propinsi
   AND a.kd_propinsi = f.kd_propinsi
   AND a.kd_dati2 = f.kd_dati2
   AND a.kd_propinsi = g.kd_propinsi
   AND a.kd_dati2 = g.kd_dati2
   AND a.kd_kecamatan = g.kd_kecamatan
