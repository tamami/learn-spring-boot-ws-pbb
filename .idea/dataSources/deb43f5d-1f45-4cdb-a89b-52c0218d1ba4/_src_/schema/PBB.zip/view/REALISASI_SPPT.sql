create view REALISASI_SPPT as
select tgl_pembayaran_sppt, 
  sum(case when denda_sppt is null then
    case when jml_sppt_yg_dibayar is null then 0 else
    jml_sppt_yg_dibayar end
  else jml_sppt_yg_dibayar + denda_sppt end) as jumlah_pembayaran
from pembayaran_sppt
where denda_sppt is not null and
  jml_sppt_yg_dibayar > 0
group by tgl_pembayaran_sppt
