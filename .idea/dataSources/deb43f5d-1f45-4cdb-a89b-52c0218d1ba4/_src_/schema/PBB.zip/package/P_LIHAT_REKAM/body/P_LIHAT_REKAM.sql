create package body p_lihat_rekam is

 procedure slct(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_lihat) is
  begin
   open p_lihat
   for
   SELECT nip_perekam_op AS nip, count(*) AS jml_spop,
       sum(total_luas_bumi) AS tot_ls_bumi, sum(total_luas_bng) AS tot_ls_bng
	   FROM dat_objek_pajak
	   WHERE tgl_perekaman_op BETWEEN p_tgl_awal AND p_tgl_akhir
	   GROUP BY nip_perekam_op;
  end;

 procedure slct_pendataan(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_lihat) is
  begin
   open p_lihat
   for
   SELECT nip_pendata AS nip, count(*) AS jml_spop,
       sum(total_luas_bumi) AS tot_ls_bumi, sum(total_luas_bng) AS tot_ls_bng
	   FROM dat_objek_pajak
	   WHERE tgl_pendataan_op BETWEEN to_date(to_char(p_tgl_awal, 'DD/MM/YYYY'), 'DD/MM/YYYY')
	   AND to_date(to_char(p_tgl_akhir, 'DD/MM/YYYY'), 'DD/MM/YYYY')
	   GROUP BY nip_pendata;
  end;

 procedure slct_stts(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_stts) is
  begin
   open p_lihat
   for
       select nip_rekam_byr_sppt as nip, count(*) as jml_stts,
       sum(jml_sppt_yg_dibayar) as tot_sppt_yg_dibayar
       from pembayaran_sppt
	   WHERE tgl_rekam_byr_sppt BETWEEN to_date(to_char(p_tgl_awal, 'DD/MM/YYYY'), 'DD/MM/YYYY')
	   AND to_date(to_char(p_tgl_akhir, 'DD/MM/YYYY'), 'DD/MM/YYYY')
       group by nip_rekam_byr_sppt;
   end;

 procedure slct_sppt(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_sppt) is
  begin
   open p_lihat
   for
       select nip_rekam_ttr_sppt as nip, count(*) as jml_sppt
       from ttr_sppt
	   WHERE tgl_rekam_ttr_sppt BETWEEN to_date(to_char(p_tgl_awal, 'DD/MM/YYYY'), 'DD/MM/YYYY')
	   AND to_date(to_char(p_tgl_akhir, 'DD/MM/YYYY'), 'DD/MM/YYYY')
       group by nip_rekam_ttr_sppt;
   end;

 procedure ins(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;
   procedure upd(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;
   procedure del(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;

   procedure lck(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;

end p_lihat_rekam;
