create package p_lihat_rekam AS
   type rec_lihat is record(
   nip dat_objek_pajak.nip_perekam_op%type,
   jumlah_op number(6),
   tot_luas_bumi dat_objek_pajak.total_luas_bumi%type,
   tot_luas_bng  dat_objek_pajak.total_luas_bng%type);

   type rec_rekam_stts is record(
   nip pegawai.nip%type,
   jml_stts number(10),
   jml_sppt_yg_dibayar pembayaran_sppt.jml_sppt_yg_dibayar%type);

   type rec_rekam_sppt is record(
   nip pegawai.nip%type,
   jml_sppt number(10));

   type rc_lihat is ref cursor
        return rec_lihat;
   type rc_stts is ref cursor
        return rec_rekam_stts;
   type rc_sppt is ref cursor
        return rec_rekam_sppt;

 type t_lihat is table of rec_lihat index by binary_integer;

 procedure slct(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_lihat);

 procedure ins(p_i_lihat IN OUT t_lihat);
 procedure upd(p_i_lihat IN OUT t_lihat);
 procedure del(p_i_lihat IN OUT t_lihat);
 procedure lck(p_i_lihat IN OUT t_lihat);

 procedure slct_pendataan(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_lihat);
 procedure slct_stts(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_stts);
 procedure slct_sppt(p_tgl_awal IN date, p_tgl_akhir IN date,
  p_lihat IN OUT rc_sppt);

 end;
