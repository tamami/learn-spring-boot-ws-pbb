create package p_pegawai AS
   type rec_pegawai is record(
   nip pegawai.nip%type,
   nm_pegawai pegawai.nm_pegawai%type);

   type rc_pegawai is ref cursor
        return rec_pegawai;

 procedure proc_pegawai(p_pegawai IN OUT rc_pegawai);

 end;
