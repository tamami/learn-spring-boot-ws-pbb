create package body p_pegawai is

 procedure proc_pegawai(p_pegawai IN OUT rc_pegawai) is
  begin
   open p_pegawai
   for
   SELECT nip, nm_pegawai
	   FROM pegawai;
  end;

end p_pegawai;
