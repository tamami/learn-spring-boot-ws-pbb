create package p_lihat_wilayah AS
   type rec_lihat is record(
   kode_wil varchar2(18),
   nama_kel varchar2(30),
   jml_op number);

   type rc_lihat is ref cursor
        return rec_lihat;

 type t_lihat is table of rec_lihat index by binary_integer;

 procedure slct(p_code IN number, p_lihat IN OUT rc_lihat);

 procedure ins(p_i_lihat IN OUT t_lihat);
 procedure upd(p_i_lihat IN OUT t_lihat);
 procedure del(p_i_lihat IN OUT t_lihat);
 procedure lck(p_i_lihat IN OUT t_lihat);

 end;
