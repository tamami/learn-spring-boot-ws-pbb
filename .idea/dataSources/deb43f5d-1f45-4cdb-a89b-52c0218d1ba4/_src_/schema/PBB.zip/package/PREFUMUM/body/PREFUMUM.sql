create PACKAGE BODY PREFUMUM is
  Function KOP1 RETURN VARCHAR2 IS
      VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=1;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function KOP2 RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=2;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function DASARSKETNJOP RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=3;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function PERDAPBB RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=4;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function PERWALBUPPBB RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=5;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function MENGINGATSKPENGURANGAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=6;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function TEMBUSANSK1 RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=7;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function TEMBUSANSK2 RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=8;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function TEMBUSANSK3 RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=9;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function TEMBUSANSK4 RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=10;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function PEJABATSKKEPDA RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=11;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function JNSSKKEPDA RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=12;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function MENGINGATSKKEBERATAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=13;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
  Function MENIMBANGSKKEBERATAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=14;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
 Function MENGINGATBETULSKKEBERATAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=15;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
 Function MENGINGATPEMBATALAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=16;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
Function MENGINGATPEMBETULAN RETURN VARCHAR2 IS
  VRETURN VARCHAR2(250);
      BEGIN
        select nm_ref into VRETURN from ref_umum where kd_ref=17;
        RETURN VRETURN;
      EXCEPTION WHEN OTHERS THEN RETURN '-';
      END;
end PREFUMUM; 