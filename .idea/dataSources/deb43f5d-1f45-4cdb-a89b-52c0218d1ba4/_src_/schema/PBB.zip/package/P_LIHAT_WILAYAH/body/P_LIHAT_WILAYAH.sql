create package body p_lihat_wilayah is

 procedure slct(p_code IN number, p_lihat IN OUT rc_lihat) is
  begin

   IF p_code = 0 THEN
   open p_lihat
   for
   SELECT 	 a.kd_propinsi||a.kd_dati2 as kd_dati2,
	b.nm_dati2 as nm_dati2,
	count(a.kd_dati2) as jml_op
	 from dat_objek_pajak a , ref_dati2 b
	 where a.kd_propinsi = b.kd_propinsi
	 and a.kd_dati2 = b.kd_dati2
	 group by a.kd_propinsi, a.kd_dati2, b.nm_dati2;
	elsif p_code = 1 THEN
     open p_lihat
      for
      SELECT 	 a.kd_propinsi||a.kd_dati2||a.kd_kecamatan as kd_dati2,
	  b.nm_kecamatan as nm_dati2,
	  count(a.kd_kecamatan) as jml_op
	  from dat_objek_pajak a , ref_kecamatan b
	  where a.kd_propinsi = b.kd_propinsi
	  and a.kd_dati2 = b.kd_dati2
	  and a.kd_kecamatan = b.kd_kecamatan
	  group by a.kd_propinsi, a.kd_dati2, a.kd_kecamatan, b.nm_kecamatan;
  	end if;
  end;

 procedure ins(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;
   procedure upd(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;
   procedure del(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;

   procedure lck(p_i_lihat IN OUT t_lihat) is
  begin
   null;
  end;

end p_lihat_wilayah;
