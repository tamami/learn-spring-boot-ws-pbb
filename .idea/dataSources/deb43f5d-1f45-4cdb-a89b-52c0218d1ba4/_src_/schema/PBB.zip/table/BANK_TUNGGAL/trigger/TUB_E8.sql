create trigger TUB_E8
	before update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL
	on BANK_TUNGGAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk1_bank_tunggal(var_kd_kanwil varchar,
                             var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KPPBB" must exist when updating a child in "BANK_TUNGGAL"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk1_bank_tunggal(:new.KD_KANWIL,
                               :new.KD_KPPBB);
       fetch cpk1_bank_tunggal into dummy;
       found := cpk1_bank_tunggal%FOUND;
       close cpk1_bank_tunggal;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "BANK_TUNGGAL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
