create trigger TUA_E8
	after update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL
	on BANK_TUNGGAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "BANK_TUNGGAL" for all children in "SKKPP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) then
       update SKKPP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL;
    end if;

    --  Modify parent code of "BANK_TUNGGAL" for all children in "BANK_PERSEPSI"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) then
       update BANK_PERSEPSI
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
