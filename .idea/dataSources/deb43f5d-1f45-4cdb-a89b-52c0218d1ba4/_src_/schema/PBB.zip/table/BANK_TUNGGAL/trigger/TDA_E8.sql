create trigger TDA_E8
	after delete
	on BANK_TUNGGAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SKKPP"
    delete SKKPP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL;

    --  Delete all children in "BANK_PERSEPSI"
    delete BANK_PERSEPSI
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
