create trigger TIA_SKP
	after insert
	on SKP
	for each row
begin
    BEGIN
        update  sppt
        set     status_tagihan_sppt = '2'
        where   kd_propinsi     = :new.KD_PROPINSI
          and   kd_dati2        = :new.KD_DATI2
          and   kd_kecamatan    = :new.KD_KECAMATAN
          and   kd_kelurahan    = :new.KD_KELURAHAN
          and   kd_blok         = :new.KD_BLOK
          and   no_urut         = :new.NO_URUT
          and   kd_jns_op       = :new.KD_JNS_OP
          and   thn_pajak_sppt  = :new.THN_PAJAK_SKP
          and   status_tagihan_sppt = '0';
    EXCEPTION
        WHEN OTHERS THEN NULL;
    END;
end;