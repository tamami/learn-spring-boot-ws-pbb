create trigger TUB_G1
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_SPPT,PEMBAYARAN_SPPT_KE,KD_KANWIL_BANK,KD_KPPBB_BANK,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI,KD_TP,NIP_REKAM_BYR_SPPT
	on PEMBAYARAN_SPPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "TEMPAT_PEMBAYARAN"
    cursor cpk1_pembayaran_sppt(var_kd_kanwil_bank varchar,
                                var_kd_kppbb_bank varchar,
                                var_kd_bank_tunggal varchar,
                                var_kd_bank_persepsi varchar,
                                var_kd_tp varchar) is
       select 1
       from   TEMPAT_PEMBAYARAN
       where  KD_KANWIL = var_kd_kanwil_bank
        and   KD_KPPBB = var_kd_kppbb_bank
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   KD_BANK_PERSEPSI = var_kd_bank_persepsi
        and   KD_TP = var_kd_tp
        and   var_kd_kanwil_bank is not null
        and   var_kd_kppbb_bank is not null
        and   var_kd_bank_tunggal is not null
        and   var_kd_bank_persepsi is not null
        and   var_kd_tp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "SPPT"
    cursor cpk2_pembayaran_sppt(var_kd_propinsi varchar,
                                var_kd_dati2 varchar,
                                var_kd_kecamatan varchar,
                                var_kd_kelurahan varchar,
                                var_kd_blok varchar,
                                var_no_urut varchar,
                                var_kd_jns_op varchar,
                                var_thn_pajak_sppt varchar) is
       select 1
       from   SPPT
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   THN_PAJAK_SPPT = var_thn_pajak_sppt
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_thn_pajak_sppt is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_pembayaran_sppt(var_nip_rekam_byr_sppt varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_byr_sppt
        and   var_nip_rekam_byr_sppt is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "TEMPAT_PEMBAYARAN" must exist when updating a child in "PEMBAYARAN_SPPT"
    if (:new.KD_KANWIL_BANK is not null) and
       (:new.KD_KPPBB_BANK is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and
       (:new.KD_BANK_PERSEPSI is not null) and
       (:new.KD_TP is not null) and (seq = 0) then
       open  cpk1_pembayaran_sppt(:new.KD_KANWIL_BANK,
                                  :new.KD_KPPBB_BANK,
                                  :new.KD_BANK_TUNGGAL,
                                  :new.KD_BANK_PERSEPSI,
                                  :new.KD_TP);
       fetch cpk1_pembayaran_sppt into dummy;
       found := cpk1_pembayaran_sppt%FOUND;
       close cpk1_pembayaran_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "TEMPAT_PEMBAYARAN". Cannot update child in "PEMBAYARAN_SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "SPPT" must exist when updating a child in "PEMBAYARAN_SPPT"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.THN_PAJAK_SPPT is not null) and (seq = 0) then
       open  cpk2_pembayaran_sppt(:new.KD_PROPINSI,
                                  :new.KD_DATI2,
                                  :new.KD_KECAMATAN,
                                  :new.KD_KELURAHAN,
                                  :new.KD_BLOK,
                                  :new.NO_URUT,
                                  :new.KD_JNS_OP,
                                  :new.THN_PAJAK_SPPT);
       fetch cpk2_pembayaran_sppt into dummy;
       found := cpk2_pembayaran_sppt%FOUND;
       close cpk2_pembayaran_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SPPT". Cannot update child in "PEMBAYARAN_SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PEMBAYARAN_SPPT"
    if (:new.NIP_REKAM_BYR_SPPT is not null) and (seq = 0) then
       open  cpk3_pembayaran_sppt(:new.NIP_REKAM_BYR_SPPT);
       fetch cpk3_pembayaran_sppt into dummy;
       found := cpk3_pembayaran_sppt%FOUND;
       close cpk3_pembayaran_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PEMBAYARAN_SPPT".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;