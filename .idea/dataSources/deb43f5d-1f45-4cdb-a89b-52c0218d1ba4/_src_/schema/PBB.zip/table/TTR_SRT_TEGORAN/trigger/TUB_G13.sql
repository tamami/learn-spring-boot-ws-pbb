create trigger TUB_G13
	before update of KD_KANWIL,KD_KPPBB,NO_SRT_TEGORAN,NIP_REKAM_TTR_SRT_TEGORAN
	on TTR_SRT_TEGORAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SRT_TEGORAN"
    cursor cpk1_ttr_srt_tegoran(var_kd_kanwil varchar,
                                var_kd_kppbb varchar,
                                var_no_srt_tegoran varchar) is
       select 1
       from   SRT_TEGORAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_SRT_TEGORAN = var_no_srt_tegoran
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_srt_tegoran is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_ttr_srt_tegoran(var_nip_rekam_ttr_srt_tegoran varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_ttr_srt_tegoran
        and   var_nip_rekam_ttr_srt_tegoran is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SRT_TEGORAN" must exist when updating a child in "TTR_SRT_TEGORAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_SRT_TEGORAN is not null) and (seq = 0) then
       open  cpk1_ttr_srt_tegoran(:new.KD_KANWIL,
                                  :new.KD_KPPBB,
                                  :new.NO_SRT_TEGORAN);
       fetch cpk1_ttr_srt_tegoran into dummy;
       found := cpk1_ttr_srt_tegoran%FOUND;
       close cpk1_ttr_srt_tegoran;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SRT_TEGORAN". Cannot update child in "TTR_SRT_TEGORAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "TTR_SRT_TEGORAN"
    if (:new.NIP_REKAM_TTR_SRT_TEGORAN is not null) and (seq = 0) then
       open  cpk2_ttr_srt_tegoran(:new.NIP_REKAM_TTR_SRT_TEGORAN);
       fetch cpk2_ttr_srt_tegoran into dummy;
       found := cpk2_ttr_srt_tegoran%FOUND;
       close cpk2_ttr_srt_tegoran;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "TTR_SRT_TEGORAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
