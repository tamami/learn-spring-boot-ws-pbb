create trigger OP_NOPETA
	before insert
	on DAT_OP_NOPETA
	for each row
declare
prop char(2);
dat  char(2);
kec  char(3);
kel  char(3);
blk  char(3);
urut char(4);
jns  char(1);
v_peta_induk number(1);
cursor c1 is select substr(nop,1,2),substr(nop,3,2),substr(nop,5,3),
  substr(nop,8,3),substr(nop,11,3),substr(nop,14,4),substr(nop,18,1)
  from dat_op_nopeta
  where substr(nop,1,10) = substr(:new.nop,1,10);
cursor c2 is select kd_propinsi,kd_dati2,kd_kecamatan,kd_kelurahan,
kd_blok,no_urut,kd_jns_op from dat_op_induk
where kd_propinsi  = substr(:new.nop,1,2) and
	  kd_dati2     = substr(:new.nop,3,2) and
	  kd_kecamatan = substr(:new.nop,5,3) and
	  kd_kelurahan = substr(:new.nop,8,3);
BEGIN
  if substr(:new.nop,11,8) = '00000000' then
    update dat_objek_pajak set status_peta_op = 1
	where
	  kd_propinsi  = substr(:new.nop,1,2) and
	  kd_dati2     = substr(:new.nop,3,2) and
	  kd_kecamatan = substr(:new.nop,5,3) and
	  kd_kelurahan = substr(:new.nop,8,3);
	open c1;
	loop
	fetch c1 into prop, dat, kec, kel, blk, urut, jns;
	exit when c1%notfound;
	begin
	  update dat_objek_pajak set status_peta_op =0
	  where
	    kd_propinsi  = prop and
	    kd_dati2     = dat and
	    kd_kecamatan = kec and
	    kd_kelurahan = kel and
		kd_blok      = blk and
		no_urut      = urut and
		kd_jns_op    = jns;
	  delete from dat_op_nopeta
	  where nop = prop||dat||kec||kel||blk||urut||jns;
	end;
	end loop;
	close c1;
	begin
	for r2 in c2 loop
	   select status_peta_op into v_peta_induk
	   from dat_objek_pajak
	   where kd_propinsi=r2.kd_propinsi and kd_dati2=r2.kd_dati2 and
	   kd_kecamatan=r2.kd_kecamatan and kd_kelurahan=r2.kd_kelurahan and
	   kd_blok=r2.kd_blok and no_urut=r2.no_urut and kd_jns_op=r2.kd_jns_op;
	   if v_peta_induk=0 then
	    begin
	    update dat_objek_pajak a set a.status_peta_op = 0
	    where exists (select * from dat_op_anggota b where
	      b.kd_propinsi_induk  = r2.kd_propinsi and
	      b.kd_dati2_induk     = r2.kd_dati2 and
	      b.kd_kecamatan_induk = r2.kd_kecamatan and
	      b.kd_kelurahan_induk = r2.kd_kelurahan and
		  b.kd_blok_induk      = r2.kd_blok and
		  b.no_urut_induk      = r2.no_urut and
		  b.kd_jns_op_induk    = r2.kd_jns_op and
		  a.kd_propinsi  = b.kd_propinsi and
	      a.kd_dati2     = b.kd_dati2 and
	      a.kd_kecamatan = b.kd_kecamatan and
	      a.kd_kelurahan = b.kd_kelurahan and
		  a.kd_blok      = b.kd_blok and
		  a.no_urut      = b.no_urut and
		  a.kd_jns_op    = b.kd_jns_op);
	  exception when others then null;
	  end;
	  end if;

	end loop;
	end;
  else
  begin
    delete from dat_op_nopeta
    where
	  NOP = substr(:new.nop,1,10)||'00000000';
  exception when others then null;
  end;
  end if;
END;
