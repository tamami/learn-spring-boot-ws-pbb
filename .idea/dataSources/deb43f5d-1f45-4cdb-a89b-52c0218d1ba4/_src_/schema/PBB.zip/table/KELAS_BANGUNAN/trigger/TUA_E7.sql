create trigger TUA_E7
	after update of KD_KLS_BNG,THN_AWAL_KLS_BNG
	on KELAS_BANGUNAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "TEMP_DATA_OP"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update TEMP_DATA_OP
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SPPT_OP_BERSAMA"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SPPT_OP_BERSAMA
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "KEPUTUSAN_KEBERATAN_PBB"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update KEPUTUSAN_KEBERATAN_PBB
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SKP_SPOP_OP_BERSAMA"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SKP_SPOP_OP_BERSAMA
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SKP_KB_OP_BERSAMA"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SKP_KB_OP_BERSAMA
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SPPT"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SPPT
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SKP_KURANG_BAYAR"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SKP_KURANG_BAYAR
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "SKP_SPOP"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update SKP_SPOP
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "PEMBETULAN_KEBERATAN"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update PEMBETULAN_KEBERATAN
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "HIS_SPPT"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update HIS_SPPT
        set   HIS_KD_KLS_BNG = :new.KD_KLS_BNG,
              HIS_THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
        and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "HIS_SKP_SPOP"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update HIS_SKP_SPOP
        set   HIS_KD_KLS_BNG = :new.KD_KLS_BNG,
              HIS_THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
        and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "HIS_SKP_KURANG_BAYAR"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update HIS_SKP_KURANG_BAYAR
        set   HIS_KD_KLS_BNG = :new.KD_KLS_BNG,
              HIS_THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
        and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;

    --  Modify parent code of "KELAS_BANGUNAN" for all children in "STA_NJOP_BNG"
    if (updating('KD_KLS_BNG') and :old.KD_KLS_BNG != :new.KD_KLS_BNG) or
       (updating('THN_AWAL_KLS_BNG') and :old.THN_AWAL_KLS_BNG != :new.THN_AWAL_KLS_BNG) then
       update STA_NJOP_BNG
        set   KD_KLS_BNG = :new.KD_KLS_BNG,
              THN_AWAL_KLS_BNG = :new.THN_AWAL_KLS_BNG
       where  KD_KLS_BNG = :old.KD_KLS_BNG
        and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
