create trigger TDA_E7
	after delete
	on KELAS_BANGUNAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TEMP_DATA_OP"
    delete TEMP_DATA_OP
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SPPT_OP_BERSAMA"
    delete SPPT_OP_BERSAMA
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "KEPUTUSAN_KEBERATAN_PBB"
    delete KEPUTUSAN_KEBERATAN_PBB
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SKP_SPOP_OP_BERSAMA"
    delete SKP_SPOP_OP_BERSAMA
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SKP_KB_OP_BERSAMA"
    delete SKP_KB_OP_BERSAMA
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SPPT"
    delete SPPT
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SKP_KURANG_BAYAR"
    delete SKP_KURANG_BAYAR
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "SKP_SPOP"
    delete SKP_SPOP
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "PEMBETULAN_KEBERATAN"
    delete PEMBETULAN_KEBERATAN
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "HIS_SPPT"
    delete HIS_SPPT
    where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
     and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "HIS_SKP_SPOP"
    delete HIS_SKP_SPOP
    where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
     and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "HIS_SKP_KURANG_BAYAR"
    delete HIS_SKP_KURANG_BAYAR
    where  HIS_KD_KLS_BNG = :old.KD_KLS_BNG
     and   HIS_THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;

    --  Delete all children in "STA_NJOP_BNG"
    delete STA_NJOP_BNG
    where  KD_KLS_BNG = :old.KD_KLS_BNG
     and   THN_AWAL_KLS_BNG = :old.THN_AWAL_KLS_BNG;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
