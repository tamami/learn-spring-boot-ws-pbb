create trigger TUB_J3
	before update of KD_KANWIL,KD_KPPBB,NO_SK_PEMBATALAN_SPMKP,NO_SPMKP,NIP_PENCETAK_PEMBATALAN_SPMKP
	on PEMBATALAN_SPMKP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SPMKP"
    cursor cpk1_pembatalan_spmkp(var_kd_kanwil varchar,
                                 var_kd_kppbb varchar,
                                 var_no_spmkp varchar) is
       select 1
       from   SPMKP
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_SPMKP = var_no_spmkp
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_spmkp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk2_pembatalan_spmkp(var_kd_kanwil varchar,
                                 var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_pembatalan_spmkp(var_nip_pencetak_pembatalan_sp varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_pembatalan_sp
        and   var_nip_pencetak_pembatalan_sp is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SPMKP" must exist when updating a child in "PEMBATALAN_SPMKP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_SPMKP is not null) and (seq = 0) then
       open  cpk1_pembatalan_spmkp(:new.KD_KANWIL,
                                   :new.KD_KPPBB,
                                   :new.NO_SPMKP);
       fetch cpk1_pembatalan_spmkp into dummy;
       found := cpk1_pembatalan_spmkp%FOUND;
       close cpk1_pembatalan_spmkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SPMKP". Cannot update child in "PEMBATALAN_SPMKP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_KPPBB" must exist when updating a child in "PEMBATALAN_SPMKP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk2_pembatalan_spmkp(:new.KD_KANWIL,
                                   :new.KD_KPPBB);
       fetch cpk2_pembatalan_spmkp into dummy;
       found := cpk2_pembatalan_spmkp%FOUND;
       close cpk2_pembatalan_spmkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "PEMBATALAN_SPMKP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PEMBATALAN_SPMKP"
    if (:new.NIP_PENCETAK_PEMBATALAN_SPMKP is not null) and (seq = 0) then
       open  cpk3_pembatalan_spmkp(:new.NIP_PENCETAK_PEMBATALAN_SPMKP);
       fetch cpk3_pembatalan_spmkp into dummy;
       found := cpk3_pembatalan_spmkp%FOUND;
       close cpk3_pembatalan_spmkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PEMBATALAN_SPMKP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
