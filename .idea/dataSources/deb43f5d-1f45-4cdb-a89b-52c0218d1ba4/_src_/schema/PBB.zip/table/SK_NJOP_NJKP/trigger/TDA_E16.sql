create trigger TDA_E16
	after delete
	on SK_NJOP_NJKP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "REF_THN_NJKP_NJOPTKP_TARIF"
    delete REF_THN_NJKP_NJOPTKP_TARIF
    where  KD_SK_NJOP_NJKP = :old.KD_SK_NJOP_NJKP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
