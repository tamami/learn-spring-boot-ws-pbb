create trigger TUA_E16
	after update of KD_SK_NJOP_NJKP
	on SK_NJOP_NJKP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SK_NJOP_NJKP" for all children in "REF_THN_NJKP_NJOPTKP_TARIF"
    if (updating('KD_SK_NJOP_NJKP') and :old.KD_SK_NJOP_NJKP != :new.KD_SK_NJOP_NJKP) then
       update REF_THN_NJKP_NJOPTKP_TARIF
        set   KD_SK_NJOP_NJKP = :new.KD_SK_NJOP_NJKP
       where  KD_SK_NJOP_NJKP = :old.KD_SK_NJOP_NJKP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
