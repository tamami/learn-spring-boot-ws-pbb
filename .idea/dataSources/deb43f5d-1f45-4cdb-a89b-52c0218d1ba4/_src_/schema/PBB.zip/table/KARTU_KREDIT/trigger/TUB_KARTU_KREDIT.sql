create trigger TUB_KARTU_KREDIT
	before update of NO_KARTU,NO_PENDUDUK
	on KARTU_KREDIT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENDUDUK"
    cursor cpk1_kartu_kredit(var_no_penduduk varchar) is
       select 1
       from   PENDUDUK
       where  NO_PENDUDUK = var_no_penduduk
        and   var_no_penduduk is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PENDUDUK" must exist when updating a child in "KARTU_KREDIT"
    if (:new.NO_PENDUDUK is not null) and (seq = 0) then
       open  cpk1_kartu_kredit(:new.NO_PENDUDUK);
       fetch cpk1_kartu_kredit into dummy;
       found := cpk1_kartu_kredit%FOUND;
       close cpk1_kartu_kredit;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENDUDUK". Cannot update child in "KARTU_KREDIT".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
