create trigger TUB_E20
	before update of INDEKS_RANGE,KD_JNS_RANGE,KD_SK_NJOP_NJKP
	on REF_THN_NJKP_NJOPTKP_TARIF
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SK_NJOP_NJKP"
    cursor cpk1_ref_thn_njkp_njoptkp_tari(var_kd_sk_njop_njkp number) is
       select 1
       from   SK_NJOP_NJKP
       where  KD_SK_NJOP_NJKP = var_kd_sk_njop_njkp
        and   var_kd_sk_njop_njkp is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SK_NJOP_NJKP" must exist when updating a child in "REF_THN_NJKP_NJOPTKP_TARIF"
    if (:new.KD_SK_NJOP_NJKP is not null) and (seq = 0) then
       open  cpk1_ref_thn_njkp_njoptkp_tari(:new.KD_SK_NJOP_NJKP);
       fetch cpk1_ref_thn_njkp_njoptkp_tari into dummy;
       found := cpk1_ref_thn_njkp_njoptkp_tari%FOUND;
       close cpk1_ref_thn_njkp_njoptkp_tari;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SK_NJOP_NJKP". Cannot update child in "REF_THN_NJKP_NJOPTKP_TARIF".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
