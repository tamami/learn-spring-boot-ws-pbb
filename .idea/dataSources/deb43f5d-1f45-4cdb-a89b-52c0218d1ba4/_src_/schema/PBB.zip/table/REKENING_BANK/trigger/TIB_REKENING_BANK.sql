create trigger TIB_REKENING_BANK
	before insert
	on REKENING_BANK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "PENDUDUK"
    cursor cpk1_rekening_bank(var_no_penduduk varchar) is
       select 1
       from   PENDUDUK
       where  NO_PENDUDUK = var_no_penduduk
        and   var_no_penduduk is not null;

begin

    --  Parent "PENDUDUK" must exist when inserting a child in "REKENING_BANK"
    if :new.NO_PENDUDUK is not null then
       open  cpk1_rekening_bank(:new.NO_PENDUDUK);
       fetch cpk1_rekening_bank into dummy;
       found := cpk1_rekening_bank%FOUND;
       close cpk1_rekening_bank;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PENDUDUK". Cannot create child in "REKENING_BANK".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
