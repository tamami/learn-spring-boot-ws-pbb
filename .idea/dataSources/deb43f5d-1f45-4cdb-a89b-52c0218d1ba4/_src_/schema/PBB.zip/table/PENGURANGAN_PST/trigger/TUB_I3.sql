create trigger TUB_I3
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,JNS_SK,NO_SK
	on PENGURANGAN_PST
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_PERMOHONAN_PENGURANGAN"
    cursor cpk1_pengurangan_pst(var_kd_kanwil varchar,
                                var_kd_kppbb varchar,
                                var_thn_pelayanan varchar,
                                var_bundel_pelayanan varchar,
                                var_no_urut_pelayanan varchar,
                                var_kd_propinsi_pemohon varchar,
                                var_kd_dati2_pemohon varchar,
                                var_kd_kecamatan_pemohon varchar,
                                var_kd_kelurahan_pemohon varchar,
                                var_kd_blok_pemohon varchar,
                                var_no_urut_pemohon varchar,
                                var_kd_jns_op_pemohon varchar) is
       select 1
       from   PST_PERMOHONAN_PENGURANGAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "SK_SK"
    cursor cpk2_pengurangan_pst(var_kd_kanwil varchar,
                                var_kd_kppbb varchar,
                                var_jns_sk varchar,
                                var_no_sk varchar) is
       select 1
       from   SK_SK
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   JNS_SK = var_jns_sk
        and   NO_SK = var_no_sk
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_jns_sk is not null
        and   var_no_sk is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PST_PERMOHONAN_PENGURANGAN" must exist when updating a child in "PENGURANGAN_PST"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk1_pengurangan_pst(:new.KD_KANWIL,
                                  :new.KD_KPPBB,
                                  :new.THN_PELAYANAN,
                                  :new.BUNDEL_PELAYANAN,
                                  :new.NO_URUT_PELAYANAN,
                                  :new.KD_PROPINSI_PEMOHON,
                                  :new.KD_DATI2_PEMOHON,
                                  :new.KD_KECAMATAN_PEMOHON,
                                  :new.KD_KELURAHAN_PEMOHON,
                                  :new.KD_BLOK_PEMOHON,
                                  :new.NO_URUT_PEMOHON,
                                  :new.KD_JNS_OP_PEMOHON);
       fetch cpk1_pengurangan_pst into dummy;
       found := cpk1_pengurangan_pst%FOUND;
       close cpk1_pengurangan_pst;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_PERMOHONAN_PENGURANGAN". Cannot update child in "PENGURANGAN_PST".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "SK_SK" must exist when updating a child in "PENGURANGAN_PST"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.JNS_SK is not null) and
       (:new.NO_SK is not null) and (seq = 0) then
       open  cpk2_pengurangan_pst(:new.KD_KANWIL,
                                  :new.KD_KPPBB,
                                  :new.JNS_SK,
                                  :new.NO_SK);
       fetch cpk2_pengurangan_pst into dummy;
       found := cpk2_pengurangan_pst%FOUND;
       close cpk2_pengurangan_pst;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SK_SK". Cannot update child in "PENGURANGAN_PST".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
