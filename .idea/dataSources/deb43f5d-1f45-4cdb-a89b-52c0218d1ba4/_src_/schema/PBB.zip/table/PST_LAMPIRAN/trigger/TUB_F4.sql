create trigger TUB_F4
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN
	on PST_LAMPIRAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_PERMOHONAN"
    cursor cpk1_pst_lampiran(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_thn_pelayanan varchar,
                             var_bundel_pelayanan varchar,
                             var_no_urut_pelayanan varchar) is
       select 1
       from   PST_PERMOHONAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PST_PERMOHONAN" must exist when updating a child in "PST_LAMPIRAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and (seq = 0) then
       open  cpk1_pst_lampiran(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.THN_PELAYANAN,
                               :new.BUNDEL_PELAYANAN,
                               :new.NO_URUT_PELAYANAN);
       fetch cpk1_pst_lampiran into dummy;
       found := cpk1_pst_lampiran%FOUND;
       close cpk1_pst_lampiran;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_PERMOHONAN". Cannot update child in "PST_LAMPIRAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
