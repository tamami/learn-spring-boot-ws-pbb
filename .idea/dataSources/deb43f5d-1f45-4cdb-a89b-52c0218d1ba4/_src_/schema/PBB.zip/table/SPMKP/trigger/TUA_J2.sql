create trigger TUA_J2
	after update of KD_KANWIL,KD_KPPBB,NO_SPMKP,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,NIP_REKAM_SPMKP
	on SPMKP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SPMKP" for all children in "PEMBATALAN_SPMKP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SPMKP') and :old.NO_SPMKP != :new.NO_SPMKP) then
       update PEMBATALAN_SPMKP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SPMKP = :new.NO_SPMKP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SPMKP = :old.NO_SPMKP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
