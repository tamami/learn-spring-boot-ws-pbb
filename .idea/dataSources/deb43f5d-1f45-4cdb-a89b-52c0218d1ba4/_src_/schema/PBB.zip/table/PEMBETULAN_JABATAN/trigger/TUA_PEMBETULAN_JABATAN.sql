create trigger TUA_PEMBETULAN_JABATAN
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP
	on PEMBETULAN_JABATAN
	for each row
DECLARE
   integrity_error   EXCEPTION;
   errno             INTEGER;
   errmsg            CHAR (200);
   dummy             INTEGER;
   FOUND             BOOLEAN;
BEGIN
   integritypackage.nextnestlevel;

   --  Modify parent code of "PEMBETULAN_jabatan" for all children in "RINCIAN_PEMBETULAN_jabatan"
   IF     (    UPDATING ('KD_PROPINSI ')
          AND :OLD.kd_propinsi  != :NEW.kd_propinsi
         )
      OR (    UPDATING ('KD_DATI2 ')
          AND :OLD.kd_dati2  != :NEW.kd_dati2
         )
      OR (    UPDATING ('KD_KECAMATAN ')
          AND :OLD.kd_kecamatan  != :NEW.kd_kecamatan
         )
      OR (    UPDATING ('KD_KELURAHAN ')
          AND :OLD.kd_kelurahan  != :NEW.kd_kelurahan
         )
      OR (    UPDATING ('KD_BLOK ')
          AND :OLD.kd_blok  != :NEW.kd_blok
         )
      OR (    UPDATING ('NO_URUT ')
          AND :OLD.no_urut  != :NEW.no_urut
         )
      OR (    UPDATING ('KD_JNS_OP ')
          AND :OLD.kd_jns_op  != :NEW.kd_jns_op
         )
   THEN
      UPDATE rincian_pembetulan_jabatan
         SET
             kd_propinsi  = :NEW.kd_propinsi ,
             kd_dati2  = :NEW.kd_dati2 ,
             kd_kecamatan  = :NEW.kd_kecamatan ,
             kd_kelurahan  = :NEW.kd_kelurahan ,
             kd_blok  = :NEW.kd_blok ,
             no_urut  = :NEW.no_urut ,
             kd_jns_op  = :NEW.kd_jns_op
       WHERE
          kd_propinsi  = :OLD.kd_propinsi
         AND kd_dati2  = :OLD.kd_dati2
         AND kd_kecamatan  = :OLD.kd_kecamatan
         AND kd_kelurahan  = :OLD.kd_kelurahan
         AND kd_blok  = :OLD.kd_blok
         AND no_urut  = :OLD.no_urut
         AND kd_jns_op  = :OLD.kd_jns_op ;
   END IF;

   integritypackage.previousnestlevel;
--  Errors handling
EXCEPTION
   WHEN integrity_error
   THEN
      BEGIN
         integritypackage.initnestlevel;
         raise_application_error (errno, errmsg);
      END;
END;
