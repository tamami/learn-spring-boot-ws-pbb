create trigger TDA_PEMBETULAN_JABATAN
	after delete
	on PEMBETULAN_JABATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;


    --  Delete all children in "RINCIAN_PEMBETULAN_jabatan"
    delete RINCIAN_PEMBETULAN_jabatan
    where    KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   THN_PEMBETULAN=:old.THN_PEMBETULAN and
     PEMBETULAN_KE=:old.PEMBETULAN_KE;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
END tda_pembetulan;
