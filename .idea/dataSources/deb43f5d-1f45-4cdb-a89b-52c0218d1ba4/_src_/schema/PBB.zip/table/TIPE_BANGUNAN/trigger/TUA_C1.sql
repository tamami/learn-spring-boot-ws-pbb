create trigger TUA_C1
	after update of TIPE_BNG
	on TIPE_BANGUNAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "TIPE_BANGUNAN" for all children in "BANGUNAN_LANTAI"
    if (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) then
       update BANGUNAN_LANTAI
        set   TIPE_BNG = :new.TIPE_BNG
       where  TIPE_BNG = :old.TIPE_BNG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
