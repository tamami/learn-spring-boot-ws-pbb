create trigger TUB_D7
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,SUBJEK_PAJAK_ID,NIP_PENDATA,NIP_PEMERIKSA_OP,NIP_PEREKAM_OP
	on DAT_OBJEK_PAJAK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_SUBJEK_PAJAK"
    cursor cpk1_dat_objek_pajak(var_subjek_pajak_id varchar) is
       select 1
       from   DAT_SUBJEK_PAJAK
       where  SUBJEK_PAJAK_ID = var_subjek_pajak_id
        and   var_subjek_pajak_id is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_PETA_BLOK"
    cursor cpk2_dat_objek_pajak(var_kd_propinsi varchar,
                                var_kd_dati2 varchar,
                                var_kd_kecamatan varchar,
                                var_kd_kelurahan varchar,
                                var_kd_blok varchar) is
       select 1
       from   DAT_PETA_BLOK
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_dat_objek_pajak(var_nip_pemeriksa_op varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pemeriksa_op
        and   var_nip_pemeriksa_op is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk4_dat_objek_pajak(var_nip_pendata varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pendata
        and   var_nip_pendata is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk5_dat_objek_pajak(var_nip_perekam_op varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam_op
        and   var_nip_perekam_op is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "DAT_SUBJEK_PAJAK" must exist when updating a child in "DAT_OBJEK_PAJAK"
    if (:new.SUBJEK_PAJAK_ID is not null) and (seq = 0) then
       open  cpk1_dat_objek_pajak(:new.SUBJEK_PAJAK_ID);
       fetch cpk1_dat_objek_pajak into dummy;
       found := cpk1_dat_objek_pajak%FOUND;
       close cpk1_dat_objek_pajak;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_SUBJEK_PAJAK". Cannot update child in "DAT_OBJEK_PAJAK".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_PETA_BLOK" must exist when updating a child in "DAT_OBJEK_PAJAK"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and (seq = 0) then
       open  cpk2_dat_objek_pajak(:new.KD_PROPINSI,
                                  :new.KD_DATI2,
                                  :new.KD_KECAMATAN,
                                  :new.KD_KELURAHAN,
                                  :new.KD_BLOK);
       fetch cpk2_dat_objek_pajak into dummy;
       found := cpk2_dat_objek_pajak%FOUND;
       close cpk2_dat_objek_pajak;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_PETA_BLOK". Cannot update child in "DAT_OBJEK_PAJAK".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DAT_OBJEK_PAJAK"
    if (:new.NIP_PEMERIKSA_OP is not null) and (seq = 0) then
       open  cpk3_dat_objek_pajak(:new.NIP_PEMERIKSA_OP);
       fetch cpk3_dat_objek_pajak into dummy;
       found := cpk3_dat_objek_pajak%FOUND;
       close cpk3_dat_objek_pajak;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DAT_OBJEK_PAJAK".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DAT_OBJEK_PAJAK"
    if (:new.NIP_PENDATA is not null) and (seq = 0) then
       open  cpk4_dat_objek_pajak(:new.NIP_PENDATA);
       fetch cpk4_dat_objek_pajak into dummy;
       found := cpk4_dat_objek_pajak%FOUND;
       close cpk4_dat_objek_pajak;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DAT_OBJEK_PAJAK".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DAT_OBJEK_PAJAK"
    if (:new.NIP_PEREKAM_OP is not null) and (seq = 0) then
       open  cpk5_dat_objek_pajak(:new.NIP_PEREKAM_OP);
       fetch cpk5_dat_objek_pajak into dummy;
       found := cpk5_dat_objek_pajak%FOUND;
       close cpk5_dat_objek_pajak;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DAT_OBJEK_PAJAK".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
