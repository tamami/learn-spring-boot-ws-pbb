create trigger TDA_D7
	after delete
	on DAT_OBJEK_PAJAK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PERUBAHAN_NOP"
    delete PERUBAHAN_NOP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "PENERIMA_KOMPENSASI"
    delete PENERIMA_KOMPENSASI
    where  KD_PROPINSI_KOMPENSASI = :old.KD_PROPINSI
     and   KD_DATI2_KOMPENSASI = :old.KD_DATI2
     and   KD_KECAMATAN_KOMPENSASI = :old.KD_KECAMATAN
     and   KD_KELURAHAN_KOMPENSASI = :old.KD_KELURAHAN
     and   KD_BLOK_KOMPENSASI = :old.KD_BLOK
     and   NO_URUT_KOMPENSASI = :old.NO_URUT
     and   KD_JNS_OP_KOMPENSASI = :old.KD_JNS_OP;

    --  Delete all children in "DAT_TRANSAKSI_JUAL_BELI"
    delete DAT_TRANSAKSI_JUAL_BELI
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "SRT_HIMBAUAN"
    delete SRT_HIMBAUAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "STP"
    delete STP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "NOP_MUTASI"
    delete NOP_MUTASI
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "SKP_KURANG_BAYAR"
    delete SKP_KURANG_BAYAR
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "SKP_SPOP"
    delete SKP_SPOP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "DAT_OP_BUMI"
    delete DAT_OP_BUMI
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "SPPT"
    delete SPPT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "DAT_OP_BANGUNAN"
    delete DAT_OP_BANGUNAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "HIS_OBJEK_PAJAK"
    delete HIS_OBJEK_PAJAK
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "HIS_OP_ANGGOTA"
    delete HIS_OP_ANGGOTA
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    /*--  Delete all children in "SIM_PBB"
    delete SIM_PBB
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;*/

    --  Delete all children in "DAT_SUBJEK_PAJAK_NJOPTKP"
    delete DAT_SUBJEK_PAJAK_NJOPTKP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "TEMPAT_BAYAR_KHUSUS"
    delete TEMPAT_BAYAR_KHUSUS
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "TEMP_SPOP_LSPOP"
    delete TEMP_SPOP_LSPOP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "TEMP_SPPT"
    delete TEMP_SPPT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "DAT_KELOMPOK_SPPT"
    delete DAT_KELOMPOK_SPPT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "DAT_OP_ANGGOTA"
    delete DAT_OP_ANGGOTA
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    --  Delete all children in "DAT_OP_INDUK"
    delete DAT_OP_INDUK
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;


    -- Delete all children in "NOP_NPWP"
    delete NOP_NPWP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;


    -- Delete all children in "NOP_PASPOR"
    delete NOP_PASPOR
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    -- Delete all children in "SIG_KELUARGA"
    delete SIG_KELUARGA
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;

    -- Delete all children in "SIG_TELEPON"
    delete SIG_TELEPON
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP;


    IntegrityPackage.PreviousNestLevel;
--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;


