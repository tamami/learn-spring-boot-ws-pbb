create trigger TUA_C7
	after update of KD_PEKERJAAN,KD_KEGIATAN
	on PEKERJAAN_KEGIATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "HRG_SATUAN"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update HRG_SATUAN
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "VOL_KEGIATAN_JPB8"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update VOL_KEGIATAN_JPB8
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "ADJ_MATERIAL"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update ADJ_MATERIAL
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "VOL_KEGIATAN"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update VOL_KEGIATAN
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "VOL_RESOURCE"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update VOL_RESOURCE
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "DBKB_MATERIAL"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update DBKB_MATERIAL
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "SIM_HRG_SATUAN"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update SIM_HRG_SATUAN
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "PEKERJAAN_KEGIATAN" for all children in "SIM_DBKB_MATERIAL"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update SIM_DBKB_MATERIAL
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
