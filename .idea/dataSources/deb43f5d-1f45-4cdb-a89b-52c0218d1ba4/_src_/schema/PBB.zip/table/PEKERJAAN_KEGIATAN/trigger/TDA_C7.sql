create trigger TDA_C7
	after delete
	on PEKERJAAN_KEGIATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "HRG_SATUAN"
    delete HRG_SATUAN
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "VOL_KEGIATAN_JPB8"
    delete VOL_KEGIATAN_JPB8
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "ADJ_MATERIAL"
    delete ADJ_MATERIAL
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "VOL_KEGIATAN"
    delete VOL_KEGIATAN
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "VOL_RESOURCE"
    delete VOL_RESOURCE
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "DBKB_MATERIAL"
    delete DBKB_MATERIAL
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "SIM_HRG_SATUAN"
    delete SIM_HRG_SATUAN
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "SIM_DBKB_MATERIAL"
    delete SIM_DBKB_MATERIAL
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
