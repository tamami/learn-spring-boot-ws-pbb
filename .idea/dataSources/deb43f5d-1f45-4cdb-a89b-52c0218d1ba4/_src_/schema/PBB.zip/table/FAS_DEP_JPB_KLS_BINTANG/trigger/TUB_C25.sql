create trigger TUB_C25
	before update of KD_PROPINSI,KD_DATI2,THN_DEP_JPB_KLS_BINTANG,KD_FASILITAS,KD_JPB,KLS_BINTANG
	on FAS_DEP_JPB_KLS_BINTANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_fas_dep_jpb_kls_bintang(var_kd_propinsi varchar,
                                        var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JPB"
    cursor cpk2_fas_dep_jpb_kls_bintang(var_kd_jpb varchar) is
       select 1
       from   REF_JPB
       where  KD_JPB = var_kd_jpb
        and   var_kd_jpb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "FASILITAS"
    cursor cpk3_fas_dep_jpb_kls_bintang(var_kd_fasilitas varchar) is
       select 1
       from   FASILITAS
       where  KD_FASILITAS = var_kd_fasilitas
        and   var_kd_fasilitas is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "FAS_DEP_JPB_KLS_BINTANG"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_fas_dep_jpb_kls_bintang(:new.KD_PROPINSI,
                                          :new.KD_DATI2);
       fetch cpk1_fas_dep_jpb_kls_bintang into dummy;
       found := cpk1_fas_dep_jpb_kls_bintang%FOUND;
       close cpk1_fas_dep_jpb_kls_bintang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "FAS_DEP_JPB_KLS_BINTANG".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_JPB" must exist when updating a child in "FAS_DEP_JPB_KLS_BINTANG"
    if (:new.KD_JPB is not null) and (seq = 0) then
       open  cpk2_fas_dep_jpb_kls_bintang(:new.KD_JPB);
       fetch cpk2_fas_dep_jpb_kls_bintang into dummy;
       found := cpk2_fas_dep_jpb_kls_bintang%FOUND;
       close cpk2_fas_dep_jpb_kls_bintang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JPB". Cannot update child in "FAS_DEP_JPB_KLS_BINTANG".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "FASILITAS" must exist when updating a child in "FAS_DEP_JPB_KLS_BINTANG"
    if (:new.KD_FASILITAS is not null) and (seq = 0) then
       open  cpk3_fas_dep_jpb_kls_bintang(:new.KD_FASILITAS);
       fetch cpk3_fas_dep_jpb_kls_bintang into dummy;
       found := cpk3_fas_dep_jpb_kls_bintang%FOUND;
       close cpk3_fas_dep_jpb_kls_bintang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "FASILITAS". Cannot update child in "FAS_DEP_JPB_KLS_BINTANG".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
