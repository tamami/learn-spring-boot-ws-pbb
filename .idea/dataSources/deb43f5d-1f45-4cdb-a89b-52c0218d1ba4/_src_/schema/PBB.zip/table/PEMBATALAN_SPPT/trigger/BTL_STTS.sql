create trigger BTL_STTS
	before insert
	on PEMBATALAN_SPPT
	for each row
BEGIN
   SELECT MAX(PEMBATALAN_SPPT_KE)+1 INTO :new.PEMBATALAN_SPPT_KE
   FROM   PEMBATALAN_SPPT
   WHERE  KD_PROPINSI     = :new.KD_PROPINSI and
          KD_DATI2 	      = :new.KD_DATI2 and
          KD_KECAMATAN    = :new.KD_KECAMATAN and
          KD_KELURAHAN    = :new.KD_KELURAHAN and
          KD_BLOK  		  = :new.KD_BLOK and
          NO_URUT  	 	  = :new.NO_URUT and
          KD_JNS_OP       = :new.KD_JNS_OP and
          THN_PAJAK_SPPT  = :new.THN_PAJAK_SPPT;
   if (:new.PEMBATALAN_SPPT_KE is NULL) OR (:new.PEMBATALAN_SPPT_KE < 1) then
      :new.PEMBATALAN_SPPT_KE:=1;
   end if;
   INSERT INTO TEMP_PEMBATALAN_SPPT VALUES (
     :new.KD_PROPINSI, :new.KD_DATI2, :new.KD_KECAMATAN,
     :new.KD_KELURAHAN, :new.KD_BLOK, :new.NO_URUT,
	 :new.KD_JNS_OP, :new.THN_PAJAK_SPPT,:new.PEMBATALAN_SPPT_KE) ;
END;
