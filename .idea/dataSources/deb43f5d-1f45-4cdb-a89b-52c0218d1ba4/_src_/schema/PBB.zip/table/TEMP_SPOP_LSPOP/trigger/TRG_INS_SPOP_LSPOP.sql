create trigger TRG_INS_SPOP_LSPOP
	before insert or update
	on TEMP_SPOP_LSPOP
	for each row
declare
  cursor c_3 is
    select kd_propinsi, kd_dati2, kd_kecamatan, kd_kelurahan, kd_blok, no_urut, kd_jns_op
    from temp_spop_lspop
    where jns_transaksi_temp = '9' and status_proses = 0;

  cursor c_op is
    select kd_propinsi, kd_dati2, kd_kecamatan, kd_kelurahan, kd_blok, no_urut, kd_jns_op
    from temp_spop_lspop
    where jns_transaksi_temp = '2' and status_proses = 0;

  vli_temp number(15);
  vls_prop char(2);
  vls_dat char(2);
  vls_kec char(3);
  vls_kel char(3);
  vls_blok char(3);
  vls_urut char(4);
  vls_jns char(1);
  vls_kd_jpb      dat_op_bangunan.kd_jpb%type;
  vli_luas_bng         dat_op_bangunan.luas_bng%type;
  vli_jml_lantai_bng   dat_op_bangunan.jml_lantai_bng%type;
  vli_nilai_bng     dat_op_bangunan.nilai_sistem_bng%type := 0;
  vli_nilai_bng_per_m2 dat_op_bangunan.nilai_sistem_bng%type := 0;
  vli_njop_bng_per_m2  dat_objek_pajak.njop_bng%type :=0;
  vlc_thn_curent sppt.thn_pajak_sppt%type := to_char(sysdate, 'YYYY');
begin
  if :new.jns_transaksi_temp = '1' then
    begin
	  :new.status_proses := 1;
      PENENTUAN_NJOP_BUMI(:new.kd_propinsi, :new.kd_dati2, :new.kd_kecamatan, :new.kd_kelurahan,
      :new.kd_blok, :new.no_urut, :new.kd_jns_op, to_char(sysdate,'yyyy'), 1, vli_temp);
    end;
  elsif :new.jns_transaksi_temp = '4' then
	-- hitung NJOP bangunan
	 begin
	   :new.status_proses := 1;
	   open c_op;
	   loop
	   exit when c_op%notfound;
	   fetch c_op into vls_prop, vls_dat, vls_kec, vls_kel, vls_blok, vls_urut, vls_jns;
		 PENENTUAN_NJOP_BNG(vls_prop, vls_dat, vls_kec, vls_kel, vls_blok, vls_urut, vls_jns,
	     to_char(sysdate,'yyyy'), 1, vli_temp);
		 UPD_TEMP_SPOP(vls_prop,vls_dat,vls_kec,vls_kel,vls_blok,vls_urut,vls_jns);
	   end loop;

	 exception when others then null;
	 end;

 -- op bersama
	 begin
	   Open c_3;
	   loop
	   Exit when c_3%notfound;
	   Fetch c_3 into vls_prop, vls_dat, vls_kec, vls_kel, vls_blok, vls_urut, vls_jns;
	     PENILAIAN_OP_ANGGOTA_MASSAL(vls_prop, vls_dat, vls_kec, vls_kel, vls_blok,
	       vls_urut, vls_jns, vlc_thn_curent, 1);
	   begin
	     Update temp_spop_lspop set status_proses = '1'
	     where kd_propinsi = vls_prop
	       and kd_dati2 = vls_dat
	       and kd_kecamatan = vls_kec
	       and kd_kelurahan = vls_kel
	       and kd_blok = vls_blok
	       and no_urut = vls_urut
	       and kd_jns_op = vls_jns
	    and jns_transaksi_temp = '9'
	    and no_transaksi_temp = 9
	    and status_proses = 0;
	   exception when others then null;
	   end;
	   end loop;
	   Close c_3;
    exception when others then null;
    end;
  end if;
  begin
    delete from temp_spop_lspop
  where status_proses = 1;
  exception when others then null;
  end;
exception when others then null;
end TRG_INS_SPOP_LSPOP;




