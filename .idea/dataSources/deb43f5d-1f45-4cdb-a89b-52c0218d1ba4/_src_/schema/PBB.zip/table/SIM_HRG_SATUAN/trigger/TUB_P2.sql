create trigger TUB_P2
	before update of KD_PROPINSI,KD_DATI2,SIM_THN_HRG_SATUAN,KD_PEKERJAAN,KD_KEGIATAN
	on SIM_HRG_SATUAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEKERJAAN_KEGIATAN"
    cursor cpk1_sim_hrg_satuan(var_kd_pekerjaan varchar,
                               var_kd_kegiatan varchar) is
       select 1
       from   PEKERJAAN_KEGIATAN
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk2_sim_hrg_satuan(var_kd_propinsi varchar,
                               var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PEKERJAAN_KEGIATAN" must exist when updating a child in "SIM_HRG_SATUAN"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and (seq = 0) then
       open  cpk1_sim_hrg_satuan(:new.KD_PEKERJAAN,
                                 :new.KD_KEGIATAN);
       fetch cpk1_sim_hrg_satuan into dummy;
       found := cpk1_sim_hrg_satuan%FOUND;
       close cpk1_sim_hrg_satuan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEKERJAAN_KEGIATAN". Cannot update child in "SIM_HRG_SATUAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_DATI2" must exist when updating a child in "SIM_HRG_SATUAN"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk2_sim_hrg_satuan(:new.KD_PROPINSI,
                                 :new.KD_DATI2);
       fetch cpk2_sim_hrg_satuan into dummy;
       found := cpk2_sim_hrg_satuan%FOUND;
       close cpk2_sim_hrg_satuan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "SIM_HRG_SATUAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
