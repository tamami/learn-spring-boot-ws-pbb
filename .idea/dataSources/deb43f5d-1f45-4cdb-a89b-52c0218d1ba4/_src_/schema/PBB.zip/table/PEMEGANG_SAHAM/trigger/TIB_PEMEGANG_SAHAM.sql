create trigger TIB_PEMEGANG_SAHAM
	before insert
	on PEMEGANG_SAHAM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "COMP_PROFILE"
    cursor cpk1_pemegang_saham(var_mfnpwp_comp varchar,
                               var_mfkpp_comp varchar,
                               var_mfcab_comp varchar) is
       select 1
       from   COMP_PROFILE
       where  MFNPWP_COMP = var_mfnpwp_comp
        and   MFKPP_COMP = var_mfkpp_comp
        and   MFCAB_COMP = var_mfcab_comp
        and   var_mfnpwp_comp is not null
        and   var_mfkpp_comp is not null
        and   var_mfcab_comp is not null;

begin

    --  Parent "COMP_PROFILE" must exist when inserting a child in "PEMEGANG_SAHAM"
    if :new.MFNPWP_COMP is not null and
       :new.MFKPP_COMP is not null and
       :new.MFCAB_COMP is not null then
       open  cpk1_pemegang_saham(:new.MFNPWP_COMP,
                                 :new.MFKPP_COMP,
                                 :new.MFCAB_COMP);
       fetch cpk1_pemegang_saham into dummy;
       found := cpk1_pemegang_saham%FOUND;
       close cpk1_pemegang_saham;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "COMP_PROFILE". Cannot create child in "PEMEGANG_SAHAM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
