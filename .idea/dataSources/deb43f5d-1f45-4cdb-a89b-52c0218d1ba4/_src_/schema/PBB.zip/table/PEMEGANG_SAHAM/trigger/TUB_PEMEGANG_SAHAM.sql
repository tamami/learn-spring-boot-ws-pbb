create trigger TUB_PEMEGANG_SAHAM
	before update of MFNPWP_COMP,MFKPP_COMP,MFCAB_COMP,MFNPWP_PEMEGANG,MFKPP_PEMEGANG,MFCAB_PEMEGANG
	on PEMEGANG_SAHAM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "COMP_PROFILE"
    cursor cpk1_pemegang_saham(var_mfnpwp_comp varchar,
                               var_mfkpp_comp varchar,
                               var_mfcab_comp varchar) is
       select 1
       from   COMP_PROFILE
       where  MFNPWP_COMP = var_mfnpwp_comp
        and   MFKPP_COMP = var_mfkpp_comp
        and   MFCAB_COMP = var_mfcab_comp
        and   var_mfnpwp_comp is not null
        and   var_mfkpp_comp is not null
        and   var_mfcab_comp is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "COMP_PROFILE" must exist when updating a child in "PEMEGANG_SAHAM"
    if (:new.MFNPWP_COMP is not null) and
       (:new.MFKPP_COMP is not null) and
       (:new.MFCAB_COMP is not null) and (seq = 0) then
       open  cpk1_pemegang_saham(:new.MFNPWP_COMP,
                                 :new.MFKPP_COMP,
                                 :new.MFCAB_COMP);
       fetch cpk1_pemegang_saham into dummy;
       found := cpk1_pemegang_saham%FOUND;
       close cpk1_pemegang_saham;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "COMP_PROFILE". Cannot update child in "PEMEGANG_SAHAM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
