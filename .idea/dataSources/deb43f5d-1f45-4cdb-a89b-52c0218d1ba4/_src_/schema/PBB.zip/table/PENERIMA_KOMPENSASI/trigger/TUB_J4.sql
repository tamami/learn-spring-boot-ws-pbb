create trigger TUB_J4
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,NO_URUT_PENERIMA_KOMPENSASI,KD_PROPINSI_KOMPENSASI,KD_DATI2_KOMPENSASI,KD_KECAMATAN_KOMPENSASI,KD_KELURAHAN_KOMPENSASI,KD_BLOK_KOMPENSASI,NO_URUT_KOMPENSASI,KD_JNS_OP_KOMPENSASI
	on PENERIMA_KOMPENSASI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SKKPP"
    cursor cpk1_penerima_kompensasi(var_kd_kanwil varchar,
                                    var_kd_kppbb varchar,
                                    var_thn_pelayanan varchar,
                                    var_bundel_pelayanan varchar,
                                    var_no_urut_pelayanan varchar,
                                    var_kd_propinsi_pemohon varchar,
                                    var_kd_dati2_pemohon varchar,
                                    var_kd_kecamatan_pemohon varchar,
                                    var_kd_kelurahan_pemohon varchar,
                                    var_kd_blok_pemohon varchar,
                                    var_no_urut_pemohon varchar,
                                    var_kd_jns_op_pemohon varchar) is
       select 1
       from   SKKPP
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_OBJEK_PAJAK"
    cursor cpk2_penerima_kompensasi(var_kd_propinsi_kompensasi varchar,
                                    var_kd_dati2_kompensasi varchar,
                                    var_kd_kecamatan_kompensasi varchar,
                                    var_kd_kelurahan_kompensasi varchar,
                                    var_kd_blok_kompensasi varchar,
                                    var_no_urut_kompensasi varchar,
                                    var_kd_jns_op_kompensasi varchar) is
       select 1
       from   DAT_OBJEK_PAJAK
       where  KD_PROPINSI = var_kd_propinsi_kompensasi
        and   KD_DATI2 = var_kd_dati2_kompensasi
        and   KD_KECAMATAN = var_kd_kecamatan_kompensasi
        and   KD_KELURAHAN = var_kd_kelurahan_kompensasi
        and   KD_BLOK = var_kd_blok_kompensasi
        and   NO_URUT = var_no_urut_kompensasi
        and   KD_JNS_OP = var_kd_jns_op_kompensasi
        and   var_kd_propinsi_kompensasi is not null
        and   var_kd_dati2_kompensasi is not null
        and   var_kd_kecamatan_kompensasi is not null
        and   var_kd_kelurahan_kompensasi is not null
        and   var_kd_blok_kompensasi is not null
        and   var_no_urut_kompensasi is not null
        and   var_kd_jns_op_kompensasi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SKKPP" must exist when updating a child in "PENERIMA_KOMPENSASI"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk1_penerima_kompensasi(:new.KD_KANWIL,
                                      :new.KD_KPPBB,
                                      :new.THN_PELAYANAN,
                                      :new.BUNDEL_PELAYANAN,
                                      :new.NO_URUT_PELAYANAN,
                                      :new.KD_PROPINSI_PEMOHON,
                                      :new.KD_DATI2_PEMOHON,
                                      :new.KD_KECAMATAN_PEMOHON,
                                      :new.KD_KELURAHAN_PEMOHON,
                                      :new.KD_BLOK_PEMOHON,
                                      :new.NO_URUT_PEMOHON,
                                      :new.KD_JNS_OP_PEMOHON);
       fetch cpk1_penerima_kompensasi into dummy;
       found := cpk1_penerima_kompensasi%FOUND;
       close cpk1_penerima_kompensasi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SKKPP". Cannot update child in "PENERIMA_KOMPENSASI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_OBJEK_PAJAK" must exist when updating a child in "PENERIMA_KOMPENSASI"
    if (:new.KD_PROPINSI_KOMPENSASI is not null) and
       (:new.KD_DATI2_KOMPENSASI is not null) and
       (:new.KD_KECAMATAN_KOMPENSASI is not null) and
       (:new.KD_KELURAHAN_KOMPENSASI is not null) and
       (:new.KD_BLOK_KOMPENSASI is not null) and
       (:new.NO_URUT_KOMPENSASI is not null) and
       (:new.KD_JNS_OP_KOMPENSASI is not null) and (seq = 0) then
       open  cpk2_penerima_kompensasi(:new.KD_PROPINSI_KOMPENSASI,
                                      :new.KD_DATI2_KOMPENSASI,
                                      :new.KD_KECAMATAN_KOMPENSASI,
                                      :new.KD_KELURAHAN_KOMPENSASI,
                                      :new.KD_BLOK_KOMPENSASI,
                                      :new.NO_URUT_KOMPENSASI,
                                      :new.KD_JNS_OP_KOMPENSASI);
       fetch cpk2_penerima_kompensasi into dummy;
       found := cpk2_penerima_kompensasi%FOUND;
       close cpk2_penerima_kompensasi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_OBJEK_PAJAK". Cannot update child in "PENERIMA_KOMPENSASI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
