create trigger TIB_PBB_MINIMAL
	before insert
	on PBB_MINIMAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_pbb_minimal(var_kd_propinsi varchar,
                        var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_pbb_minimal(var_nip_perekam varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam
        and   var_nip_perekam is not null;
begin

    --  Parent "REF_DATI2" must exist when inserting a child in "PBB_MINIMAL"
    if :new.KD_PROPINSI is not null and
       :new.KD_DATI2 is not null then
       open  cpk1_pbb_minimal(:new.KD_PROPINSI,
                          :new.KD_DATI2);
       fetch cpk1_pbb_minimal into dummy;
       found := cpk1_pbb_minimal%FOUND;
       close cpk1_pbb_minimal;
       if not found then
          errno  := -20001;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot create child in "PBB_MINIMAL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when inserting a child in "PBB_MINIMAL"
    if :new.NIP_PEREKAM_PBB_MINIMAL is not null then
       open  cpk2_pbb_minimal(:new.NIP_PEREKAM_PBB_MINIMAL);
       fetch cpk2_pbb_minimal into dummy;
       found := cpk2_pbb_minimal%FOUND;
       close cpk2_pbb_minimal;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot create child in "PBB_MINIMAL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;

