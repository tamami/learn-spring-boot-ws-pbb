create trigger TUB_K6
	before update of KD_PROPINSI,KD_DATI2,THN_LAP_PEMBAGIAN,BLN_LAP_PEMBAGIAN,KD_MATA_ANGGARAN,JNS_MATA_ANGGARAN,NIP_REKAM_LAP_PEMBAGIAN
	on LAPORAN_PEMBAGIAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_MATA_ANGGARAN"
    cursor cpk1_laporan_pembagian(var_kd_propinsi varchar,
                                  var_kd_dati2 varchar,
                                  var_jns_mata_anggaran varchar,
                                  var_kd_mata_anggaran varchar) is
       select 1
       from   REF_MATA_ANGGARAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   JNS_MATA_ANGGARAN = var_jns_mata_anggaran
        and   KD_MATA_ANGGARAN = var_kd_mata_anggaran
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_jns_mata_anggaran is not null
        and   var_kd_mata_anggaran is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk2_laporan_pembagian(var_kd_propinsi varchar,
                                  var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_laporan_pembagian(var_nip_rekam_lap_pembagian varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_lap_pembagian
        and   var_nip_rekam_lap_pembagian is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_MATA_ANGGARAN" must exist when updating a child in "LAPORAN_PEMBAGIAN"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.JNS_MATA_ANGGARAN is not null) and
       (:new.KD_MATA_ANGGARAN is not null) and (seq = 0) then
       open  cpk1_laporan_pembagian(:new.KD_PROPINSI,
                                    :new.KD_DATI2,
                                    :new.JNS_MATA_ANGGARAN,
                                    :new.KD_MATA_ANGGARAN);
       fetch cpk1_laporan_pembagian into dummy;
       found := cpk1_laporan_pembagian%FOUND;
       close cpk1_laporan_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_MATA_ANGGARAN". Cannot update child in "LAPORAN_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_DATI2" must exist when updating a child in "LAPORAN_PEMBAGIAN"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk2_laporan_pembagian(:new.KD_PROPINSI,
                                    :new.KD_DATI2);
       fetch cpk2_laporan_pembagian into dummy;
       found := cpk2_laporan_pembagian%FOUND;
       close cpk2_laporan_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "LAPORAN_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "LAPORAN_PEMBAGIAN"
    if (:new.NIP_REKAM_LAP_PEMBAGIAN is not null) and (seq = 0) then
       open  cpk3_laporan_pembagian(:new.NIP_REKAM_LAP_PEMBAGIAN);
       fetch cpk3_laporan_pembagian into dummy;
       found := cpk3_laporan_pembagian%FOUND;
       close cpk3_laporan_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "LAPORAN_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
