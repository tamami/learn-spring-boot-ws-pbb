create trigger TUA_G14
	after update of KD_KANWIL,KD_KPPBB,NO_SRT_PAKSA,NO_SRT_TEGORAN,NIP_PENCETAK_SURAT_PAKSA
	on SRT_PAKSA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SRT_PAKSA" for all children in "SRT_PERINTAH_SITA"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SRT_PAKSA') and :old.NO_SRT_PAKSA != :new.NO_SRT_PAKSA) then
       update SRT_PERINTAH_SITA
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SRT_PAKSA = :new.NO_SRT_PAKSA
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SRT_PAKSA = :old.NO_SRT_PAKSA;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
