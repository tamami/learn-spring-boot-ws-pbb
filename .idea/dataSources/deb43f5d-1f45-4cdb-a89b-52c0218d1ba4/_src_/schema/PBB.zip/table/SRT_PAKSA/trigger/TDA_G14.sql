create trigger TDA_G14
	after delete
	on SRT_PAKSA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SRT_PERINTAH_SITA"
    delete SRT_PERINTAH_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_SRT_PAKSA = :old.NO_SRT_PAKSA;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
