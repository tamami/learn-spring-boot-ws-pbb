create trigger TUA_D15
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BNG,NIP_PENILAI_INDIVIDU,NIP_PEMERIKSA_INDIVIDU,NIP_PEREKAM_INDIVIDU
	on DAT_NILAI_INDIVIDU
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_NILAI_INDIVIDU" for all children in "HIS_NILAI_INDIVIDU"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update HIS_NILAI_INDIVIDU
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
