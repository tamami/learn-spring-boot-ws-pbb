create trigger TUA_E6
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_SPPT,KD_KANWIL_BANK,KD_KPPBB_BANK,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI,KD_TP,KD_KLS_TANAH,THN_AWAL_KLS_TANAH,KD_KLS_BNG,THN_AWAL_KLS_BNG,NIP_PENCETAK_SPPT
	on SPPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SPPT" for all children in "TTR_SPPT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update TTR_SPPT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "PEMBAYARAN_SPPT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update PEMBAYARAN_SPPT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "SPPT_OP_BERSAMA"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update SPPT_OP_BERSAMA
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "PENGEMBALIAN_SPPT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update PENGEMBALIAN_SPPT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "HIS_SPPT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update HIS_SPPT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "PENGHAPUSAN_PIUTANG"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update PENGHAPUSAN_PIUTANG
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;

    --  Modify parent code of "SPPT" for all children in "BANDING"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('THN_PAJAK_SPPT') and :old.THN_PAJAK_SPPT != :new.THN_PAJAK_SPPT) then
       update BANDING
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              THN_PAJAK_SPPT = :new.THN_PAJAK_SPPT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   THN_PAJAK_SPPT = :old.THN_PAJAK_SPPT;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
