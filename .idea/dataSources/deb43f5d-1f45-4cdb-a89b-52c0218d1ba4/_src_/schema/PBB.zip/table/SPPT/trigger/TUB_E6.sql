create trigger TUB_E6
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_SPPT,KD_KANWIL_BANK,KD_KPPBB_BANK,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI,KD_TP,KD_KLS_TANAH,THN_AWAL_KLS_TANAH,KD_KLS_BNG,THN_AWAL_KLS_BNG,NIP_PENCETAK_SPPT
	on SPPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_TANAH"
    cursor cpk1_sppt(var_kd_kls_tanah varchar,
                     var_thn_awal_kls_tanah varchar) is
       select 1
       from   KELAS_TANAH
       where  KD_KLS_TANAH = var_kd_kls_tanah
        and   THN_AWAL_KLS_TANAH = var_thn_awal_kls_tanah
        and   var_kd_kls_tanah is not null
        and   var_thn_awal_kls_tanah is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_BANGUNAN"
    cursor cpk2_sppt(var_kd_kls_bng varchar,
                     var_thn_awal_kls_bng varchar) is
       select 1
       from   KELAS_BANGUNAN
       where  KD_KLS_BNG = var_kd_kls_bng
        and   THN_AWAL_KLS_BNG = var_thn_awal_kls_bng
        and   var_kd_kls_bng is not null
        and   var_thn_awal_kls_bng is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "TEMPAT_PEMBAYARAN"
    cursor cpk3_sppt(var_kd_kanwil_bank varchar,
                     var_kd_kppbb_bank varchar,
                     var_kd_bank_tunggal varchar,
                     var_kd_bank_persepsi varchar,
                     var_kd_tp varchar) is
       select 1
       from   TEMPAT_PEMBAYARAN
       where  KD_KANWIL = var_kd_kanwil_bank
        and   KD_KPPBB = var_kd_kppbb_bank
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   KD_BANK_PERSEPSI = var_kd_bank_persepsi
        and   KD_TP = var_kd_tp
        and   var_kd_kanwil_bank is not null
        and   var_kd_kppbb_bank is not null
        and   var_kd_bank_tunggal is not null
        and   var_kd_bank_persepsi is not null
        and   var_kd_tp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_OBJEK_PAJAK"
    cursor cpk4_sppt(var_kd_propinsi varchar,
                     var_kd_dati2 varchar,
                     var_kd_kecamatan varchar,
                     var_kd_kelurahan varchar,
                     var_kd_blok varchar,
                     var_no_urut varchar,
                     var_kd_jns_op varchar) is
       select 1
       from   DAT_OBJEK_PAJAK
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk5_sppt(var_nip_pencetak_sppt varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_sppt
        and   var_nip_pencetak_sppt is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "KELAS_TANAH" must exist when updating a child in "SPPT"
    if (:new.KD_KLS_TANAH is not null) and
       (:new.THN_AWAL_KLS_TANAH is not null) and (seq = 0) then
       open  cpk1_sppt(:new.KD_KLS_TANAH,
                       :new.THN_AWAL_KLS_TANAH);
       fetch cpk1_sppt into dummy;
       found := cpk1_sppt%FOUND;
       close cpk1_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_TANAH". Cannot update child in "SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KELAS_BANGUNAN" must exist when updating a child in "SPPT"
    if (:new.KD_KLS_BNG is not null) and
       (:new.THN_AWAL_KLS_BNG is not null) and (seq = 0) then
       open  cpk2_sppt(:new.KD_KLS_BNG,
                       :new.THN_AWAL_KLS_BNG);
       fetch cpk2_sppt into dummy;
       found := cpk2_sppt%FOUND;
       close cpk2_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_BANGUNAN". Cannot update child in "SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "TEMPAT_PEMBAYARAN" must exist when updating a child in "SPPT"
    if (:new.KD_KANWIL_BANK is not null) and
       (:new.KD_KPPBB_BANK is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and
       (:new.KD_BANK_PERSEPSI is not null) and
       (:new.KD_TP is not null) and (seq = 0) then
       open  cpk3_sppt(:new.KD_KANWIL_BANK,
                       :new.KD_KPPBB_BANK,
                       :new.KD_BANK_TUNGGAL,
                       :new.KD_BANK_PERSEPSI,
                       :new.KD_TP);
       fetch cpk3_sppt into dummy;
       found := cpk3_sppt%FOUND;
       close cpk3_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "TEMPAT_PEMBAYARAN". Cannot update child in "SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_OBJEK_PAJAK" must exist when updating a child in "SPPT"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and (seq = 0) then
       open  cpk4_sppt(:new.KD_PROPINSI,
                       :new.KD_DATI2,
                       :new.KD_KECAMATAN,
                       :new.KD_KELURAHAN,
                       :new.KD_BLOK,
                       :new.NO_URUT,
                       :new.KD_JNS_OP);
       fetch cpk4_sppt into dummy;
       found := cpk4_sppt%FOUND;
       close cpk4_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_OBJEK_PAJAK". Cannot update child in "SPPT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SPPT"
    if (:new.NIP_PENCETAK_SPPT is not null) and (seq = 0) then
       open  cpk5_sppt(:new.NIP_PENCETAK_SPPT);
       fetch cpk5_sppt into dummy;
       found := cpk5_sppt%FOUND;
       close cpk5_sppt;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SPPT".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
