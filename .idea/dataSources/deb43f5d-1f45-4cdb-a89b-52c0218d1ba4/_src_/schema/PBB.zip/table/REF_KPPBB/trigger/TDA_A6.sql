create trigger TDA_A6
	after delete
	on REF_KPPBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SRT_BATAL_LELANG"
    delete SRT_BATAL_LELANG
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SRT_CABUT_SITA"
    delete SRT_CABUT_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "PERMINTAAN_JADUAL_LELANG"
    delete PERMINTAAN_JADUAL_LELANG
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SRT_PERINTAH_SITA"
    delete SRT_PERINTAH_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SRT_PAKSA"
    delete SRT_PAKSA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SRT_TEGORAN"
    delete SRT_TEGORAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SRT_HIMBAUAN"
    delete SRT_HIMBAUAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "POSISI_PEGAWAI"
    delete POSISI_PEGAWAI
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "BANK_TUNGGAL"
    delete BANK_TUNGGAL
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "PST_PERMOHONAN"
    delete PST_PERMOHONAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "DOKUMEN"
    delete DOKUMEN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "REF_ADM_KPPBB"
    delete REF_ADM_KPPBB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "BA_SITA"
    delete BA_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SK_SK"
    delete SK_SK
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "PEMBATALAN_SPMKP"
    delete PEMBATALAN_SPMKP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SPMKP"
    delete SPMKP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SKKPP"
    delete SKKPP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "SPB"
    delete SPB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;

    --  Delete all children in "TEMP_MAX_BUNDEL"
    delete TEMP_MAX_BUNDEL
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
