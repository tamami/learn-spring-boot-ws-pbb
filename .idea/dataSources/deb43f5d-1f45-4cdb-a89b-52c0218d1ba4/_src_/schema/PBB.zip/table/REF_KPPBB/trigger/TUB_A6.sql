create trigger TUB_A6
	before update of KD_KANWIL,KD_KPPBB
	on REF_KPPBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KANWIL"
    cursor cpk1_ref_kppbb(var_kd_kanwil varchar) is
       select 1
       from   REF_KANWIL
       where  KD_KANWIL = var_kd_kanwil
        and   var_kd_kanwil is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KANWIL" must exist when updating a child in "REF_KPPBB"
    if (:new.KD_KANWIL is not null) and (seq = 0) then
       open  cpk1_ref_kppbb(:new.KD_KANWIL);
       fetch cpk1_ref_kppbb into dummy;
       found := cpk1_ref_kppbb%FOUND;
       close cpk1_ref_kppbb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KANWIL". Cannot update child in "REF_KPPBB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
