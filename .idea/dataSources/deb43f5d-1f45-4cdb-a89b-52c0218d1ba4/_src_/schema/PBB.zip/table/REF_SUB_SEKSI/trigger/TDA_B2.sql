create trigger TDA_B2
	after delete
	on REF_SUB_SEKSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "POSISI_PEGAWAI"
    delete POSISI_PEGAWAI
    where  KD_SEKSI = :old.KD_SEKSI
     and   KD_SUBSEKSI = :old.KD_SUBSEKSI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
