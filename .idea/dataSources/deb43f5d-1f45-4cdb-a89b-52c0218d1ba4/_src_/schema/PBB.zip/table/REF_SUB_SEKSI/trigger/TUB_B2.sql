create trigger TUB_B2
	before update of KD_SEKSI,KD_SUBSEKSI
	on REF_SUB_SEKSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_SEKSI"
    cursor cpk1_ref_sub_seksi(var_kd_seksi varchar) is
       select 1
       from   REF_SEKSI
       where  KD_SEKSI = var_kd_seksi
        and   var_kd_seksi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_SEKSI" must exist when updating a child in "REF_SUB_SEKSI"
    if (:new.KD_SEKSI is not null) and (seq = 0) then
       open  cpk1_ref_sub_seksi(:new.KD_SEKSI);
       fetch cpk1_ref_sub_seksi into dummy;
       found := cpk1_ref_sub_seksi%FOUND;
       close cpk1_ref_sub_seksi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_SEKSI". Cannot update child in "REF_SUB_SEKSI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
