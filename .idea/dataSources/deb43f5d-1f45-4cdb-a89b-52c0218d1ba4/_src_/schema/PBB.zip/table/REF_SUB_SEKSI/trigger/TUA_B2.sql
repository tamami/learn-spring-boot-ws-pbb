create trigger TUA_B2
	after update of KD_SEKSI,KD_SUBSEKSI
	on REF_SUB_SEKSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_SUB_SEKSI" for all children in "POSISI_PEGAWAI"
    if (updating('KD_SEKSI') and :old.KD_SEKSI != :new.KD_SEKSI) or
       (updating('KD_SUBSEKSI') and :old.KD_SUBSEKSI != :new.KD_SUBSEKSI) then
       update POSISI_PEGAWAI
        set   KD_SEKSI = :new.KD_SEKSI,
              KD_SUBSEKSI = :new.KD_SUBSEKSI
       where  KD_SEKSI = :old.KD_SEKSI
        and   KD_SUBSEKSI = :old.KD_SUBSEKSI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
