create trigger TIB_AKTA_NIKAH
	before insert
	on AKTA_NIKAH
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "PENDUDUK"
    cursor cpk1_akta_nikah(var_no_penduduk varchar) is
       select 1
       from   PENDUDUK
       where  NO_PENDUDUK = var_no_penduduk
        and   var_no_penduduk is not null;

begin

    --  Parent "PENDUDUK" must exist when inserting a child in "AKTA_NIKAH"
    if :new.NO_PENDUDUK is not null then
       open  cpk1_akta_nikah(:new.NO_PENDUDUK);
       fetch cpk1_akta_nikah into dummy;
       found := cpk1_akta_nikah%FOUND;
       close cpk1_akta_nikah;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PENDUDUK". Cannot create child in "AKTA_NIKAH".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
