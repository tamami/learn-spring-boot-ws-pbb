create trigger TUA_G19
	after update of KD_KANWIL,KD_KPPBB,NO_PMT_JDL_LELANG,NO_SPMP,KD_KANTOR_LELANG,NIP_PENCETAK_SRT_PMT_JDL_LLG
	on PERMINTAAN_JADUAL_LELANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PERMINTAAN_JADUAL_LELANG" for all children in "SRT_BATAL_LELANG"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_PMT_JDL_LELANG') and :old.NO_PMT_JDL_LELANG != :new.NO_PMT_JDL_LELANG) then
       update SRT_BATAL_LELANG
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_PMT_JDL_LELANG = :new.NO_PMT_JDL_LELANG
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_PMT_JDL_LELANG = :old.NO_PMT_JDL_LELANG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
