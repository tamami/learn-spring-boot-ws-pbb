create trigger TDA_G19
	after delete
	on PERMINTAAN_JADUAL_LELANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SRT_BATAL_LELANG"
    delete SRT_BATAL_LELANG
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_PMT_JDL_LELANG = :old.NO_PMT_JDL_LELANG;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
