create trigger TUB_E10
	before update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI,KD_TP
	on TEMPAT_PEMBAYARAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BANK_PERSEPSI"
    cursor cpk1_tempat_pembayaran(var_kd_kanwil varchar,
                                  var_kd_kppbb varchar,
                                  var_kd_bank_tunggal varchar,
                                  var_kd_bank_persepsi varchar) is
       select 1
       from   BANK_PERSEPSI
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   KD_BANK_PERSEPSI = var_kd_bank_persepsi
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_kd_bank_tunggal is not null
        and   var_kd_bank_persepsi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BANK_PERSEPSI" must exist when updating a child in "TEMPAT_PEMBAYARAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and
       (:new.KD_BANK_PERSEPSI is not null) and (seq = 0) then
       open  cpk1_tempat_pembayaran(:new.KD_KANWIL,
                                    :new.KD_KPPBB,
                                    :new.KD_BANK_TUNGGAL,
                                    :new.KD_BANK_PERSEPSI);
       fetch cpk1_tempat_pembayaran into dummy;
       found := cpk1_tempat_pembayaran%FOUND;
       close cpk1_tempat_pembayaran;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BANK_PERSEPSI". Cannot update child in "TEMPAT_PEMBAYARAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
