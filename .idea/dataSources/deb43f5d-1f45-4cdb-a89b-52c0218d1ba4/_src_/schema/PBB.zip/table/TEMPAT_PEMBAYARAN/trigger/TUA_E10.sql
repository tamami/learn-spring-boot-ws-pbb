create trigger TUA_E10
	after update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI,KD_TP
	on TEMPAT_PEMBAYARAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "PEMBAYARAN_STP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update PEMBAYARAN_STP
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "STP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update STP
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "PEMBAYARAN_SKP_KB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update PEMBAYARAN_SKP_KB
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "PEMBAYARAN_SKP_SPOP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update PEMBAYARAN_SKP_SPOP
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "PEMBAYARAN_SPPT"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update PEMBAYARAN_SPPT
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "SKP_KURANG_BAYAR"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update SKP_KURANG_BAYAR
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "SKP_SPOP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update SKP_SPOP
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "TEMPAT_PEMBAYARAN_SPPT_MASAL"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update TEMPAT_PEMBAYARAN_SPPT_MASAL
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "SPPT"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update SPPT
        set   KD_KANWIL_BANK = :new.KD_KANWIL,
              KD_KPPBB_BANK = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL_BANK = :old.KD_KANWIL
        and   KD_KPPBB_BANK = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "HIS_SPPT"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update HIS_SPPT
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              HIS_KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              HIS_KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              HIS_KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   HIS_KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   HIS_KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   HIS_KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "HIS_SKP_SPOP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update HIS_SKP_SPOP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              HIS_KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              HIS_KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              HIS_KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   HIS_KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   HIS_KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   HIS_KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "HIS_SKP_KURANG_BAYAR"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update HIS_SKP_KURANG_BAYAR
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              HIS_KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              HIS_KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              HIS_KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   HIS_KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   HIS_KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   HIS_KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "HIS_STP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update HIS_STP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              HIS_KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              HIS_KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              HIS_KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   HIS_KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   HIS_KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   HIS_KD_TP = :old.KD_TP;
    end if;

    --  Modify parent code of "TEMPAT_PEMBAYARAN" for all children in "TEMPAT_BAYAR_KHUSUS"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) or
       (updating('KD_TP') and :old.KD_TP != :new.KD_TP) then
       update TEMPAT_BAYAR_KHUSUS
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI,
              KD_TP = :new.KD_TP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI
        and   KD_TP = :old.KD_TP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;