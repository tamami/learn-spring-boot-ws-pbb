create trigger TIB_KOMDIR
	before insert
	on KOMDIR
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "JABATAN_KOMDIR"
    cursor cpk1_komdir(var_kd_jabatan_komdir varchar) is
       select 1
       from   JABATAN_KOMDIR
       where  KD_JABATAN_KOMDIR = var_kd_jabatan_komdir
        and   var_kd_jabatan_komdir is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "COMP_PROFILE"
    cursor cpk2_komdir(var_mfnpwp_comp varchar,
                       var_mfkpp_comp varchar,
                       var_mfcab_comp varchar) is
       select 1
       from   COMP_PROFILE
       where  MFNPWP_COMP = var_mfnpwp_comp
        and   MFKPP_COMP = var_mfkpp_comp
        and   MFCAB_COMP = var_mfcab_comp
        and   var_mfnpwp_comp is not null
        and   var_mfkpp_comp is not null
        and   var_mfcab_comp is not null;

begin

    --  Parent "JABATAN_KOMDIR" must exist when inserting a child in "KOMDIR"
    if :new.KD_JABATAN_KOMDIR is not null then
       open  cpk1_komdir(:new.KD_JABATAN_KOMDIR);
       fetch cpk1_komdir into dummy;
       found := cpk1_komdir%FOUND;
       close cpk1_komdir;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "JABATAN_KOMDIR". Cannot create child in "KOMDIR".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "COMP_PROFILE" must exist when inserting a child in "KOMDIR"
    if :new.MFNPWP_COMP is not null and
       :new.MFKPP_COMP is not null and
       :new.MFCAB_COMP is not null then
       open  cpk2_komdir(:new.MFNPWP_COMP,
                         :new.MFKPP_COMP,
                         :new.MFCAB_COMP);
       fetch cpk2_komdir into dummy;
       found := cpk2_komdir%FOUND;
       close cpk2_komdir;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "COMP_PROFILE". Cannot create child in "KOMDIR".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
