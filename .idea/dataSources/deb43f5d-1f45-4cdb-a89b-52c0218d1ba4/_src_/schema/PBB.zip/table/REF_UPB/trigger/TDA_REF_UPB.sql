create trigger TDA_REF_UPB
	after delete
	on REF_UPB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "ASET_KIBB"
    delete ASET_KIBB
    where  KD_PEBIN = :old.KD_PEBIN
     and   KD_PBI = :old.KD_PBI
     and   KD_PPBI = :old.KD_PPBI
     and   KD_UPB = :old.KD_UPB;

    --  Delete all children in "ASET_KIBT"
    delete ASET_KIBT
    where  KD_PEBIN = :old.KD_PEBIN
     and   KD_PBI = :old.KD_PBI
     and   KD_PPBI = :old.KD_PPBI
     and   KD_UPB = :old.KD_UPB;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
