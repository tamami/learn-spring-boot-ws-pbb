create trigger TIB_REF_UPB
	before insert
	on REF_UPB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "REF_PPBI"
    cursor cpk1_ref_upb(var_kd_pebin varchar,
                        var_kd_pbi varchar,
                        var_kd_ppbi varchar) is
       select 1
       from   REF_PPBI
       where  KD_PEBIN = var_kd_pebin
        and   KD_PBI = var_kd_pbi
        and   KD_PPBI = var_kd_ppbi
        and   var_kd_pebin is not null
        and   var_kd_pbi is not null
        and   var_kd_ppbi is not null;

begin

    --  Parent "REF_PPBI" must exist when inserting a child in "REF_UPB"
    if :new.KD_PEBIN is not null and
       :new.KD_PBI is not null and
       :new.KD_PPBI is not null then
       open  cpk1_ref_upb(:new.KD_PEBIN,
                          :new.KD_PBI,
                          :new.KD_PPBI);
       fetch cpk1_ref_upb into dummy;
       found := cpk1_ref_upb%FOUND;
       close cpk1_ref_upb;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "REF_PPBI". Cannot create child in "REF_UPB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
