create trigger SIG_TGH1
	after update of NO_PELANGGAN
	on SIG_LISTRIK
	for each row
DECLARE
    integrity_error  EXCEPTION;
    errno            INTEGER;
    errmsg           CHAR(200);
    dummy            INTEGER;
    found            BOOLEAN;
BEGIN
    Integritypackage.NextNestLevel;
    --  Modify parent code of "SIG_LISTRIK" for all children in "SIG_LISTRIK_TAGIHAN"
    IF (UPDATING('NO_PELANGGAN') AND :OLD.NO_PELANGGAN != :NEW.NO_PELANGGAN) THEN
       UPDATE SIG_LISTRIK_TAGIHAN
        SET   NO_PELANGGAN = :NEW.NO_PELANGGAN
       WHERE
		  KD_PROPINSI = :OLD.KD_PROPINSI AND
		  KD_DATI2 = :OLD.KD_DATI2 AND
		  KD_KECAMATAN = :OLD.KD_KECAMATAN AND
		  KD_KELURAHAN = :OLD.KD_KELURAHAN AND
		  KD_BLOK = :OLD.KD_BLOK AND
		  NO_URUT = :OLD.NO_URUT AND
		  KD_JNS_OP = :OLD.KD_JNS_OP AND
		  NO_PELANGGAN = :OLD.NO_PELANGGAN;
    END IF;
    Integritypackage.PreviousNestLevel;
--  Errors handling
EXCEPTION
    WHEN integrity_error THEN
       BEGIN
       Integritypackage.InitNestLevel;
       RAISE_APPLICATION_ERROR(errno, errmsg);
       END;
END;
