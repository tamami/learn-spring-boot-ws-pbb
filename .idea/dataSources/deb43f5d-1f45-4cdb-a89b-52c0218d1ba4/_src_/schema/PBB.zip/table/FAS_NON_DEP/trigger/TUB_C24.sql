create trigger TUB_C24
	before update of KD_PROPINSI,KD_DATI2,THN_NON_DEP,KD_FASILITAS
	on FAS_NON_DEP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_fas_non_dep(var_kd_propinsi varchar,
                            var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "FASILITAS"
    cursor cpk2_fas_non_dep(var_kd_fasilitas varchar) is
       select 1
       from   FASILITAS
       where  KD_FASILITAS = var_kd_fasilitas
        and   var_kd_fasilitas is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "FAS_NON_DEP"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_fas_non_dep(:new.KD_PROPINSI,
                              :new.KD_DATI2);
       fetch cpk1_fas_non_dep into dummy;
       found := cpk1_fas_non_dep%FOUND;
       close cpk1_fas_non_dep;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "FAS_NON_DEP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "FASILITAS" must exist when updating a child in "FAS_NON_DEP"
    if (:new.KD_FASILITAS is not null) and (seq = 0) then
       open  cpk2_fas_non_dep(:new.KD_FASILITAS);
       fetch cpk2_fas_non_dep into dummy;
       found := cpk2_fas_non_dep%FOUND;
       close cpk2_fas_non_dep;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "FASILITAS". Cannot update child in "FAS_NON_DEP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
