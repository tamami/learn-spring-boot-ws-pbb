create trigger TUA_A4
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_SEKTOR
	on REF_KELURAHAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_KELURAHAN" for all children in "LOG_ZNT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update LOG_ZNT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "LOG_DBKB"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update LOG_DBKB
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "JALAN_STANDARD"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update JALAN_STANDARD
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "CETAK_MASAL"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update CETAK_MASAL
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "KALIBRASI"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update KALIBRASI
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "TEMPAT_PEMBAYARAN_SPPT_MASAL"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update TEMPAT_PEMBAYARAN_SPPT_MASAL
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "DAT_PETA_BLOK"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update DAT_PETA_BLOK
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "DAT_ZNT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update DAT_ZNT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "PENGHAPUSAN_OP"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update PENGHAPUSAN_OP
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "PENGHAPUSAN_BNG"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update PENGHAPUSAN_BNG
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "STA_POKOK_KETETAPAN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update STA_POKOK_KETETAPAN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "STA_NJOP_BUMI"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update STA_NJOP_BUMI
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "STA_NJOP_BNG"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update STA_NJOP_BNG
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "STA_POKOK_BAYAR"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update STA_POKOK_BAYAR
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "STA_PERUBAHAN_KETETAPAN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update STA_PERUBAHAN_KETETAPAN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;

    --  Modify parent code of "REF_KELURAHAN" for all children in "RENCANA_PENDATAAN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) then
       update RENCANA_PENDATAAN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
