create trigger TUA_D11
	after update of SUBJEK_PAJAK_ID
	on DAT_SUBJEK_PAJAK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_SUBJEK_PAJAK" for all children in "DAT_OBJEK_PAJAK"
    if (updating('SUBJEK_PAJAK_ID') and :old.SUBJEK_PAJAK_ID != :new.SUBJEK_PAJAK_ID) then
       update DAT_OBJEK_PAJAK
        set   SUBJEK_PAJAK_ID = :new.SUBJEK_PAJAK_ID
       where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;
    end if;

    --  Modify parent code of "DAT_SUBJEK_PAJAK" for all children in "HIS_OBJEK_PAJAK"
    if (updating('SUBJEK_PAJAK_ID') and :old.SUBJEK_PAJAK_ID != :new.SUBJEK_PAJAK_ID) then
       update HIS_OBJEK_PAJAK
        set   SUBJEK_PAJAK_ID = :new.SUBJEK_PAJAK_ID
       where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;
    end if;

    --  Modify parent code of "DAT_SUBJEK_PAJAK" for all children in "DAT_SUBJEK_PAJAK_NJOPTKP"
    if (updating('SUBJEK_PAJAK_ID') and :old.SUBJEK_PAJAK_ID != :new.SUBJEK_PAJAK_ID) then
       update DAT_SUBJEK_PAJAK_NJOPTKP
        set   SUBJEK_PAJAK_ID = :new.SUBJEK_PAJAK_ID
       where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
