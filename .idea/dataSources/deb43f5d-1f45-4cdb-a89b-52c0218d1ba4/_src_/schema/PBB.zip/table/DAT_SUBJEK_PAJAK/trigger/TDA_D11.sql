create trigger TDA_D11
	after delete
	on DAT_SUBJEK_PAJAK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_OBJEK_PAJAK"
    delete DAT_OBJEK_PAJAK
    where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;

    --  Delete all children in "HIS_OBJEK_PAJAK"
    delete HIS_OBJEK_PAJAK
    where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;

    --  Delete all children in "DAT_SUBJEK_PAJAK_NJOPTKP"
    delete DAT_SUBJEK_PAJAK_NJOPTKP
    where  SUBJEK_PAJAK_ID = :old.SUBJEK_PAJAK_ID;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
