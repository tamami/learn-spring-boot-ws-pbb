create trigger TUB_ASET_KIBB
	before update of KD_PEBIN,KD_PBI,KD_PPBI,KD_UPB,KD_KIBB
	on ASET_KIBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_UPB"
    cursor cpk1_aset_kibb(var_kd_pebin varchar,
                          var_kd_pbi varchar,
                          var_kd_ppbi varchar,
                          var_kd_upb varchar) is
       select 1
       from   REF_UPB
       where  KD_PEBIN = var_kd_pebin
        and   KD_PBI = var_kd_pbi
        and   KD_PPBI = var_kd_ppbi
        and   KD_UPB = var_kd_upb
        and   var_kd_pebin is not null
        and   var_kd_pbi is not null
        and   var_kd_ppbi is not null
        and   var_kd_upb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_UPB" must exist when updating a child in "ASET_KIBB"
    if (:new.KD_PEBIN is not null) and
       (:new.KD_PBI is not null) and
       (:new.KD_PPBI is not null) and
       (:new.KD_UPB is not null) and (seq = 0) then
       open  cpk1_aset_kibb(:new.KD_PEBIN,
                            :new.KD_PBI,
                            :new.KD_PPBI,
                            :new.KD_UPB);
       fetch cpk1_aset_kibb into dummy;
       found := cpk1_aset_kibb%FOUND;
       close cpk1_aset_kibb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_UPB". Cannot update child in "ASET_KIBB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
