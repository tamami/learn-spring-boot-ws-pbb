create trigger TUA_REF_PPBI
	after update of KD_PEBIN,KD_PBI,KD_PPBI
	on REF_PPBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_PPBI" for all children in "REF_UPB"
    if (updating('KD_PEBIN') and :old.KD_PEBIN != :new.KD_PEBIN) or
       (updating('KD_PBI') and :old.KD_PBI != :new.KD_PBI) or
       (updating('KD_PPBI') and :old.KD_PPBI != :new.KD_PPBI) then
       update REF_UPB
        set   KD_PEBIN = :new.KD_PEBIN,
              KD_PBI = :new.KD_PBI,
              KD_PPBI = :new.KD_PPBI
       where  KD_PEBIN = :old.KD_PEBIN
        and   KD_PBI = :old.KD_PBI
        and   KD_PPBI = :old.KD_PPBI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
