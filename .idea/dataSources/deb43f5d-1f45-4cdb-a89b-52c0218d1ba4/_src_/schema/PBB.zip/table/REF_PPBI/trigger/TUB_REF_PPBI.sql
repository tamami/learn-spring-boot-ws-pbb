create trigger TUB_REF_PPBI
	before update of KD_PEBIN,KD_PBI,KD_PPBI
	on REF_PPBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_PBI"
    cursor cpk1_ref_ppbi(var_kd_pebin varchar,
                         var_kd_pbi varchar) is
       select 1
       from   REF_PBI
       where  KD_PEBIN = var_kd_pebin
        and   KD_PBI = var_kd_pbi
        and   var_kd_pebin is not null
        and   var_kd_pbi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_PBI" must exist when updating a child in "REF_PPBI"
    if (:new.KD_PEBIN is not null) and
       (:new.KD_PBI is not null) and (seq = 0) then
       open  cpk1_ref_ppbi(:new.KD_PEBIN,
                           :new.KD_PBI);
       fetch cpk1_ref_ppbi into dummy;
       found := cpk1_ref_ppbi%FOUND;
       close cpk1_ref_ppbi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_PBI". Cannot update child in "REF_PPBI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
