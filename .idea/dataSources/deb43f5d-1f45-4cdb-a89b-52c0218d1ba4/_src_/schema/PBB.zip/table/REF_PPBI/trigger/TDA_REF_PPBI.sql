create trigger TDA_REF_PPBI
	after delete
	on REF_PPBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "REF_UPB"
    delete REF_UPB
    where  KD_PEBIN = :old.KD_PEBIN
     and   KD_PBI = :old.KD_PBI
     and   KD_PPBI = :old.KD_PPBI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
