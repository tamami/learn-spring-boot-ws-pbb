create trigger TRG_ZNT
	before insert
	on TEMP_ZNT_MASSAL
	for each row
DECLARE
   p_nip_user  CHAR(9);
BEGIN
  IF (:NEW.NO_ZNT_MASSAL = '9999') AND (:NEW.JNS_ZNT_MASSAL = '9') AND (:NEW.STATUS_ZNT_MASSAL = 1) THEN
    Znt_Massal(p_nip_user);
  END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END TRG_TEMP_ZNT;
