create trigger TIB_REK_TELEPON
	before insert
	on REK_TELEPON
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "TELEPON"
    cursor cpk1_rek_telepon(var_kd_area varchar,
                            var_no_telepon varchar) is
       select 1
       from   TELEPON
       where  KD_AREA = var_kd_area
        and   NO_TELEPON = var_no_telepon
        and   var_kd_area is not null
        and   var_no_telepon is not null;

begin

    --  Parent "TELEPON" must exist when inserting a child in "REK_TELEPON"
    if :new.KD_AREA is not null and
       :new.NO_TELEPON is not null then
       open  cpk1_rek_telepon(:new.KD_AREA,
                              :new.NO_TELEPON);
       fetch cpk1_rek_telepon into dummy;
       found := cpk1_rek_telepon%FOUND;
       close cpk1_rek_telepon;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "TELEPON". Cannot create child in "REK_TELEPON".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
