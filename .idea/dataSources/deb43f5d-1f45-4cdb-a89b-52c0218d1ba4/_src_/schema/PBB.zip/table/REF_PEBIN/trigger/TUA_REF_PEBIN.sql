create trigger TUA_REF_PEBIN
	after update of KD_PEBIN
	on REF_PEBIN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_PEBIN" for all children in "REF_PBI"
    if (updating('KD_PEBIN') and :old.KD_PEBIN != :new.KD_PEBIN) then
       update REF_PBI
        set   KD_PEBIN = :new.KD_PEBIN
       where  KD_PEBIN = :old.KD_PEBIN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
