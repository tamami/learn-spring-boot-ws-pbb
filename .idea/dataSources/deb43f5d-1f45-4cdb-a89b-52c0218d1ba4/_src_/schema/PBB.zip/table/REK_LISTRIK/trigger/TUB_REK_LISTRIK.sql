create trigger TUB_REK_LISTRIK
	before update of NO_PELANGGAN_PLN,THN_PLN,BULAN_KE_PLN
	on REK_LISTRIK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "LISTRIK"
    cursor cpk1_rek_listrik(var_no_pelanggan_pln varchar) is
       select 1
       from   LISTRIK
       where  NO_PELANGGAN_PLN = var_no_pelanggan_pln
        and   var_no_pelanggan_pln is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "LISTRIK" must exist when updating a child in "REK_LISTRIK"
    if (:new.NO_PELANGGAN_PLN is not null) and (seq = 0) then
       open  cpk1_rek_listrik(:new.NO_PELANGGAN_PLN);
       fetch cpk1_rek_listrik into dummy;
       found := cpk1_rek_listrik%FOUND;
       close cpk1_rek_listrik;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "LISTRIK". Cannot update child in "REK_LISTRIK".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
