create trigger TIB_REK_LISTRIK
	before insert
	on REK_LISTRIK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "LISTRIK"
    cursor cpk1_rek_listrik(var_no_pelanggan_pln varchar) is
       select 1
       from   LISTRIK
       where  NO_PELANGGAN_PLN = var_no_pelanggan_pln
        and   var_no_pelanggan_pln is not null;

begin

    --  Parent "LISTRIK" must exist when inserting a child in "REK_LISTRIK"
    if :new.NO_PELANGGAN_PLN is not null then
       open  cpk1_rek_listrik(:new.NO_PELANGGAN_PLN);
       fetch cpk1_rek_listrik into dummy;
       found := cpk1_rek_listrik%FOUND;
       close cpk1_rek_listrik;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "LISTRIK". Cannot create child in "REK_LISTRIK".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
