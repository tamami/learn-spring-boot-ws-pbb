create trigger TUB_P6
	before update of KD_PROPINSI,KD_DATI2,SIM_THN_DEP_MIN_MAX,KD_FASILITAS,SIM_KLS_DEP_MIN,SIM_KLS_DEP_MAX
	on SIM_FAS_DEP_MIN_MAX
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_sim_fas_dep_min_max(var_kd_propinsi varchar,
                                    var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "FASILITAS"
    cursor cpk2_sim_fas_dep_min_max(var_kd_fasilitas varchar) is
       select 1
       from   FASILITAS
       where  KD_FASILITAS = var_kd_fasilitas
        and   var_kd_fasilitas is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "SIM_FAS_DEP_MIN_MAX"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_sim_fas_dep_min_max(:new.KD_PROPINSI,
                                      :new.KD_DATI2);
       fetch cpk1_sim_fas_dep_min_max into dummy;
       found := cpk1_sim_fas_dep_min_max%FOUND;
       close cpk1_sim_fas_dep_min_max;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "SIM_FAS_DEP_MIN_MAX".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "FASILITAS" must exist when updating a child in "SIM_FAS_DEP_MIN_MAX"
    if (:new.KD_FASILITAS is not null) and (seq = 0) then
       open  cpk2_sim_fas_dep_min_max(:new.KD_FASILITAS);
       fetch cpk2_sim_fas_dep_min_max into dummy;
       found := cpk2_sim_fas_dep_min_max%FOUND;
       close cpk2_sim_fas_dep_min_max;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "FASILITAS". Cannot update child in "SIM_FAS_DEP_MIN_MAX".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
