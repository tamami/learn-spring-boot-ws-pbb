create trigger TUA_E9
	after update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI
	on BANK_PERSEPSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "BANK_PERSEPSI" for all children in "TEMPAT_PEMBAYARAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('KD_BANK_TUNGGAL') and :old.KD_BANK_TUNGGAL != :new.KD_BANK_TUNGGAL) or
       (updating('KD_BANK_PERSEPSI') and :old.KD_BANK_PERSEPSI != :new.KD_BANK_PERSEPSI) then
       update TEMPAT_PEMBAYARAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              KD_BANK_TUNGGAL = :new.KD_BANK_TUNGGAL,
              KD_BANK_PERSEPSI = :new.KD_BANK_PERSEPSI
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
        and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
