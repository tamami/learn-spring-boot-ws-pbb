create trigger TDA_E9
	after delete
	on BANK_PERSEPSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TEMPAT_PEMBAYARAN"
    delete TEMPAT_PEMBAYARAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   KD_BANK_TUNGGAL = :old.KD_BANK_TUNGGAL
     and   KD_BANK_PERSEPSI = :old.KD_BANK_PERSEPSI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
