create trigger TUB_E9
	before update of KD_KANWIL,KD_KPPBB,KD_BANK_TUNGGAL,KD_BANK_PERSEPSI
	on BANK_PERSEPSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BANK_TUNGGAL"
    cursor cpk1_bank_persepsi(var_kd_kanwil varchar,
                              var_kd_kppbb varchar,
                              var_kd_bank_tunggal varchar) is
       select 1
       from   BANK_TUNGGAL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_kd_bank_tunggal is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BANK_TUNGGAL" must exist when updating a child in "BANK_PERSEPSI"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and (seq = 0) then
       open  cpk1_bank_persepsi(:new.KD_KANWIL,
                                :new.KD_KPPBB,
                                :new.KD_BANK_TUNGGAL);
       fetch cpk1_bank_persepsi into dummy;
       found := cpk1_bank_persepsi%FOUND;
       close cpk1_bank_persepsi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BANK_TUNGGAL". Cannot update child in "BANK_PERSEPSI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
