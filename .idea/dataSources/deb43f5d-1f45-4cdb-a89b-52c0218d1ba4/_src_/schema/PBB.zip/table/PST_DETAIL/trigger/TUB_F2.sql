create trigger TUB_F2
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,KD_JNS_PELAYANAN,KD_SEKSI_BERKAS,NIP_PENYERAH
	on PST_DETAIL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JNS_PELAYANAN"
    cursor cpk1_pst_detail(var_kd_jns_pelayanan varchar) is
       select 1
       from   REF_JNS_PELAYANAN
       where  KD_JNS_PELAYANAN = var_kd_jns_pelayanan
        and   var_kd_jns_pelayanan is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_PERMOHONAN"
    cursor cpk2_pst_detail(var_kd_kanwil varchar,
                           var_kd_kppbb varchar,
                           var_thn_pelayanan varchar,
                           var_bundel_pelayanan varchar,
                           var_no_urut_pelayanan varchar) is
       select 1
       from   PST_PERMOHONAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_pst_detail(var_nip_penyerah varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_penyerah
        and   var_nip_penyerah is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_SEKSI"
    cursor cpk4_pst_detail(var_kd_seksi_berkas varchar) is
       select 1
       from   REF_SEKSI
       where  KD_SEKSI = var_kd_seksi_berkas
        and   var_kd_seksi_berkas is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_JNS_PELAYANAN" must exist when updating a child in "PST_DETAIL"
    if (:new.KD_JNS_PELAYANAN is not null) and (seq = 0) then
       open  cpk1_pst_detail(:new.KD_JNS_PELAYANAN);
       fetch cpk1_pst_detail into dummy;
       found := cpk1_pst_detail%FOUND;
       close cpk1_pst_detail;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JNS_PELAYANAN". Cannot update child in "PST_DETAIL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PST_PERMOHONAN" must exist when updating a child in "PST_DETAIL"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and (seq = 0) then
       open  cpk2_pst_detail(:new.KD_KANWIL,
                             :new.KD_KPPBB,
                             :new.THN_PELAYANAN,
                             :new.BUNDEL_PELAYANAN,
                             :new.NO_URUT_PELAYANAN);
       fetch cpk2_pst_detail into dummy;
       found := cpk2_pst_detail%FOUND;
       close cpk2_pst_detail;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_PERMOHONAN". Cannot update child in "PST_DETAIL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PST_DETAIL"
    if (:new.NIP_PENYERAH is not null) and (seq = 0) then
       open  cpk3_pst_detail(:new.NIP_PENYERAH);
       fetch cpk3_pst_detail into dummy;
       found := cpk3_pst_detail%FOUND;
       close cpk3_pst_detail;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PST_DETAIL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_SEKSI" must exist when updating a child in "PST_DETAIL"
    if (:new.KD_SEKSI_BERKAS is not null) and (seq = 0) then
       open  cpk4_pst_detail(:new.KD_SEKSI_BERKAS);
       fetch cpk4_pst_detail into dummy;
       found := cpk4_pst_detail%FOUND;
       close cpk4_pst_detail;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_SEKSI". Cannot update child in "PST_DETAIL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
