create trigger TUA_F2
	after update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,KD_JNS_PELAYANAN,KD_SEKSI_BERKAS,NIP_PENYERAH
	on PST_DETAIL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PST_DETAIL" for all children in "TEMP_DATA_OP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update TEMP_DATA_OP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "PST_PERMOHONAN_PENGURANGAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PST_PERMOHONAN_PENGURANGAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "BERKAS_KIRIM"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update BERKAS_KIRIM
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "SPB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update SPB
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "SKKPP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update SKKPP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "KEPUTUSAN_KEBERATAN_PBB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update KEPUTUSAN_KEBERATAN_PBB
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "PST_DATA_OP_BARU"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PST_DATA_OP_BARU
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "PEMBETULAN_SPPTSKPSTP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PEMBETULAN_SPPTSKPSTP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "PEMBATALAN_SPPTSKPSTP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PEMBATALAN_SPPTSKPSTP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "PEMBETULAN_KEBERATAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PEMBETULAN_KEBERATAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;

    --  Modify parent code of "PST_DETAIL" for all children in "LOG_KELUARAN_PST"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update LOG_KELUARAN_PST
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
