create trigger TDA_F2
	after delete
	on PST_DETAIL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TEMP_DATA_OP"
    delete TEMP_DATA_OP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "PST_PERMOHONAN_PENGURANGAN"
    delete PST_PERMOHONAN_PENGURANGAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "BERKAS_KIRIM"
    delete BERKAS_KIRIM
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "SPB"
    delete SPB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "SKKPP"
    delete SKKPP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "KEPUTUSAN_KEBERATAN_PBB"
    delete KEPUTUSAN_KEBERATAN_PBB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "PST_DATA_OP_BARU"
    delete PST_DATA_OP_BARU
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "PEMBETULAN_SPPTSKPSTP"
    delete PEMBETULAN_SPPTSKPSTP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "PEMBATALAN_SPPTSKPSTP"
    delete PEMBATALAN_SPPTSKPSTP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "PEMBETULAN_KEBERATAN"
    delete PEMBETULAN_KEBERATAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;

    --  Delete all children in "LOG_KELUARAN_PST"
    delete LOG_KELUARAN_PST
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
