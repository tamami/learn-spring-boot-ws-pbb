create trigger TUB_E11
	before update
	on TEMPAT_PEMBAYARAN_SPPT_MASAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "TEMPAT_PEMBAYARAN"
    cursor cpk1_tempat_pembayaran_sppt_ma(var_kd_kanwil varchar,
                                          var_kd_kppbb varchar,
                                          var_kd_bank_tunggal varchar,
                                          var_kd_bank_persepsi varchar,
                                          var_kd_tp varchar) is
       select 1
       from   TEMPAT_PEMBAYARAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   KD_BANK_PERSEPSI = var_kd_bank_persepsi
        and   KD_TP = var_kd_tp
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_kd_bank_tunggal is not null
        and   var_kd_bank_persepsi is not null
        and   var_kd_tp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KELURAHAN"
    cursor cpk2_tempat_pembayaran_sppt_ma(var_kd_propinsi varchar,
                                          var_kd_dati2 varchar,
                                          var_kd_kecamatan varchar,
                                          var_kd_kelurahan varchar) is
       select 1
       from   REF_KELURAHAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "TEMPAT_PEMBAYARAN" must exist when updating a child in "TEMPAT_PEMBAYARAN_SPPT_MASAL"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and
       (:new.KD_BANK_PERSEPSI is not null) and
       (:new.KD_TP is not null) and (seq = 0) then
       open  cpk1_tempat_pembayaran_sppt_ma(:new.KD_KANWIL,
                                            :new.KD_KPPBB,
                                            :new.KD_BANK_TUNGGAL,
                                            :new.KD_BANK_PERSEPSI,
                                            :new.KD_TP);
       fetch cpk1_tempat_pembayaran_sppt_ma into dummy;
       found := cpk1_tempat_pembayaran_sppt_ma%FOUND;
       close cpk1_tempat_pembayaran_sppt_ma;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "TEMPAT_PEMBAYARAN". Cannot update child in "TEMPAT_PEMBAYARAN_SPPT_MASAL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_KELURAHAN" must exist when updating a child in "TEMPAT_PEMBAYARAN_SPPT_MASAL"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and (seq = 0) then
       open  cpk2_tempat_pembayaran_sppt_ma(:new.KD_PROPINSI,
                                            :new.KD_DATI2,
                                            :new.KD_KECAMATAN,
                                            :new.KD_KELURAHAN);
       fetch cpk2_tempat_pembayaran_sppt_ma into dummy;
       found := cpk2_tempat_pembayaran_sppt_ma%FOUND;
       close cpk2_tempat_pembayaran_sppt_ma;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KELURAHAN". Cannot update child in "TEMPAT_PEMBAYARAN_SPPT_MASAL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
