create trigger TUB_C10
	before update of KD_PEKERJAAN,KD_KEGIATAN,LBR_BENT_MIN_HRG_JPB8,LBR_BENT_MAX_HRG_JPB8,TING_KOLOM_MIN_HRG_JPB8,TING_KOLOM_MAX_HRG_JPB8
	on VOL_KEGIATAN_JPB8
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEKERJAAN_KEGIATAN"
    cursor cpk1_vol_kegiatan_jpb8(var_kd_pekerjaan varchar,
                                  var_kd_kegiatan varchar) is
       select 1
       from   PEKERJAAN_KEGIATAN
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PEKERJAAN_KEGIATAN" must exist when updating a child in "VOL_KEGIATAN_JPB8"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and (seq = 0) then
       open  cpk1_vol_kegiatan_jpb8(:new.KD_PEKERJAAN,
                                    :new.KD_KEGIATAN);
       fetch cpk1_vol_kegiatan_jpb8 into dummy;
       found := cpk1_vol_kegiatan_jpb8%FOUND;
       close cpk1_vol_kegiatan_jpb8;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEKERJAAN_KEGIATAN". Cannot update child in "VOL_KEGIATAN_JPB8".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
