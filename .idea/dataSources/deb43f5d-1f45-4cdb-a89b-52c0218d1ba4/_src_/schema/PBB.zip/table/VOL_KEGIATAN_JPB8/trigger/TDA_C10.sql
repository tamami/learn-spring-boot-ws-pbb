create trigger TDA_C10
	after delete
	on VOL_KEGIATAN_JPB8
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "HRG_KEGIATAN_JPB8"
    delete HRG_KEGIATAN_JPB8
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN
     and   LBR_BENT_MIN_HRG_JPB8 = :old.LBR_BENT_MIN_HRG_JPB8
     and   LBR_BENT_MAX_HRG_JPB8 = :old.LBR_BENT_MAX_HRG_JPB8
     and   TING_KOLOM_MIN_HRG_JPB8 = :old.TING_KOLOM_MIN_HRG_JPB8
     and   TING_KOLOM_MAX_HRG_JPB8 = :old.TING_KOLOM_MAX_HRG_JPB8;

    --  Delete all children in "SIM_HRG_KEGIATAN_JPB8"
    delete SIM_HRG_KEGIATAN_JPB8
    where  KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN
     and   LBR_BENT_MIN_HRG_JPB8 = :old.LBR_BENT_MIN_HRG_JPB8
     and   LBR_BENT_MAX_HRG_JPB8 = :old.LBR_BENT_MAX_HRG_JPB8
     and   TING_KOLOM_MIN_HRG_JPB8 = :old.TING_KOLOM_MIN_HRG_JPB8
     and   TING_KOLOM_MAX_HRG_JPB8 = :old.TING_KOLOM_MAX_HRG_JPB8;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
