create trigger TUA_C10
	after update of KD_PEKERJAAN,KD_KEGIATAN,LBR_BENT_MIN_HRG_JPB8,LBR_BENT_MAX_HRG_JPB8,TING_KOLOM_MIN_HRG_JPB8,TING_KOLOM_MAX_HRG_JPB8
	on VOL_KEGIATAN_JPB8
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "VOL_KEGIATAN_JPB8" for all children in "HRG_KEGIATAN_JPB8"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) or
       (updating('LBR_BENT_MIN_HRG_JPB8') and :old.LBR_BENT_MIN_HRG_JPB8 != :new.LBR_BENT_MIN_HRG_JPB8) or
       (updating('LBR_BENT_MAX_HRG_JPB8') and :old.LBR_BENT_MAX_HRG_JPB8 != :new.LBR_BENT_MAX_HRG_JPB8) or
       (updating('TING_KOLOM_MIN_HRG_JPB8') and :old.TING_KOLOM_MIN_HRG_JPB8 != :new.TING_KOLOM_MIN_HRG_JPB8) or
       (updating('TING_KOLOM_MAX_HRG_JPB8') and :old.TING_KOLOM_MAX_HRG_JPB8 != :new.TING_KOLOM_MAX_HRG_JPB8) then
       update HRG_KEGIATAN_JPB8
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN,
              LBR_BENT_MIN_HRG_JPB8 = :new.LBR_BENT_MIN_HRG_JPB8,
              LBR_BENT_MAX_HRG_JPB8 = :new.LBR_BENT_MAX_HRG_JPB8,
              TING_KOLOM_MIN_HRG_JPB8 = :new.TING_KOLOM_MIN_HRG_JPB8,
              TING_KOLOM_MAX_HRG_JPB8 = :new.TING_KOLOM_MAX_HRG_JPB8
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN
        and   LBR_BENT_MIN_HRG_JPB8 = :old.LBR_BENT_MIN_HRG_JPB8
        and   LBR_BENT_MAX_HRG_JPB8 = :old.LBR_BENT_MAX_HRG_JPB8
        and   TING_KOLOM_MIN_HRG_JPB8 = :old.TING_KOLOM_MIN_HRG_JPB8
        and   TING_KOLOM_MAX_HRG_JPB8 = :old.TING_KOLOM_MAX_HRG_JPB8;
    end if;

    --  Modify parent code of "VOL_KEGIATAN_JPB8" for all children in "SIM_HRG_KEGIATAN_JPB8"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) or
       (updating('LBR_BENT_MIN_HRG_JPB8') and :old.LBR_BENT_MIN_HRG_JPB8 != :new.LBR_BENT_MIN_HRG_JPB8) or
       (updating('LBR_BENT_MAX_HRG_JPB8') and :old.LBR_BENT_MAX_HRG_JPB8 != :new.LBR_BENT_MAX_HRG_JPB8) or
       (updating('TING_KOLOM_MIN_HRG_JPB8') and :old.TING_KOLOM_MIN_HRG_JPB8 != :new.TING_KOLOM_MIN_HRG_JPB8) or
       (updating('TING_KOLOM_MAX_HRG_JPB8') and :old.TING_KOLOM_MAX_HRG_JPB8 != :new.TING_KOLOM_MAX_HRG_JPB8) then
       update SIM_HRG_KEGIATAN_JPB8
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN,
              LBR_BENT_MIN_HRG_JPB8 = :new.LBR_BENT_MIN_HRG_JPB8,
              LBR_BENT_MAX_HRG_JPB8 = :new.LBR_BENT_MAX_HRG_JPB8,
              TING_KOLOM_MIN_HRG_JPB8 = :new.TING_KOLOM_MIN_HRG_JPB8,
              TING_KOLOM_MAX_HRG_JPB8 = :new.TING_KOLOM_MAX_HRG_JPB8
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN
        and   LBR_BENT_MIN_HRG_JPB8 = :old.LBR_BENT_MIN_HRG_JPB8
        and   LBR_BENT_MAX_HRG_JPB8 = :old.LBR_BENT_MAX_HRG_JPB8
        and   TING_KOLOM_MIN_HRG_JPB8 = :old.TING_KOLOM_MIN_HRG_JPB8
        and   TING_KOLOM_MAX_HRG_JPB8 = :old.TING_KOLOM_MAX_HRG_JPB8;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
