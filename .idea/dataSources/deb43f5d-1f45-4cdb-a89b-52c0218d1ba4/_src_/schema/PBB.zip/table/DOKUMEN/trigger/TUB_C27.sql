create trigger TUB_C27
	before update of KD_KANWIL,KD_KPPBB,JNS_DOKUMEN,NO_DOKUMEN,NIP_PENDATA_DOK,NIP_PEMERIKSA_DOK,NIP_PEREKAM_DOK
	on DOKUMEN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk1_dokumen(var_kd_kanwil varchar,
                        var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_dokumen(var_nip_pendata_dok varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pendata_dok
        and   var_nip_pendata_dok is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_dokumen(var_nip_pemeriksa_dok varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pemeriksa_dok
        and   var_nip_pemeriksa_dok is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk4_dokumen(var_nip_perekam_dok varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam_dok
        and   var_nip_perekam_dok is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KPPBB" must exist when updating a child in "DOKUMEN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk1_dokumen(:new.KD_KANWIL,
                          :new.KD_KPPBB);
       fetch cpk1_dokumen into dummy;
       found := cpk1_dokumen%FOUND;
       close cpk1_dokumen;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "DOKUMEN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DOKUMEN"
    if (:new.NIP_PENDATA_DOK is not null) and (seq = 0) then
       open  cpk2_dokumen(:new.NIP_PENDATA_DOK);
       fetch cpk2_dokumen into dummy;
       found := cpk2_dokumen%FOUND;
       close cpk2_dokumen;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DOKUMEN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DOKUMEN"
    if (:new.NIP_PEMERIKSA_DOK is not null) and (seq = 0) then
       open  cpk3_dokumen(:new.NIP_PEMERIKSA_DOK);
       fetch cpk3_dokumen into dummy;
       found := cpk3_dokumen%FOUND;
       close cpk3_dokumen;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DOKUMEN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "DOKUMEN"
    if (:new.NIP_PEREKAM_DOK is not null) and (seq = 0) then
       open  cpk4_dokumen(:new.NIP_PEREKAM_DOK);
       fetch cpk4_dokumen into dummy;
       found := cpk4_dokumen%FOUND;
       close cpk4_dokumen;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "DOKUMEN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
