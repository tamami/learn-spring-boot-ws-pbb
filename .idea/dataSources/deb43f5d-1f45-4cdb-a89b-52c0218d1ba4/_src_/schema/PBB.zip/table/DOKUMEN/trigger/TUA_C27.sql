create trigger TUA_C27
	after update of KD_KANWIL,KD_KPPBB,JNS_DOKUMEN,NO_DOKUMEN,NIP_PENDATA_DOK,NIP_PEMERIKSA_DOK,NIP_PEREKAM_DOK
	on DOKUMEN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DOKUMEN" for all children in "HRG_RESOURCE"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_DOKUMEN') and :old.JNS_DOKUMEN != :new.JNS_DOKUMEN) or
       (updating('NO_DOKUMEN') and :old.NO_DOKUMEN != :new.NO_DOKUMEN) then
       update HRG_RESOURCE
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_DOKUMEN = :new.JNS_DOKUMEN,
              NO_DOKUMEN = :new.NO_DOKUMEN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_DOKUMEN = :old.JNS_DOKUMEN
        and   NO_DOKUMEN = :old.NO_DOKUMEN;
    end if;

    --  Modify parent code of "DOKUMEN" for all children in "DAT_NIR"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_DOKUMEN') and :old.JNS_DOKUMEN != :new.JNS_DOKUMEN) or
       (updating('NO_DOKUMEN') and :old.NO_DOKUMEN != :new.NO_DOKUMEN) then
       update DAT_NIR
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_DOKUMEN = :new.JNS_DOKUMEN,
              NO_DOKUMEN = :new.NO_DOKUMEN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_DOKUMEN = :old.JNS_DOKUMEN
        and   NO_DOKUMEN = :old.NO_DOKUMEN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
