create trigger TUB_C30
	before update of KD_PROPINSI,KD_DATI2,THN_DBKB_JPB4,KLS_DBKB_JPB4,LANTAI_MIN_JPB4,LANTAI_MAX_JPB4
	on DBKB_JPB4
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_dbkb_jpb4(var_kd_propinsi varchar,
                          var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "DBKB_JPB4"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_dbkb_jpb4(:new.KD_PROPINSI,
                            :new.KD_DATI2);
       fetch cpk1_dbkb_jpb4 into dummy;
       found := cpk1_dbkb_jpb4%FOUND;
       close cpk1_dbkb_jpb4;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "DBKB_JPB4".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
