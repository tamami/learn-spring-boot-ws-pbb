create trigger TUB_REK_PAM
	before update of NO_PELANGGAN_PAM,THN_PAM,BULAN_KE_PAM
	on REK_PAM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PAM"
    cursor cpk1_rek_pam(var_no_pelanggan_pam varchar) is
       select 1
       from   PAM
       where  NO_PELANGGAN_PAM = var_no_pelanggan_pam
        and   var_no_pelanggan_pam is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PAM" must exist when updating a child in "REK_PAM"
    if (:new.NO_PELANGGAN_PAM is not null) and (seq = 0) then
       open  cpk1_rek_pam(:new.NO_PELANGGAN_PAM);
       fetch cpk1_rek_pam into dummy;
       found := cpk1_rek_pam%FOUND;
       close cpk1_rek_pam;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PAM". Cannot update child in "REK_PAM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
