create trigger TIB_REK_PAM
	before insert
	on REK_PAM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "PAM"
    cursor cpk1_rek_pam(var_no_pelanggan_pam varchar) is
       select 1
       from   PAM
       where  NO_PELANGGAN_PAM = var_no_pelanggan_pam
        and   var_no_pelanggan_pam is not null;

begin

    --  Parent "PAM" must exist when inserting a child in "REK_PAM"
    if :new.NO_PELANGGAN_PAM is not null then
       open  cpk1_rek_pam(:new.NO_PELANGGAN_PAM);
       fetch cpk1_rek_pam into dummy;
       found := cpk1_rek_pam%FOUND;
       close cpk1_rek_pam;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PAM". Cannot create child in "REK_PAM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
