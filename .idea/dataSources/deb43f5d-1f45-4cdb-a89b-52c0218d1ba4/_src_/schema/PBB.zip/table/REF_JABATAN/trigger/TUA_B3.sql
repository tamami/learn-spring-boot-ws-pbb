create trigger TUA_B3
	after update of KD_JABATAN
	on REF_JABATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_JABATAN" for all children in "POSISI_PEGAWAI"
    if (updating('KD_JABATAN') and :old.KD_JABATAN != :new.KD_JABATAN) then
       update POSISI_PEGAWAI
        set   KD_JABATAN = :new.KD_JABATAN
       where  KD_JABATAN = :old.KD_JABATAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
