create trigger TUB_X14
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BNG,HIS_INDEKS_NILAI_INDIVIDU,HIS_NIP_PENILAI_INDIVIDU,HIS_NIP_PEREKAM_INDIVIDU
	on HIS_NILAI_INDIVIDU
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_NILAI_INDIVIDU"
    cursor cpk1_his_nilai_individu(var_kd_propinsi varchar,
                                   var_kd_dati2 varchar,
                                   var_kd_kecamatan varchar,
                                   var_kd_kelurahan varchar,
                                   var_kd_blok varchar,
                                   var_no_urut varchar,
                                   var_kd_jns_op varchar,
                                   var_no_bng number) is
       select 1
       from   DAT_NILAI_INDIVIDU
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   NO_BNG = var_no_bng
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_no_bng is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_his_nilai_individu(var_his_nip_perekam_individu varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_his_nip_perekam_individu
        and   var_his_nip_perekam_individu is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_his_nilai_individu(var_his_nip_penilai_individu varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_his_nip_penilai_individu
        and   var_his_nip_penilai_individu is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "DAT_NILAI_INDIVIDU" must exist when updating a child in "HIS_NILAI_INDIVIDU"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.NO_BNG is not null) and (seq = 0) then
       open  cpk1_his_nilai_individu(:new.KD_PROPINSI,
                                     :new.KD_DATI2,
                                     :new.KD_KECAMATAN,
                                     :new.KD_KELURAHAN,
                                     :new.KD_BLOK,
                                     :new.NO_URUT,
                                     :new.KD_JNS_OP,
                                     :new.NO_BNG);
       fetch cpk1_his_nilai_individu into dummy;
       found := cpk1_his_nilai_individu%FOUND;
       close cpk1_his_nilai_individu;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_NILAI_INDIVIDU". Cannot update child in "HIS_NILAI_INDIVIDU".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "HIS_NILAI_INDIVIDU"
    if (:new.HIS_NIP_PEREKAM_INDIVIDU is not null) and (seq = 0) then
       open  cpk2_his_nilai_individu(:new.HIS_NIP_PEREKAM_INDIVIDU);
       fetch cpk2_his_nilai_individu into dummy;
       found := cpk2_his_nilai_individu%FOUND;
       close cpk2_his_nilai_individu;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "HIS_NILAI_INDIVIDU".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "HIS_NILAI_INDIVIDU"
    if (:new.HIS_NIP_PENILAI_INDIVIDU is not null) and (seq = 0) then
       open  cpk3_his_nilai_individu(:new.HIS_NIP_PENILAI_INDIVIDU);
       fetch cpk3_his_nilai_individu into dummy;
       found := cpk3_his_nilai_individu%FOUND;
       close cpk3_his_nilai_individu;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "HIS_NILAI_INDIVIDU".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
