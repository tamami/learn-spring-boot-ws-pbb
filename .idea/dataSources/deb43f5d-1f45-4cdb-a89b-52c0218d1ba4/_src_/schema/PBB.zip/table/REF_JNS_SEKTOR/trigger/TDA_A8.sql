create trigger TDA_A8
	after delete
	on REF_JNS_SEKTOR
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PROGNOSA"
    delete PROGNOSA
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "PENERIMAAN"
    delete PENERIMAAN
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "REF_KELURAHAN"
    delete REF_KELURAHAN
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "SIM_PBB_SUM"
    delete SIM_PBB_SUM
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "SIM_TARGET"
    delete SIM_TARGET
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "SIM_POTENSI_PENERIMAAN"
    delete SIM_POTENSI_PENERIMAAN
    where  KD_SEKTOR = :old.KD_SEKTOR;

    --  Delete all children in "COLLECTION_RATIO"
    delete COLLECTION_RATIO
    where  KD_SEKTOR = :old.KD_SEKTOR;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
