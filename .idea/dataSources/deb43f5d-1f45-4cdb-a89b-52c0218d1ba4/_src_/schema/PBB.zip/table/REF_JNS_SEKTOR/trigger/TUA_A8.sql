create trigger TUA_A8
	after update of KD_SEKTOR
	on REF_JNS_SEKTOR
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "PROGNOSA"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update PROGNOSA
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "PENERIMAAN"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update PENERIMAAN
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "REF_KELURAHAN"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update REF_KELURAHAN
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "SIM_PBB_SUM"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update SIM_PBB_SUM
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "SIM_TARGET"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update SIM_TARGET
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "SIM_POTENSI_PENERIMAAN"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update SIM_POTENSI_PENERIMAAN
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;

    --  Modify parent code of "REF_JNS_SEKTOR" for all children in "COLLECTION_RATIO"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) then
       update COLLECTION_RATIO
        set   KD_SEKTOR = :new.KD_SEKTOR
       where  KD_SEKTOR = :old.KD_SEKTOR;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
