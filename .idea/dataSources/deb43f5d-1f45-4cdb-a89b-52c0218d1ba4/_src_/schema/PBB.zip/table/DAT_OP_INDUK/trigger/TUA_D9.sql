create trigger TUA_D9
	after update
	on DAT_OP_INDUK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_OP_INDUK" for all children in "DAT_OP_ANGGOTA"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) then
       update DAT_OP_ANGGOTA
        set   KD_PROPINSI_INDUK = :new.KD_PROPINSI,
              KD_DATI2_INDUK = :new.KD_DATI2,
              KD_KECAMATAN_INDUK = :new.KD_KECAMATAN,
              KD_KELURAHAN_INDUK = :new.KD_KELURAHAN,
              KD_BLOK_INDUK = :new.KD_BLOK,
              NO_URUT_INDUK = :new.NO_URUT,
              KD_JNS_OP_INDUK = :new.KD_JNS_OP
       where  KD_PROPINSI_INDUK = :old.KD_PROPINSI
        and   KD_DATI2_INDUK = :old.KD_DATI2
        and   KD_KECAMATAN_INDUK = :old.KD_KECAMATAN
        and   KD_KELURAHAN_INDUK = :old.KD_KELURAHAN
        and   KD_BLOK_INDUK = :old.KD_BLOK
        and   NO_URUT_INDUK = :old.NO_URUT
        and   KD_JNS_OP_INDUK = :old.KD_JNS_OP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
