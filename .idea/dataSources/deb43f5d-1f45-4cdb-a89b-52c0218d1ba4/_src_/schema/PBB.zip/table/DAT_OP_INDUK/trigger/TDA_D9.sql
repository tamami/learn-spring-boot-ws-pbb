create trigger TDA_D9
	after delete
	on DAT_OP_INDUK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_OP_ANGGOTA"
    delete DAT_OP_ANGGOTA
    where  KD_PROPINSI_INDUK = :old.KD_PROPINSI
     and   KD_DATI2_INDUK = :old.KD_DATI2
     and   KD_KECAMATAN_INDUK = :old.KD_KECAMATAN
     and   KD_KELURAHAN_INDUK = :old.KD_KELURAHAN
     and   KD_BLOK_INDUK = :old.KD_BLOK
     and   NO_URUT_INDUK = :old.NO_URUT
     and   KD_JNS_OP_INDUK = :old.KD_JNS_OP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
