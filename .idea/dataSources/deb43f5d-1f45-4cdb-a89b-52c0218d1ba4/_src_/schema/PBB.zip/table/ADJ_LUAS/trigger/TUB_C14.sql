create trigger TUB_C14
	before update of KD_JPB,TIPE_BNG,KD_BNG_LANTAI
	on ADJ_LUAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BANGUNAN_LANTAI"
    cursor cpk1_adj_luas(var_kd_jpb varchar,
                         var_tipe_bng varchar,
                         var_kd_bng_lantai varchar) is
       select 1
       from   BANGUNAN_LANTAI
       where  KD_JPB = var_kd_jpb
        and   TIPE_BNG = var_tipe_bng
        and   KD_BNG_LANTAI = var_kd_bng_lantai
        and   var_kd_jpb is not null
        and   var_tipe_bng is not null
        and   var_kd_bng_lantai is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BANGUNAN_LANTAI" must exist when updating a child in "ADJ_LUAS"
    if (:new.KD_JPB is not null) and
       (:new.TIPE_BNG is not null) and
       (:new.KD_BNG_LANTAI is not null) and (seq = 0) then
       open  cpk1_adj_luas(:new.KD_JPB,
                           :new.TIPE_BNG,
                           :new.KD_BNG_LANTAI);
       fetch cpk1_adj_luas into dummy;
       found := cpk1_adj_luas%FOUND;
       close cpk1_adj_luas;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BANGUNAN_LANTAI". Cannot update child in "ADJ_LUAS".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
