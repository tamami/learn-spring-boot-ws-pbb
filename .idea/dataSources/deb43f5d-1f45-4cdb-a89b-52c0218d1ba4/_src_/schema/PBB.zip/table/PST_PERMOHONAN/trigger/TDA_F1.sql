create trigger TDA_F1
	after delete
	on PST_PERMOHONAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PST_LAMPIRAN"
    delete PST_LAMPIRAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN;

    --  Delete all children in "PST_DETAIL"
    delete PST_DETAIL
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN;

     IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
