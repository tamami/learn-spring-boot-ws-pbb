create trigger TUA_F1
	after update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,NIP_PENERIMA
	on PST_PERMOHONAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PST_PERMOHONAN" for all children in "PST_LAMPIRAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) then
       update PST_LAMPIRAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN;
    end if;

    --  Modify parent code of "PST_PERMOHONAN" for all children in "PST_DETAIL"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) then
       update PST_DETAIL
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN = :new.NO_URUT_PELAYANAN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN;
    end if;


    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
