create trigger TUA_F3
	after update of KD_JNS_PELAYANAN
	on REF_JNS_PELAYANAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_JNS_PELAYANAN" for all children in "PST_DETAIL"
    if (updating('KD_JNS_PELAYANAN') and :old.KD_JNS_PELAYANAN != :new.KD_JNS_PELAYANAN) then
       update PST_DETAIL
        set   KD_JNS_PELAYANAN = :new.KD_JNS_PELAYANAN
       where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;
    end if;

    --  Modify parent code of "REF_JNS_PELAYANAN" for all children in "KELUARAN_PST"
    if (updating('KD_JNS_PELAYANAN') and :old.KD_JNS_PELAYANAN != :new.KD_JNS_PELAYANAN) then
       update KELUARAN_PST
        set   KD_JNS_PELAYANAN = :new.KD_JNS_PELAYANAN
       where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;
    end if;

    --  Modify parent code of "REF_JNS_PELAYANAN" for all children in "LOG_KELUARAN_PST"
    if (updating('KD_JNS_PELAYANAN') and :old.KD_JNS_PELAYANAN != :new.KD_JNS_PELAYANAN) then
       update LOG_KELUARAN_PST
        set   KD_JNS_PELAYANAN = :new.KD_JNS_PELAYANAN
       where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
