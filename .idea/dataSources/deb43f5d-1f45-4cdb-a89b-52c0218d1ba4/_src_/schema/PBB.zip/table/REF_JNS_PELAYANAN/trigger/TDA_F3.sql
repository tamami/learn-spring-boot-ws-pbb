create trigger TDA_F3
	after delete
	on REF_JNS_PELAYANAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PST_DETAIL"
    delete PST_DETAIL
    where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;

    --  Delete all children in "KELUARAN_PST"
    delete KELUARAN_PST
    where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;

    --  Delete all children in "LOG_KELUARAN_PST"
    delete LOG_KELUARAN_PST
    where  KD_JNS_PELAYANAN = :old.KD_JNS_PELAYANAN;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
