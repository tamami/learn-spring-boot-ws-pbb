create trigger TUB_D2
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_ZNT,THN_NIR_ZNT,KD_KANWIL,KD_KPPBB,JNS_DOKUMEN,NO_DOKUMEN
	on DAT_NIR
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "DOKUMEN"
    cursor cpk1_dat_nir(var_kd_kanwil varchar,
                        var_kd_kppbb varchar,
                        var_jns_dokumen varchar,
                        var_no_dokumen varchar) is
       select 1
       from   DOKUMEN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   JNS_DOKUMEN = var_jns_dokumen
        and   NO_DOKUMEN = var_no_dokumen
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_jns_dokumen is not null
        and   var_no_dokumen is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_ZNT"
    cursor cpk2_dat_nir(var_kd_propinsi varchar,
                        var_kd_dati2 varchar,
                        var_kd_kecamatan varchar,
                        var_kd_kelurahan varchar,
                        var_kd_znt varchar) is
       select 1
       from   DAT_ZNT
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_ZNT = var_kd_znt
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_znt is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "DOKUMEN" must exist when updating a child in "DAT_NIR"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.JNS_DOKUMEN is not null) and
       (:new.NO_DOKUMEN is not null) and (seq = 0) then
       open  cpk1_dat_nir(:new.KD_KANWIL,
                          :new.KD_KPPBB,
                          :new.JNS_DOKUMEN,
                          :new.NO_DOKUMEN);
       fetch cpk1_dat_nir into dummy;
       found := cpk1_dat_nir%FOUND;
       close cpk1_dat_nir;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DOKUMEN". Cannot update child in "DAT_NIR".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_ZNT" must exist when updating a child in "DAT_NIR"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_ZNT is not null) and (seq = 0) then
       open  cpk2_dat_nir(:new.KD_PROPINSI,
                          :new.KD_DATI2,
                          :new.KD_KECAMATAN,
                          :new.KD_KELURAHAN,
                          :new.KD_ZNT);
       fetch cpk2_dat_nir into dummy;
       found := cpk2_dat_nir%FOUND;
       close cpk2_dat_nir;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_ZNT". Cannot update child in "DAT_NIR".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
