create trigger TUB_COMP_PORTO
	before update of MFNPWP_COMP,MFKPP_COMP,MFCAB_COMP,TAHUN_PORTO,KD_STAT_FIN_REP,KD_PENDAPAT
	on COMP_PORTO
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "COMP_PROFILE"
    cursor cpk1_comp_porto(var_mfnpwp_comp varchar,
                           var_mfkpp_comp varchar,
                           var_mfcab_comp varchar) is
       select 1
       from   COMP_PROFILE
       where  MFNPWP_COMP = var_mfnpwp_comp
        and   MFKPP_COMP = var_mfkpp_comp
        and   MFCAB_COMP = var_mfcab_comp
        and   var_mfnpwp_comp is not null
        and   var_mfkpp_comp is not null
        and   var_mfcab_comp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "STAT_FIN_REPORT"
    cursor cpk2_comp_porto(var_kd_stat_fin_rep varchar) is
       select 1
       from   STAT_FIN_REPORT
       where  KD_STAT_FIN_REP = var_kd_stat_fin_rep
        and   var_kd_stat_fin_rep is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENDAPAT_FIN_REP"
    cursor cpk3_comp_porto(var_kd_pendapat varchar) is
       select 1
       from   PENDAPAT_FIN_REP
       where  KD_PENDAPAT = var_kd_pendapat
        and   var_kd_pendapat is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "COMP_PROFILE" must exist when updating a child in "COMP_PORTO"
    if (:new.MFNPWP_COMP is not null) and
       (:new.MFKPP_COMP is not null) and
       (:new.MFCAB_COMP is not null) and (seq = 0) then
       open  cpk1_comp_porto(:new.MFNPWP_COMP,
                             :new.MFKPP_COMP,
                             :new.MFCAB_COMP);
       fetch cpk1_comp_porto into dummy;
       found := cpk1_comp_porto%FOUND;
       close cpk1_comp_porto;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "COMP_PROFILE". Cannot update child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "STAT_FIN_REPORT" must exist when updating a child in "COMP_PORTO"
    if (:new.KD_STAT_FIN_REP is not null) and (seq = 0) then
       open  cpk2_comp_porto(:new.KD_STAT_FIN_REP);
       fetch cpk2_comp_porto into dummy;
       found := cpk2_comp_porto%FOUND;
       close cpk2_comp_porto;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "STAT_FIN_REPORT". Cannot update child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PENDAPAT_FIN_REP" must exist when updating a child in "COMP_PORTO"
    if (:new.KD_PENDAPAT is not null) and (seq = 0) then
       open  cpk3_comp_porto(:new.KD_PENDAPAT);
       fetch cpk3_comp_porto into dummy;
       found := cpk3_comp_porto%FOUND;
       close cpk3_comp_porto;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENDAPAT_FIN_REP". Cannot update child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
