create trigger TIB_COMP_PORTO
	before insert
	on COMP_PORTO
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "COMP_PROFILE"
    cursor cpk1_comp_porto(var_mfnpwp_comp varchar,
                           var_mfkpp_comp varchar,
                           var_mfcab_comp varchar) is
       select 1
       from   COMP_PROFILE
       where  MFNPWP_COMP = var_mfnpwp_comp
        and   MFKPP_COMP = var_mfkpp_comp
        and   MFCAB_COMP = var_mfcab_comp
        and   var_mfnpwp_comp is not null
        and   var_mfkpp_comp is not null
        and   var_mfcab_comp is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "STAT_FIN_REPORT"
    cursor cpk2_comp_porto(var_kd_stat_fin_rep varchar) is
       select 1
       from   STAT_FIN_REPORT
       where  KD_STAT_FIN_REP = var_kd_stat_fin_rep
        and   var_kd_stat_fin_rep is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "PENDAPAT_FIN_REP"
    cursor cpk3_comp_porto(var_kd_pendapat varchar) is
       select 1
       from   PENDAPAT_FIN_REP
       where  KD_PENDAPAT = var_kd_pendapat
        and   var_kd_pendapat is not null;

begin

    --  Parent "COMP_PROFILE" must exist when inserting a child in "COMP_PORTO"
    if :new.MFNPWP_COMP is not null and
       :new.MFKPP_COMP is not null and
       :new.MFCAB_COMP is not null then
       open  cpk1_comp_porto(:new.MFNPWP_COMP,
                             :new.MFKPP_COMP,
                             :new.MFCAB_COMP);
       fetch cpk1_comp_porto into dummy;
       found := cpk1_comp_porto%FOUND;
       close cpk1_comp_porto;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "COMP_PROFILE". Cannot create child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "STAT_FIN_REPORT" must exist when inserting a child in "COMP_PORTO"
    if :new.KD_STAT_FIN_REP is not null then
       open  cpk2_comp_porto(:new.KD_STAT_FIN_REP);
       fetch cpk2_comp_porto into dummy;
       found := cpk2_comp_porto%FOUND;
       close cpk2_comp_porto;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "STAT_FIN_REPORT". Cannot create child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PENDAPAT_FIN_REP" must exist when inserting a child in "COMP_PORTO"
    if :new.KD_PENDAPAT is not null then
       open  cpk3_comp_porto(:new.KD_PENDAPAT);
       fetch cpk3_comp_porto into dummy;
       found := cpk3_comp_porto%FOUND;
       close cpk3_comp_porto;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PENDAPAT_FIN_REP". Cannot create child in "COMP_PORTO".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
