create trigger TDA_F7
	after delete
	on BERKAS_KIRIM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "BERKAS_TERIMA"
    delete BERKAS_TERIMA
    where  KD_SEKSI = :old.KD_SEKSI
     and   KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON
     and   NO_AGENDA_KIRIM = :old.NO_AGENDA_KIRIM
     and   THN_AGENDA_KIRIM = :old.THN_AGENDA_KIRIM;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
