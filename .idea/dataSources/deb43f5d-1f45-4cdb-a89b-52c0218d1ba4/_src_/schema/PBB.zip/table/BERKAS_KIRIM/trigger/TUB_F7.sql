create trigger TUB_F7
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,KD_SEKSI,THN_AGENDA_KIRIM,NO_AGENDA_KIRIM,NIP_PENGIRIM_BERKAS
	on BERKAS_KIRIM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_SEKSI"
    cursor cpk1_berkas_kirim(var_kd_seksi varchar) is
       select 1
       from   REF_SEKSI
       where  KD_SEKSI = var_kd_seksi
        and   var_kd_seksi is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_DETAIL"
    cursor cpk2_berkas_kirim(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_thn_pelayanan varchar,
                             var_bundel_pelayanan varchar,
                             var_no_urut_pelayanan varchar,
                             var_kd_propinsi_pemohon varchar,
                             var_kd_dati2_pemohon varchar,
                             var_kd_kecamatan_pemohon varchar,
                             var_kd_kelurahan_pemohon varchar,
                             var_kd_blok_pemohon varchar,
                             var_no_urut_pemohon varchar,
                             var_kd_jns_op_pemohon varchar) is
       select 1
       from   PST_DETAIL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_berkas_kirim(var_nip_pengirim_berkas varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pengirim_berkas
        and   var_nip_pengirim_berkas is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_SEKSI" must exist when updating a child in "BERKAS_KIRIM"
    if (:new.KD_SEKSI is not null) and (seq = 0) then
       open  cpk1_berkas_kirim(:new.KD_SEKSI);
       fetch cpk1_berkas_kirim into dummy;
       found := cpk1_berkas_kirim%FOUND;
       close cpk1_berkas_kirim;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_SEKSI". Cannot update child in "BERKAS_KIRIM".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PST_DETAIL" must exist when updating a child in "BERKAS_KIRIM"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk2_berkas_kirim(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.THN_PELAYANAN,
                               :new.BUNDEL_PELAYANAN,
                               :new.NO_URUT_PELAYANAN,
                               :new.KD_PROPINSI_PEMOHON,
                               :new.KD_DATI2_PEMOHON,
                               :new.KD_KECAMATAN_PEMOHON,
                               :new.KD_KELURAHAN_PEMOHON,
                               :new.KD_BLOK_PEMOHON,
                               :new.NO_URUT_PEMOHON,
                               :new.KD_JNS_OP_PEMOHON);
       fetch cpk2_berkas_kirim into dummy;
       found := cpk2_berkas_kirim%FOUND;
       close cpk2_berkas_kirim;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_DETAIL". Cannot update child in "BERKAS_KIRIM".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "BERKAS_KIRIM"
    if (:new.NIP_PENGIRIM_BERKAS is not null) and (seq = 0) then
       open  cpk3_berkas_kirim(:new.NIP_PENGIRIM_BERKAS);
       fetch cpk3_berkas_kirim into dummy;
       found := cpk3_berkas_kirim%FOUND;
       close cpk3_berkas_kirim;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "BERKAS_KIRIM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
