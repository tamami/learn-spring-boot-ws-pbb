create trigger TUB_REF_PBI
	before update of KD_PEBIN,KD_PBI
	on REF_PBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_PEBIN"
    cursor cpk1_ref_pbi(var_kd_pebin varchar) is
       select 1
       from   REF_PEBIN
       where  KD_PEBIN = var_kd_pebin
        and   var_kd_pebin is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_PEBIN" must exist when updating a child in "REF_PBI"
    if (:new.KD_PEBIN is not null) and (seq = 0) then
       open  cpk1_ref_pbi(:new.KD_PEBIN);
       fetch cpk1_ref_pbi into dummy;
       found := cpk1_ref_pbi%FOUND;
       close cpk1_ref_pbi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_PEBIN". Cannot update child in "REF_PBI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
