create trigger TDA_REF_PBI
	after delete
	on REF_PBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "REF_PPBI"
    delete REF_PPBI
    where  KD_PEBIN = :old.KD_PEBIN
     and   KD_PBI = :old.KD_PBI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
