create trigger TUA_REF_PBI
	after update of KD_PEBIN,KD_PBI
	on REF_PBI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_PBI" for all children in "REF_PPBI"
    if (updating('KD_PEBIN') and :old.KD_PEBIN != :new.KD_PEBIN) or
       (updating('KD_PBI') and :old.KD_PBI != :new.KD_PBI) then
       update REF_PPBI
        set   KD_PEBIN = :new.KD_PEBIN,
              KD_PBI = :new.KD_PBI
       where  KD_PEBIN = :old.KD_PEBIN
        and   KD_PBI = :old.KD_PBI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
