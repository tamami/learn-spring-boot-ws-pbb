create trigger TUB_A9
	before update of KD_PROPINSI,KD_DATI2,THN_SK_KANWIL,NIP_PENCETAK_SK_KANWIL
	on SK_KANWIL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_sk_kanwil(var_kd_propinsi varchar,
                          var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_sk_kanwil(var_nip_pencetak_sk_kanwil varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_sk_kanwil
        and   var_nip_pencetak_sk_kanwil is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "SK_KANWIL"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_sk_kanwil(:new.KD_PROPINSI,
                            :new.KD_DATI2);
       fetch cpk1_sk_kanwil into dummy;
       found := cpk1_sk_kanwil%FOUND;
       close cpk1_sk_kanwil;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "SK_KANWIL".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SK_KANWIL"
    if (:new.NIP_PENCETAK_SK_KANWIL is not null) and (seq = 0) then
       open  cpk2_sk_kanwil(:new.NIP_PENCETAK_SK_KANWIL);
       fetch cpk2_sk_kanwil into dummy;
       found := cpk2_sk_kanwil%FOUND;
       close cpk2_sk_kanwil;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SK_KANWIL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
