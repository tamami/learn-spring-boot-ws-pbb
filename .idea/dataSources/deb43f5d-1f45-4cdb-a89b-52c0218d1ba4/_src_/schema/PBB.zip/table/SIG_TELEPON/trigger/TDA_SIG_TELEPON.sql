create trigger TDA_SIG_TELEPON
	after delete
	on SIG_TELEPON
	for each row
DECLARE
    integrity_error  EXCEPTION;
    errno            INTEGER;
    errmsg           CHAR(200);
    dummy            INTEGER;
    found            BOOLEAN;
BEGIN
    Integritypackage.NextNestLevel;

   --  Delete all children in "SIG_TELEPON_TAGIHAN"
    delete SIG_TELEPON_TAGIHAN
    WHERE KD_PROPINSI = :OLD.KD_PROPINSI AND
		  KD_DATI2 = :OLD.KD_DATI2 AND
		  KD_KECAMATAN = :OLD.KD_KECAMATAN AND
		  KD_KELURAHAN = :OLD.KD_KELURAHAN AND
		  KD_BLOK = :OLD.KD_BLOK AND
		  NO_URUT = :OLD.NO_URUT AND
		  KD_JNS_OP = :OLD.KD_JNS_OP;

    Integritypackage.PreviousNestLevel;
--  Errors handling
EXCEPTION
    WHEN integrity_error THEN
       BEGIN
       Integritypackage.InitNestLevel;
       RAISE_APPLICATION_ERROR(errno, errmsg);
       END;
END;
