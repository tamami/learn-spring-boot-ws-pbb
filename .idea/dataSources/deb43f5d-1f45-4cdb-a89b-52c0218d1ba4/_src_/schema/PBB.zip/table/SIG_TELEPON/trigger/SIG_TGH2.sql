create trigger SIG_TGH2
	after update of KODE_AREA,NO_TELEPON
	on SIG_TELEPON
	for each row
DECLARE
    integrity_error  EXCEPTION;
    errno            INTEGER;
    errmsg           CHAR(200);
    dummy            INTEGER;
    found            BOOLEAN;
BEGIN
    Integritypackage.NextNestLevel;
    --  Modify parent code of "SIG_TELEPON" for all children in "SIG_TELEPON_TAGIHAN"

	IF (UPDATING('KODE_AREA') AND :OLD.KODE_AREA != :NEW.KODE_AREA) OR
	   (UPDATING('NO_TELEPON') AND :OLD.NO_TELEPON != :NEW.NO_TELEPON) THEN
        UPDATE SIG_TELEPON_TAGIHAN
        SET KODE_AREA = :NEW.KODE_AREA,
      		NO_TELEPON = :NEW.NO_TELEPON

	    WHERE
		  KD_PROPINSI = :OLD.KD_PROPINSI AND
		  KD_DATI2 = :OLD.KD_DATI2 AND
		  KD_KECAMATAN = :OLD.KD_KECAMATAN AND
		  KD_KELURAHAN = :OLD.KD_KELURAHAN AND
		  KD_BLOK = :OLD.KD_BLOK AND
		  NO_URUT = :OLD.NO_URUT AND
		  KD_JNS_OP = :OLD.KD_JNS_OP AND
		  KODE_AREA = :OLD.KODE_AREA AND
		  NO_TELEPON = :OLD.NO_TELEPON;


	END IF;
    Integritypackage.PreviousNestLevel;
--  Errors handling
EXCEPTION
    WHEN integrity_error THEN
       BEGIN
       Integritypackage.InitNestLevel;
       RAISE_APPLICATION_ERROR(errno, errmsg);
       END;
END;
