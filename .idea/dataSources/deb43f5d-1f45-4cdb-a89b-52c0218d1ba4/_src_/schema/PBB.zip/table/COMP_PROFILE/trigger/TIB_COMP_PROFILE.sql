create trigger TIB_COMP_PROFILE
	before insert
	on COMP_PROFILE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "JNS_STATUS_KANTOR"
    cursor cpk1_comp_profile(var_kd_stat_kantor varchar) is
       select 1
       from   JNS_STATUS_KANTOR
       where  KD_STAT_KANTOR = var_kd_stat_kantor
        and   var_kd_stat_kantor is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "JNS_USAHA"
    cursor cpk2_comp_profile(var_kd_jns_usaha varchar) is
       select 1
       from   JNS_USAHA
       where  KD_JNS_USAHA = var_kd_jns_usaha
        and   var_kd_jns_usaha is not null;

begin

    --  Parent "JNS_STATUS_KANTOR" must exist when inserting a child in "COMP_PROFILE"
    if :new.KD_STAT_KANTOR is not null then
       open  cpk1_comp_profile(:new.KD_STAT_KANTOR);
       fetch cpk1_comp_profile into dummy;
       found := cpk1_comp_profile%FOUND;
       close cpk1_comp_profile;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "JNS_STATUS_KANTOR". Cannot create child in "COMP_PROFILE".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "JNS_USAHA" must exist when inserting a child in "COMP_PROFILE"
    if :new.KD_JNS_USAHA is not null then
       open  cpk2_comp_profile(:new.KD_JNS_USAHA);
       fetch cpk2_comp_profile into dummy;
       found := cpk2_comp_profile%FOUND;
       close cpk2_comp_profile;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "JNS_USAHA". Cannot create child in "COMP_PROFILE".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
