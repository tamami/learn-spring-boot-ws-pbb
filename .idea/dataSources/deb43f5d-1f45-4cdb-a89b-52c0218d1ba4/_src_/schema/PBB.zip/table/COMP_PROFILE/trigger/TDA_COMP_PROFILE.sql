create trigger TDA_COMP_PROFILE
	after delete
	on COMP_PROFILE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "COMP_PORTO"
    delete COMP_PORTO
    where  MFNPWP_COMP = :old.MFNPWP_COMP
     and   MFKPP_COMP = :old.MFKPP_COMP
     and   MFCAB_COMP = :old.MFCAB_COMP;

    --  Delete all children in "KOMDIR"
    delete KOMDIR
    where  MFNPWP_COMP = :old.MFNPWP_COMP
     and   MFKPP_COMP = :old.MFKPP_COMP
     and   MFCAB_COMP = :old.MFCAB_COMP;

    --  Delete all children in "PEMEGANG_SAHAM"
    delete PEMEGANG_SAHAM
    where  MFNPWP_COMP = :old.MFNPWP_COMP
     and   MFKPP_COMP = :old.MFKPP_COMP
     and   MFCAB_COMP = :old.MFCAB_COMP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
