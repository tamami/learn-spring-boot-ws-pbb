create trigger TUA_COMP_PROFILE
	after update of MFNPWP_COMP,MFKPP_COMP,MFCAB_COMP,KD_STAT_KANTOR,KD_JNS_USAHA
	on COMP_PROFILE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "COMP_PROFILE" for all children in "COMP_PORTO"
    if (updating('MFNPWP_COMP') and :old.MFNPWP_COMP != :new.MFNPWP_COMP) or
       (updating('MFKPP_COMP') and :old.MFKPP_COMP != :new.MFKPP_COMP) or
       (updating('MFCAB_COMP') and :old.MFCAB_COMP != :new.MFCAB_COMP) then
       update COMP_PORTO
        set   MFNPWP_COMP = :new.MFNPWP_COMP,
              MFKPP_COMP = :new.MFKPP_COMP,
              MFCAB_COMP = :new.MFCAB_COMP
       where  MFNPWP_COMP = :old.MFNPWP_COMP
        and   MFKPP_COMP = :old.MFKPP_COMP
        and   MFCAB_COMP = :old.MFCAB_COMP;
    end if;

    --  Modify parent code of "COMP_PROFILE" for all children in "KOMDIR"
    if (updating('MFNPWP_COMP') and :old.MFNPWP_COMP != :new.MFNPWP_COMP) or
       (updating('MFKPP_COMP') and :old.MFKPP_COMP != :new.MFKPP_COMP) or
       (updating('MFCAB_COMP') and :old.MFCAB_COMP != :new.MFCAB_COMP) then
       update KOMDIR
        set   MFNPWP_COMP = :new.MFNPWP_COMP,
              MFKPP_COMP = :new.MFKPP_COMP,
              MFCAB_COMP = :new.MFCAB_COMP
       where  MFNPWP_COMP = :old.MFNPWP_COMP
        and   MFKPP_COMP = :old.MFKPP_COMP
        and   MFCAB_COMP = :old.MFCAB_COMP;
    end if;

    --  Modify parent code of "COMP_PROFILE" for all children in "PEMEGANG_SAHAM"
    if (updating('MFNPWP_COMP') and :old.MFNPWP_COMP != :new.MFNPWP_COMP) or
       (updating('MFKPP_COMP') and :old.MFKPP_COMP != :new.MFKPP_COMP) or
       (updating('MFCAB_COMP') and :old.MFCAB_COMP != :new.MFCAB_COMP) then
       update PEMEGANG_SAHAM
        set   MFNPWP_COMP = :new.MFNPWP_COMP,
              MFKPP_COMP = :new.MFKPP_COMP,
              MFCAB_COMP = :new.MFCAB_COMP
       where  MFNPWP_COMP = :old.MFNPWP_COMP
        and   MFKPP_COMP = :old.MFKPP_COMP
        and   MFCAB_COMP = :old.MFCAB_COMP;
    end if;

    --  Modify parent code of "COMP_PROFILE" for all children in "BNG_SIN_PROFILE"
    if (updating('MFNPWP_COMP') and :old.MFNPWP_COMP != :new.MFNPWP_COMP) or
       (updating('MFKPP_COMP') and :old.MFKPP_COMP != :new.MFKPP_COMP) or
       (updating('MFCAB_COMP') and :old.MFCAB_COMP != :new.MFCAB_COMP) then
       update BNG_SIN_PROFILE
        set   MFNPWP_COMP = :new.MFNPWP_COMP,
              MFKPP_COMP = :new.MFKPP_COMP,
              MFCAB_COMP = :new.MFCAB_COMP
       where  MFNPWP_COMP = :old.MFNPWP_COMP
        and   MFKPP_COMP = :old.MFKPP_COMP
        and   MFCAB_COMP = :old.MFCAB_COMP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
