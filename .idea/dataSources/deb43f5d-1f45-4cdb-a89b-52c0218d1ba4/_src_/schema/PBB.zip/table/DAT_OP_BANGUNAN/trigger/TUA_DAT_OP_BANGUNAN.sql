create trigger TUA_DAT_OP_BANGUNAN
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BNG
	on DAT_OP_BANGUNAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "BNG_SIN_PROFILE"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update BNG_SIN_PROFILE
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "DAT_OP_BNG_KIBB"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update DAT_OP_BNG_KIBB
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "PENDUDUK_BNG_SIN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update PENDUDUK_BNG_SIN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "TELEPON"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update TELEPON
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "PAM"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update PAM
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "LISTRIK"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update LISTRIK
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "GAS"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update GAS
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "IMB"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update IMB
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;

    --  Modify parent code of "DAT_OP_BANGUNAN" for all children in "KENDARAAN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) or
       (updating('NO_URUT') and :old.NO_URUT != :new.NO_URUT) or
       (updating('KD_JNS_OP') and :old.KD_JNS_OP != :new.KD_JNS_OP) or
       (updating('NO_BNG') and :old.NO_BNG != :new.NO_BNG) then
       update KENDARAAN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK,
              NO_URUT = :new.NO_URUT,
              KD_JNS_OP = :new.KD_JNS_OP,
              NO_BNG = :new.NO_BNG
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK
        and   NO_URUT = :old.NO_URUT
        and   KD_JNS_OP = :old.KD_JNS_OP
        and   NO_BNG = :old.NO_BNG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
