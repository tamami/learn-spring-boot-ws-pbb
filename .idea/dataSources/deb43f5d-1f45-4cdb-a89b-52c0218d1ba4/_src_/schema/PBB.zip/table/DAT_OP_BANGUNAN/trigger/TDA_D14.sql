create trigger TDA_D14
	after delete
	on DAT_OP_BANGUNAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_KUNJUNGAN_KEMBALI"
    delete DAT_KUNJUNGAN_KEMBALI
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_NILAI_INDIVIDU"
    delete DAT_NILAI_INDIVIDU
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_FASILITAS_BANGUNAN"
    delete DAT_FASILITAS_BANGUNAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "HIS_OP_BNG"
    delete HIS_OP_BNG
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB14"
    delete DAT_JPB14
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB2"
    delete DAT_JPB2
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB9"
    delete DAT_JPB9
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB13"
    delete DAT_JPB13
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB12"
    delete DAT_JPB12
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB16"
    delete DAT_JPB16
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB15"
    delete DAT_JPB15
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB4"
    delete DAT_JPB4
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB7"
    delete DAT_JPB7
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB6"
    delete DAT_JPB6
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB5"
    delete DAT_JPB5
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB8"
    delete DAT_JPB8
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;

    --  Delete all children in "DAT_JPB3"
    delete DAT_JPB3
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BNG = :old.NO_BNG;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
