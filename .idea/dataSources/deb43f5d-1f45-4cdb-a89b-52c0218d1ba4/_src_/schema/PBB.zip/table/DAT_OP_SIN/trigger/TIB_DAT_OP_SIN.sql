create trigger TIB_DAT_OP_SIN
	before insert
	on DAT_OP_SIN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "DAT_OBJEK_PAJAK"
    cursor cpk1_dat_op_sin(var_kd_propinsi varchar,
                           var_kd_dati2 varchar,
                           var_kd_kecamatan varchar,
                           var_kd_kelurahan varchar,
                           var_kd_blok varchar,
                           var_no_urut varchar,
                           var_kd_jns_op varchar) is
       select 1
       from   DAT_OBJEK_PAJAK
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "JENIS_SIN"
    cursor cpk2_dat_op_sin(var_kd_jns_sin varchar) is
       select 1
       from   JENIS_SIN
       where  KD_JNS_SIN = var_kd_jns_sin
        and   var_kd_jns_sin is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_dat_op_sin(var_nip_pendata varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pendata
        and   var_nip_pendata is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk4_dat_op_sin(var_nip_perekam varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam
        and   var_nip_perekam is not null;

begin

    --  Parent "DAT_OBJEK_PAJAK" must exist when inserting a child in "DAT_OP_SIN"
    if :new.KD_PROPINSI is not null and
       :new.KD_DATI2 is not null and
       :new.KD_KECAMATAN is not null and
       :new.KD_KELURAHAN is not null and
       :new.KD_BLOK is not null and
       :new.NO_URUT is not null and
       :new.KD_JNS_OP is not null then
       open  cpk1_dat_op_sin(:new.KD_PROPINSI,
                             :new.KD_DATI2,
                             :new.KD_KECAMATAN,
                             :new.KD_KELURAHAN,
                             :new.KD_BLOK,
                             :new.NO_URUT,
                             :new.KD_JNS_OP);
       fetch cpk1_dat_op_sin into dummy;
       found := cpk1_dat_op_sin%FOUND;
       close cpk1_dat_op_sin;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "DAT_OBJEK_PAJAK". Cannot create child in "DAT_OP_SIN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "JENIS_SIN" must exist when inserting a child in "DAT_OP_SIN"
    if :new.KD_JNS_SIN is not null then
       open  cpk2_dat_op_sin(:new.KD_JNS_SIN);
       fetch cpk2_dat_op_sin into dummy;
       found := cpk2_dat_op_sin%FOUND;
       close cpk2_dat_op_sin;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "JENIS_SIN". Cannot create child in "DAT_OP_SIN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when inserting a child in "DAT_OP_SIN"
    if :new.NIP_PENDATA is not null then
       open  cpk3_dat_op_sin(:new.NIP_PENDATA);
       fetch cpk3_dat_op_sin into dummy;
       found := cpk3_dat_op_sin%FOUND;
       close cpk3_dat_op_sin;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot create child in "DAT_OP_SIN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when inserting a child in "DAT_OP_SIN"
    if :new.NIP_PEREKAM is not null then
       open  cpk4_dat_op_sin(:new.NIP_PEREKAM);
       fetch cpk4_dat_op_sin into dummy;
       found := cpk4_dat_op_sin%FOUND;
       close cpk4_dat_op_sin;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot create child in "DAT_OP_SIN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
