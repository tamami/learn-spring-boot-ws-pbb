create trigger TUB_H3
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,THN_PELAYANAN_KEB_KBRT,BUNDEL_PELAYANAN_KEP_KBRT,NO_URUT_PELAYANAN_KEP_KBRT,JNS_SK,NO_SK,KD_KLS_TANAH,THN_AWAL_KLS_TANAH,KD_KLS_BNG,THN_AWAL_KLS_BNG,NIP_PENCETAK_PEMBETULAN
	on PEMBETULAN_KEBERATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_DETAIL"
    cursor cpk1_pembetulan_keberatan(var_kd_kanwil varchar,
                                     var_kd_kppbb varchar,
                                     var_thn_pelayanan varchar,
                                     var_bundel_pelayanan varchar,
                                     var_no_urut_pelayanan varchar,
                                     var_kd_propinsi_pemohon varchar,
                                     var_kd_dati2_pemohon varchar,
                                     var_kd_kecamatan_pemohon varchar,
                                     var_kd_kelurahan_pemohon varchar,
                                     var_kd_blok_pemohon varchar,
                                     var_no_urut_pemohon varchar,
                                     var_kd_jns_op_pemohon varchar) is
       select 1
       from   PST_DETAIL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KEPUTUSAN_KEBERATAN_PBB"
    cursor cpk2_pembetulan_keberatan(var_kd_kanwil varchar,
                                     var_kd_kppbb varchar,
                                     var_thn_pelayanan_keb_kbrt varchar,
                                     var_bundel_pelayanan_kep_kbrt varchar,
                                     var_no_urut_pelayanan_kep_kbrt varchar,
                                     var_kd_propinsi_pemohon varchar,
                                     var_kd_dati2_pemohon varchar,
                                     var_kd_kecamatan_pemohon varchar,
                                     var_kd_kelurahan_pemohon varchar,
                                     var_kd_blok_pemohon varchar,
                                     var_no_urut_pemohon varchar,
                                     var_kd_jns_op_pemohon varchar) is
       select 1
       from   KEPUTUSAN_KEBERATAN_PBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan_keb_kbrt
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan_kep_kbrt
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan_kep_kbrt
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan_keb_kbrt is not null
        and   var_bundel_pelayanan_kep_kbrt is not null
        and   var_no_urut_pelayanan_kep_kbrt is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "SK_SK"
    cursor cpk3_pembetulan_keberatan(var_kd_kanwil varchar,
                                     var_kd_kppbb varchar,
                                     var_jns_sk varchar,
                                     var_no_sk varchar) is
       select 1
       from   SK_SK
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   JNS_SK = var_jns_sk
        and   NO_SK = var_no_sk
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_jns_sk is not null
        and   var_no_sk is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_BANGUNAN"
    cursor cpk4_pembetulan_keberatan(var_kd_kls_bng varchar,
                                     var_thn_awal_kls_bng varchar) is
       select 1
       from   KELAS_BANGUNAN
       where  KD_KLS_BNG = var_kd_kls_bng
        and   THN_AWAL_KLS_BNG = var_thn_awal_kls_bng
        and   var_kd_kls_bng is not null
        and   var_thn_awal_kls_bng is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_TANAH"
    cursor cpk5_pembetulan_keberatan(var_kd_kls_tanah varchar,
                                     var_thn_awal_kls_tanah varchar) is
       select 1
       from   KELAS_TANAH
       where  KD_KLS_TANAH = var_kd_kls_tanah
        and   THN_AWAL_KLS_TANAH = var_thn_awal_kls_tanah
        and   var_kd_kls_tanah is not null
        and   var_thn_awal_kls_tanah is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk6_pembetulan_keberatan(var_nip_pencetak_pembetulan varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_pembetulan
        and   var_nip_pencetak_pembetulan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PST_DETAIL" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk1_pembetulan_keberatan(:new.KD_KANWIL,
                                       :new.KD_KPPBB,
                                       :new.THN_PELAYANAN,
                                       :new.BUNDEL_PELAYANAN,
                                       :new.NO_URUT_PELAYANAN,
                                       :new.KD_PROPINSI_PEMOHON,
                                       :new.KD_DATI2_PEMOHON,
                                       :new.KD_KECAMATAN_PEMOHON,
                                       :new.KD_KELURAHAN_PEMOHON,
                                       :new.KD_BLOK_PEMOHON,
                                       :new.NO_URUT_PEMOHON,
                                       :new.KD_JNS_OP_PEMOHON);
       fetch cpk1_pembetulan_keberatan into dummy;
       found := cpk1_pembetulan_keberatan%FOUND;
       close cpk1_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_DETAIL". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KEPUTUSAN_KEBERATAN_PBB" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN_KEB_KBRT is not null) and
       (:new.BUNDEL_PELAYANAN_KEP_KBRT is not null) and
       (:new.NO_URUT_PELAYANAN_KEP_KBRT is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk2_pembetulan_keberatan(:new.KD_KANWIL,
                                       :new.KD_KPPBB,
                                       :new.THN_PELAYANAN_KEB_KBRT,
                                       :new.BUNDEL_PELAYANAN_KEP_KBRT,
                                       :new.NO_URUT_PELAYANAN_KEP_KBRT,
                                       :new.KD_PROPINSI_PEMOHON,
                                       :new.KD_DATI2_PEMOHON,
                                       :new.KD_KECAMATAN_PEMOHON,
                                       :new.KD_KELURAHAN_PEMOHON,
                                       :new.KD_BLOK_PEMOHON,
                                       :new.NO_URUT_PEMOHON,
                                       :new.KD_JNS_OP_PEMOHON);
       fetch cpk2_pembetulan_keberatan into dummy;
       found := cpk2_pembetulan_keberatan%FOUND;
       close cpk2_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KEPUTUSAN_KEBERATAN_PBB". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "SK_SK" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.JNS_SK is not null) and
       (:new.NO_SK is not null) and (seq = 0) then
       open  cpk3_pembetulan_keberatan(:new.KD_KANWIL,
                                       :new.KD_KPPBB,
                                       :new.JNS_SK,
                                       :new.NO_SK);
       fetch cpk3_pembetulan_keberatan into dummy;
       found := cpk3_pembetulan_keberatan%FOUND;
       close cpk3_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SK_SK". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KELAS_BANGUNAN" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.KD_KLS_BNG is not null) and
       (:new.THN_AWAL_KLS_BNG is not null) and (seq = 0) then
       open  cpk4_pembetulan_keberatan(:new.KD_KLS_BNG,
                                       :new.THN_AWAL_KLS_BNG);
       fetch cpk4_pembetulan_keberatan into dummy;
       found := cpk4_pembetulan_keberatan%FOUND;
       close cpk4_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_BANGUNAN". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KELAS_TANAH" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.KD_KLS_TANAH is not null) and
       (:new.THN_AWAL_KLS_TANAH is not null) and (seq = 0) then
       open  cpk5_pembetulan_keberatan(:new.KD_KLS_TANAH,
                                       :new.THN_AWAL_KLS_TANAH);
       fetch cpk5_pembetulan_keberatan into dummy;
       found := cpk5_pembetulan_keberatan%FOUND;
       close cpk5_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_TANAH". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PEMBETULAN_KEBERATAN"
    if (:new.NIP_PENCETAK_PEMBETULAN is not null) and (seq = 0) then
       open  cpk6_pembetulan_keberatan(:new.NIP_PENCETAK_PEMBETULAN);
       fetch cpk6_pembetulan_keberatan into dummy;
       found := cpk6_pembetulan_keberatan%FOUND;
       close cpk6_pembetulan_keberatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PEMBETULAN_KEBERATAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
