create trigger TUB_G20
	before update of KD_KANWIL,KD_KPPBB,NO_SRT_BATAL_LELANG,NO_PMT_JDL_LELANG,NIP_PENCETAK_SRT_BATAL_LELANG
	on SRT_BATAL_LELANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk1_srt_batal_lelang(var_kd_kanwil varchar,
                                 var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PERMINTAAN_JADUAL_LELANG"
    cursor cpk2_srt_batal_lelang(var_kd_kanwil varchar,
                                 var_kd_kppbb varchar,
                                 var_no_pmt_jdl_lelang varchar) is
       select 1
       from   PERMINTAAN_JADUAL_LELANG
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_PMT_JDL_LELANG = var_no_pmt_jdl_lelang
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_pmt_jdl_lelang is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_srt_batal_lelang(var_nip_pencetak_srt_batal_lel varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_srt_batal_lel
        and   var_nip_pencetak_srt_batal_lel is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KPPBB" must exist when updating a child in "SRT_BATAL_LELANG"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk1_srt_batal_lelang(:new.KD_KANWIL,
                                   :new.KD_KPPBB);
       fetch cpk1_srt_batal_lelang into dummy;
       found := cpk1_srt_batal_lelang%FOUND;
       close cpk1_srt_batal_lelang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "SRT_BATAL_LELANG".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PERMINTAAN_JADUAL_LELANG" must exist when updating a child in "SRT_BATAL_LELANG"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_PMT_JDL_LELANG is not null) and (seq = 0) then
       open  cpk2_srt_batal_lelang(:new.KD_KANWIL,
                                   :new.KD_KPPBB,
                                   :new.NO_PMT_JDL_LELANG);
       fetch cpk2_srt_batal_lelang into dummy;
       found := cpk2_srt_batal_lelang%FOUND;
       close cpk2_srt_batal_lelang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PERMINTAAN_JADUAL_LELANG". Cannot update child in "SRT_BATAL_LELANG".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SRT_BATAL_LELANG"
    if (:new.NIP_PENCETAK_SRT_BATAL_LELANG is not null) and (seq = 0) then
       open  cpk3_srt_batal_lelang(:new.NIP_PENCETAK_SRT_BATAL_LELANG);
       fetch cpk3_srt_batal_lelang into dummy;
       found := cpk3_srt_batal_lelang%FOUND;
       close cpk3_srt_batal_lelang;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SRT_BATAL_LELANG".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
