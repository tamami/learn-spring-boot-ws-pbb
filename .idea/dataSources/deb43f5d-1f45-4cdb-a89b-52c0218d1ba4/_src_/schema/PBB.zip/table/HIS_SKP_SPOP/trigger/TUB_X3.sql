create trigger TUB_X3
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_SKP_SPOP,HIS_INDEKS_PERUBAHAN_SKP_SPOP,KD_KANWIL,KD_KPPBB,JNS_SK,NO_SK,HIS_KD_BANK_TUNGGAL,HIS_KD_BANK_PERSEPSI,HIS_KD_TP,HIS_KD_KLS_TANAH,HIS_THN_AWAL_KLS_TANAH,HIS_KD_KLS_BNG,HIS_THN_AWAL_KLS_BNG,HIS_NIP_CETAK_SKP_SPOP
	on HIS_SKP_SPOP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SKP_SPOP"
    cursor cpk1_his_skp_spop(var_kd_propinsi varchar,
                             var_kd_dati2 varchar,
                             var_kd_kecamatan varchar,
                             var_kd_kelurahan varchar,
                             var_kd_blok varchar,
                             var_no_urut varchar,
                             var_kd_jns_op varchar,
                             var_thn_pajak_skp_spop varchar) is
       select 1
       from   SKP_SPOP
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   THN_PAJAK_SKP_SPOP = var_thn_pajak_skp_spop
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_thn_pajak_skp_spop is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "SK_SK"
    cursor cpk2_his_skp_spop(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_jns_sk varchar,
                             var_no_sk varchar) is
       select 1
       from   SK_SK
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   JNS_SK = var_jns_sk
        and   NO_SK = var_no_sk
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_jns_sk is not null
        and   var_no_sk is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_TANAH"
    cursor cpk3_his_skp_spop(var_his_kd_kls_tanah varchar,
                             var_his_thn_awal_kls_tanah varchar) is
       select 1
       from   KELAS_TANAH
       where  KD_KLS_TANAH = var_his_kd_kls_tanah
        and   THN_AWAL_KLS_TANAH = var_his_thn_awal_kls_tanah
        and   var_his_kd_kls_tanah is not null
        and   var_his_thn_awal_kls_tanah is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "KELAS_BANGUNAN"
    cursor cpk4_his_skp_spop(var_his_kd_kls_bng varchar,
                             var_his_thn_awal_kls_bng varchar) is
       select 1
       from   KELAS_BANGUNAN
       where  KD_KLS_BNG = var_his_kd_kls_bng
        and   THN_AWAL_KLS_BNG = var_his_thn_awal_kls_bng
        and   var_his_kd_kls_bng is not null
        and   var_his_thn_awal_kls_bng is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "TEMPAT_PEMBAYARAN"
    cursor cpk5_his_skp_spop(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_his_kd_bank_tunggal varchar,
                             var_his_kd_bank_persepsi varchar,
                             var_his_kd_tp varchar) is
       select 1
       from   TEMPAT_PEMBAYARAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_BANK_TUNGGAL = var_his_kd_bank_tunggal
        and   KD_BANK_PERSEPSI = var_his_kd_bank_persepsi
        and   KD_TP = var_his_kd_tp
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_his_kd_bank_tunggal is not null
        and   var_his_kd_bank_persepsi is not null
        and   var_his_kd_tp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk6_his_skp_spop(var_his_nip_cetak_skp_spop varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_his_nip_cetak_skp_spop
        and   var_his_nip_cetak_skp_spop is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SKP_SPOP" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.THN_PAJAK_SKP_SPOP is not null) and (seq = 0) then
       open  cpk1_his_skp_spop(:new.KD_PROPINSI,
                               :new.KD_DATI2,
                               :new.KD_KECAMATAN,
                               :new.KD_KELURAHAN,
                               :new.KD_BLOK,
                               :new.NO_URUT,
                               :new.KD_JNS_OP,
                               :new.THN_PAJAK_SKP_SPOP);
       fetch cpk1_his_skp_spop into dummy;
       found := cpk1_his_skp_spop%FOUND;
       close cpk1_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SKP_SPOP". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "SK_SK" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.JNS_SK is not null) and
       (:new.NO_SK is not null) and (seq = 0) then
       open  cpk2_his_skp_spop(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.JNS_SK,
                               :new.NO_SK);
       fetch cpk2_his_skp_spop into dummy;
       found := cpk2_his_skp_spop%FOUND;
       close cpk2_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SK_SK". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KELAS_TANAH" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.HIS_KD_KLS_TANAH is not null) and
       (:new.HIS_THN_AWAL_KLS_TANAH is not null) and (seq = 0) then
       open  cpk3_his_skp_spop(:new.HIS_KD_KLS_TANAH,
                               :new.HIS_THN_AWAL_KLS_TANAH);
       fetch cpk3_his_skp_spop into dummy;
       found := cpk3_his_skp_spop%FOUND;
       close cpk3_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_TANAH". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "KELAS_BANGUNAN" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.HIS_KD_KLS_BNG is not null) and
       (:new.HIS_THN_AWAL_KLS_BNG is not null) and (seq = 0) then
       open  cpk4_his_skp_spop(:new.HIS_KD_KLS_BNG,
                               :new.HIS_THN_AWAL_KLS_BNG);
       fetch cpk4_his_skp_spop into dummy;
       found := cpk4_his_skp_spop%FOUND;
       close cpk4_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "KELAS_BANGUNAN". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "TEMPAT_PEMBAYARAN" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.HIS_KD_BANK_TUNGGAL is not null) and
       (:new.HIS_KD_BANK_PERSEPSI is not null) and
       (:new.HIS_KD_TP is not null) and (seq = 0) then
       open  cpk5_his_skp_spop(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.HIS_KD_BANK_TUNGGAL,
                               :new.HIS_KD_BANK_PERSEPSI,
                               :new.HIS_KD_TP);
       fetch cpk5_his_skp_spop into dummy;
       found := cpk5_his_skp_spop%FOUND;
       close cpk5_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "TEMPAT_PEMBAYARAN". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "HIS_SKP_SPOP"
    if (:new.HIS_NIP_CETAK_SKP_SPOP is not null) and (seq = 0) then
       open  cpk6_his_skp_spop(:new.HIS_NIP_CETAK_SKP_SPOP);
       fetch cpk6_his_skp_spop into dummy;
       found := cpk6_his_skp_spop%FOUND;
       close cpk6_his_skp_spop;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "HIS_SKP_SPOP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
