create trigger TDA_X3
	after delete
	on HIS_SKP_SPOP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "HIS_SKP_SPOP_OP_BERSAMA"
    delete HIS_SKP_SPOP_OP_BERSAMA
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   THN_PAJAK_SKP_SPOP = :old.THN_PAJAK_SKP_SPOP
     and   HIS_INDEKS_PERUBAHAN_SKP_SPOP = :old.HIS_INDEKS_PERUBAHAN_SKP_SPOP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
