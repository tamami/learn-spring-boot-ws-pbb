create trigger TUA_A1
	after update of KD_PROPINSI
	on REF_PROPINSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_PROPINSI" for all children in "REF_DATI2"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) then
       update REF_DATI2
        set   KD_PROPINSI = :new.KD_PROPINSI
       where  KD_PROPINSI = :old.KD_PROPINSI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
