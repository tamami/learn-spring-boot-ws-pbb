create trigger TUB_D32
	before update of UMUR_EFEKTIF,KD_RANGE_PENYUSUTAN,KONDISI_BNG_SUSUT
	on PENYUSUTAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "RANGE_PENYUSUTAN"
    cursor cpk1_penyusutan(var_kd_range_penyusutan varchar) is
       select 1
       from   RANGE_PENYUSUTAN
       where  KD_RANGE_PENYUSUTAN = var_kd_range_penyusutan
        and   var_kd_range_penyusutan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "RANGE_PENYUSUTAN" must exist when updating a child in "PENYUSUTAN"
    if (:new.KD_RANGE_PENYUSUTAN is not null) and (seq = 0) then
       open  cpk1_penyusutan(:new.KD_RANGE_PENYUSUTAN);
       fetch cpk1_penyusutan into dummy;
       found := cpk1_penyusutan%FOUND;
       close cpk1_penyusutan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "RANGE_PENYUSUTAN". Cannot update child in "PENYUSUTAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
