create trigger TUB_F6
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON
	on PST_PERMOHONAN_PENGURANGAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_DETAIL"
    cursor cpk1_pst_permohonan_penguranga(var_kd_kanwil varchar,
                                          var_kd_kppbb varchar,
                                          var_thn_pelayanan varchar,
                                          var_bundel_pelayanan varchar,
                                          var_no_urut_pelayanan varchar,
                                          var_kd_propinsi_pemohon varchar,
                                          var_kd_dati2_pemohon varchar,
                                          var_kd_kecamatan_pemohon varchar,
                                          var_kd_kelurahan_pemohon varchar,
                                          var_kd_blok_pemohon varchar,
                                          var_no_urut_pemohon varchar,
                                          var_kd_jns_op_pemohon varchar) is
       select 1
       from   PST_DETAIL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PST_DETAIL" must exist when updating a child in "PST_PERMOHONAN_PENGURANGAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk1_pst_permohonan_penguranga(:new.KD_KANWIL,
                                            :new.KD_KPPBB,
                                            :new.THN_PELAYANAN,
                                            :new.BUNDEL_PELAYANAN,
                                            :new.NO_URUT_PELAYANAN,
                                            :new.KD_PROPINSI_PEMOHON,
                                            :new.KD_DATI2_PEMOHON,
                                            :new.KD_KECAMATAN_PEMOHON,
                                            :new.KD_KELURAHAN_PEMOHON,
                                            :new.KD_BLOK_PEMOHON,
                                            :new.NO_URUT_PEMOHON,
                                            :new.KD_JNS_OP_PEMOHON);
       fetch cpk1_pst_permohonan_penguranga into dummy;
       found := cpk1_pst_permohonan_penguranga%FOUND;
       close cpk1_pst_permohonan_penguranga;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_DETAIL". Cannot update child in "PST_PERMOHONAN_PENGURANGAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
