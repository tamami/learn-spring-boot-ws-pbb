create trigger TUA_A5
	after update of KD_KANWIL
	on REF_KANWIL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_KANWIL" for all children in "REF_KPPBB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) then
       update REF_KPPBB
        set   KD_KANWIL = :new.KD_KANWIL
       where  KD_KANWIL = :old.KD_KANWIL;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
