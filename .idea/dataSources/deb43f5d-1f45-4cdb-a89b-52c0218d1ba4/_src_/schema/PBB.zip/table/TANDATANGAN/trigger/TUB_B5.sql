create trigger TUB_B5
	before update of NIP
	on TANDATANGAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk1_tandatangan(var_nip varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip
        and   var_nip is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PEGAWAI" must exist when updating a child in "TANDATANGAN"
    if (:new.NIP is not null) and (seq = 0) then
       open  cpk1_tandatangan(:new.NIP);
       fetch cpk1_tandatangan into dummy;
       found := cpk1_tandatangan%FOUND;
       close cpk1_tandatangan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "TANDATANGAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
