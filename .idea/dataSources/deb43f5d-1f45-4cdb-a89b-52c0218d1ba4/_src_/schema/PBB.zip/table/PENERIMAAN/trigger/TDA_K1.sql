create trigger TDA_K1
	after delete
	on PENERIMAAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TERIMA_PEMBAGIAN"
    delete TERIMA_PEMBAGIAN
    where  KD_SEKTOR = :old.KD_SEKTOR
     and   KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   TAHUN_PEMBAGIAN = :old.TAHUN_PENERIMAAN
     and   BULAN_PEMBAGIAN = :old.BULAN_PENERIMAAN
     and   MINGGU_KE_PEMBAGIAN = :old.MINGGU_KE_PENERIMAAN
     and   PEMBAGIAN_KE = :old.PENERIMAAN_KE;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
