create trigger TUA_K1
	after update of KD_SEKTOR,KD_PROPINSI,KD_DATI2,TAHUN_PENERIMAAN,BULAN_PENERIMAAN,MINGGU_KE_PENERIMAAN,PENERIMAAN_KE,NIP_REKAM_TRM_PENERIMAAN
	on PENERIMAAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PENERIMAAN" for all children in "TERIMA_PEMBAGIAN"
    if (updating('KD_SEKTOR') and :old.KD_SEKTOR != :new.KD_SEKTOR) or
       (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('TAHUN_PENERIMAAN') and :old.TAHUN_PENERIMAAN != :new.TAHUN_PENERIMAAN) or
       (updating('BULAN_PENERIMAAN') and :old.BULAN_PENERIMAAN != :new.BULAN_PENERIMAAN) or
       (updating('MINGGU_KE_PENERIMAAN') and :old.MINGGU_KE_PENERIMAAN != :new.MINGGU_KE_PENERIMAAN) or
       (updating('PENERIMAAN_KE') and :old.PENERIMAAN_KE != :new.PENERIMAAN_KE) then
       update TERIMA_PEMBAGIAN
        set   KD_SEKTOR = :new.KD_SEKTOR,
              KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              TAHUN_PEMBAGIAN = :new.TAHUN_PENERIMAAN,
              BULAN_PEMBAGIAN = :new.BULAN_PENERIMAAN,
              MINGGU_KE_PEMBAGIAN = :new.MINGGU_KE_PENERIMAAN,
              PEMBAGIAN_KE = :new.PENERIMAAN_KE
       where  KD_SEKTOR = :old.KD_SEKTOR
        and   KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   TAHUN_PEMBAGIAN = :old.TAHUN_PENERIMAAN
        and   BULAN_PEMBAGIAN = :old.BULAN_PENERIMAAN
        and   MINGGU_KE_PEMBAGIAN = :old.MINGGU_KE_PENERIMAAN
        and   PEMBAGIAN_KE = :old.PENERIMAAN_KE;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
