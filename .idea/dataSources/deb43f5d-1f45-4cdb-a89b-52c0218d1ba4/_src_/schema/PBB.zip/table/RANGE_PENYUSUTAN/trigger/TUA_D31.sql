create trigger TUA_D31
	after update of KD_RANGE_PENYUSUTAN
	on RANGE_PENYUSUTAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "RANGE_PENYUSUTAN" for all children in "PENYUSUTAN"
    if (updating('KD_RANGE_PENYUSUTAN') and :old.KD_RANGE_PENYUSUTAN != :new.KD_RANGE_PENYUSUTAN) then
       update PENYUSUTAN
        set   KD_RANGE_PENYUSUTAN = :new.KD_RANGE_PENYUSUTAN
       where  KD_RANGE_PENYUSUTAN = :old.KD_RANGE_PENYUSUTAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
