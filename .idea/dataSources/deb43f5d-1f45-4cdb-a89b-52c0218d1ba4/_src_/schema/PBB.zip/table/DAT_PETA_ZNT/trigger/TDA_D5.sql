create trigger TDA_D5
	after delete
	on DAT_PETA_ZNT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_OP_BUMI"
    delete DAT_OP_BUMI
    where  KD_ZNT = :old.KD_ZNT
     and   KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
