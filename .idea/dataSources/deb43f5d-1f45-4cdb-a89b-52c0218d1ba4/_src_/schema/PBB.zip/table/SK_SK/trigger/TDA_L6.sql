create trigger TDA_L6
	after delete
	on SK_SK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PEMBETULAN_SPPTSKPSTP"
    delete PEMBETULAN_SPPTSKPSTP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PEMBATALAN_SPPTSKPSTP"
    delete PEMBATALAN_SPPTSKPSTP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PENGURANGAN_DENDA_ADM"
    delete PENGURANGAN_DENDA_ADM
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PENGURANGAN_PERMANEN"
    delete PENGURANGAN_PERMANEN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PENGURANGAN_PST"
    delete PENGURANGAN_PST
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PENGURANGAN_PENGENAAN_JPB"
    delete PENGURANGAN_PENGENAAN_JPB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "KEPUTUSAN_KEBERATAN_PBB"
    delete KEPUTUSAN_KEBERATAN_PBB
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "PEMBETULAN_KEBERATAN"
    delete PEMBETULAN_KEBERATAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "HIS_SPPT"
    delete HIS_SPPT
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "HIS_SKP_SPOP"
    delete HIS_SKP_SPOP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "HIS_SKP_KURANG_BAYAR"
    delete HIS_SKP_KURANG_BAYAR
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;

    --  Delete all children in "HIS_STP"
    delete HIS_STP
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   JNS_SK = :old.JNS_SK
     and   NO_SK = :old.NO_SK;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
