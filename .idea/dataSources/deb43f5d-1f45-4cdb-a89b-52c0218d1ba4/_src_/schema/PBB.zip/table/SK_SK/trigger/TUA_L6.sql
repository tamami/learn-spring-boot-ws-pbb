create trigger TUA_L6
	after update of KD_KANWIL,KD_KPPBB,JNS_SK,NO_SK,NIP_PENCETAK_SK
	on SK_SK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SK_SK" for all children in "PEMBETULAN_SPPTSKPSTP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PEMBETULAN_SPPTSKPSTP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PEMBATALAN_SPPTSKPSTP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PEMBATALAN_SPPTSKPSTP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PENGURANGAN_DENDA_ADM"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PENGURANGAN_DENDA_ADM
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PENGURANGAN_PERMANEN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PENGURANGAN_PERMANEN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PENGURANGAN_PST"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PENGURANGAN_PST
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PENGURANGAN_PENGENAAN_JPB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PENGURANGAN_PENGENAAN_JPB
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "KEPUTUSAN_KEBERATAN_PBB"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update KEPUTUSAN_KEBERATAN_PBB
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "PEMBETULAN_KEBERATAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update PEMBETULAN_KEBERATAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "HIS_SPPT"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update HIS_SPPT
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "HIS_SKP_SPOP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update HIS_SKP_SPOP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "HIS_SKP_KURANG_BAYAR"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update HIS_SKP_KURANG_BAYAR
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;

    --  Modify parent code of "SK_SK" for all children in "HIS_STP"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('JNS_SK') and :old.JNS_SK != :new.JNS_SK) or
       (updating('NO_SK') and :old.NO_SK != :new.NO_SK) then
       update HIS_STP
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              JNS_SK = :new.JNS_SK,
              NO_SK = :new.NO_SK
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   JNS_SK = :old.JNS_SK
        and   NO_SK = :old.NO_SK;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
