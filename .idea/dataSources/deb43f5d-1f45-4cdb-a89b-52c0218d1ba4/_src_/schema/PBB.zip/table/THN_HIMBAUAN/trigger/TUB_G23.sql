create trigger TUB_G23
	before update
	on THN_HIMBAUAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SRT_HIMBAUAN"
    cursor cpk1_thn_himbauan(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_kd_propinsi varchar,
                             var_kd_dati2 varchar,
                             var_kd_kecamatan varchar,
                             var_kd_kelurahan varchar,
                             var_kd_blok varchar,
                             var_no_urut varchar,
                             var_kd_jns_op varchar,
                             var_no_srt_himbauan varchar) is
       select 1
       from   SRT_HIMBAUAN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   NO_SRT_HIMBAUAN = var_no_srt_himbauan
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_no_srt_himbauan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SRT_HIMBAUAN" must exist when updating a child in "THN_HIMBAUAN"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.NO_SRT_HIMBAUAN is not null) and (seq = 0) then
       open  cpk1_thn_himbauan(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.KD_PROPINSI,
                               :new.KD_DATI2,
                               :new.KD_KECAMATAN,
                               :new.KD_KELURAHAN,
                               :new.KD_BLOK,
                               :new.NO_URUT,
                               :new.KD_JNS_OP,
                               :new.NO_SRT_HIMBAUAN);
       fetch cpk1_thn_himbauan into dummy;
       found := cpk1_thn_himbauan%FOUND;
       close cpk1_thn_himbauan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SRT_HIMBAUAN". Cannot update child in "THN_HIMBAUAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
