create trigger TUA_G15
	after update of KD_KANWIL,KD_KPPBB,NO_SPMP,NO_SRT_PAKSA,NIP_JURU_SITA,NIP_PENCETAK_SPMP
	on SRT_PERINTAH_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SRT_PERINTAH_SITA" for all children in "SRT_CABUT_SITA"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SPMP') and :old.NO_SPMP != :new.NO_SPMP) then
       update SRT_CABUT_SITA
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SPMP = :new.NO_SPMP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SPMP = :old.NO_SPMP;
    end if;

    --  Modify parent code of "SRT_PERINTAH_SITA" for all children in "PERMINTAAN_JADUAL_LELANG"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SPMP') and :old.NO_SPMP != :new.NO_SPMP) then
       update PERMINTAAN_JADUAL_LELANG
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SPMP = :new.NO_SPMP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SPMP = :old.NO_SPMP;
    end if;

    --  Modify parent code of "SRT_PERINTAH_SITA" for all children in "BA_SITA"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SPMP') and :old.NO_SPMP != :new.NO_SPMP) then
       update BA_SITA
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SPMP = :new.NO_SPMP
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SPMP = :old.NO_SPMP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
