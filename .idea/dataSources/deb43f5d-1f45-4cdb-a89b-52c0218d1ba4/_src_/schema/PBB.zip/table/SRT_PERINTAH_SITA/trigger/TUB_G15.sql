create trigger TUB_G15
	before update of KD_KANWIL,KD_KPPBB,NO_SPMP,NO_SRT_PAKSA,NIP_JURU_SITA,NIP_PENCETAK_SPMP
	on SRT_PERINTAH_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk1_srt_perintah_sita(var_kd_kanwil varchar,
                                  var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "SRT_PAKSA"
    cursor cpk2_srt_perintah_sita(var_kd_kanwil varchar,
                                  var_kd_kppbb varchar,
                                  var_no_srt_paksa varchar) is
       select 1
       from   SRT_PAKSA
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_SRT_PAKSA = var_no_srt_paksa
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_srt_paksa is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_srt_perintah_sita(var_nip_pencetak_spmp varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_pencetak_spmp
        and   var_nip_pencetak_spmp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk4_srt_perintah_sita(var_nip_juru_sita varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_juru_sita
        and   var_nip_juru_sita is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KPPBB" must exist when updating a child in "SRT_PERINTAH_SITA"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk1_srt_perintah_sita(:new.KD_KANWIL,
                                    :new.KD_KPPBB);
       fetch cpk1_srt_perintah_sita into dummy;
       found := cpk1_srt_perintah_sita%FOUND;
       close cpk1_srt_perintah_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "SRT_PERINTAH_SITA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "SRT_PAKSA" must exist when updating a child in "SRT_PERINTAH_SITA"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_SRT_PAKSA is not null) and (seq = 0) then
       open  cpk2_srt_perintah_sita(:new.KD_KANWIL,
                                    :new.KD_KPPBB,
                                    :new.NO_SRT_PAKSA);
       fetch cpk2_srt_perintah_sita into dummy;
       found := cpk2_srt_perintah_sita%FOUND;
       close cpk2_srt_perintah_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SRT_PAKSA". Cannot update child in "SRT_PERINTAH_SITA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SRT_PERINTAH_SITA"
    if (:new.NIP_PENCETAK_SPMP is not null) and (seq = 0) then
       open  cpk3_srt_perintah_sita(:new.NIP_PENCETAK_SPMP);
       fetch cpk3_srt_perintah_sita into dummy;
       found := cpk3_srt_perintah_sita%FOUND;
       close cpk3_srt_perintah_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SRT_PERINTAH_SITA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SRT_PERINTAH_SITA"
    if (:new.NIP_JURU_SITA is not null) and (seq = 0) then
       open  cpk4_srt_perintah_sita(:new.NIP_JURU_SITA);
       fetch cpk4_srt_perintah_sita into dummy;
       found := cpk4_srt_perintah_sita%FOUND;
       close cpk4_srt_perintah_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SRT_PERINTAH_SITA".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
