create trigger TDA_G15
	after delete
	on SRT_PERINTAH_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SRT_CABUT_SITA"
    delete SRT_CABUT_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_SPMP = :old.NO_SPMP;

    --  Delete all children in "PERMINTAAN_JADUAL_LELANG"
    delete PERMINTAAN_JADUAL_LELANG
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_SPMP = :old.NO_SPMP;

    --  Delete all children in "BA_SITA"
    delete BA_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_SPMP = :old.NO_SPMP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
