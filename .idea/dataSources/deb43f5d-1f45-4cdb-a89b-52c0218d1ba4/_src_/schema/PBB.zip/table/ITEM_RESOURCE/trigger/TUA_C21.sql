create trigger TUA_C21
	after update of KD_GROUP_RESOURCE,KD_RESOURCE
	on ITEM_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "ITEM_RESOURCE" for all children in "HRG_RESOURCE"
    if (updating('KD_GROUP_RESOURCE') and :old.KD_GROUP_RESOURCE != :new.KD_GROUP_RESOURCE) or
       (updating('KD_RESOURCE') and :old.KD_RESOURCE != :new.KD_RESOURCE) then
       update HRG_RESOURCE
        set   KD_GROUP_RESOURCE = :new.KD_GROUP_RESOURCE,
              KD_RESOURCE = :new.KD_RESOURCE
       where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
        and   KD_RESOURCE = :old.KD_RESOURCE;
    end if;

    --  Modify parent code of "ITEM_RESOURCE" for all children in "VOL_RESOURCE"
    if (updating('KD_GROUP_RESOURCE') and :old.KD_GROUP_RESOURCE != :new.KD_GROUP_RESOURCE) or
       (updating('KD_RESOURCE') and :old.KD_RESOURCE != :new.KD_RESOURCE) then
       update VOL_RESOURCE
        set   KD_GROUP_RESOURCE = :new.KD_GROUP_RESOURCE,
              KD_RESOURCE = :new.KD_RESOURCE
       where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
        and   KD_RESOURCE = :old.KD_RESOURCE;
    end if;

    --  Modify parent code of "ITEM_RESOURCE" for all children in "SIM_HRG_RESOURCE"
    if (updating('KD_GROUP_RESOURCE') and :old.KD_GROUP_RESOURCE != :new.KD_GROUP_RESOURCE) or
       (updating('KD_RESOURCE') and :old.KD_RESOURCE != :new.KD_RESOURCE) then
       update SIM_HRG_RESOURCE
        set   KD_GROUP_RESOURCE = :new.KD_GROUP_RESOURCE,
              KD_RESOURCE = :new.KD_RESOURCE
       where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
        and   KD_RESOURCE = :old.KD_RESOURCE;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
