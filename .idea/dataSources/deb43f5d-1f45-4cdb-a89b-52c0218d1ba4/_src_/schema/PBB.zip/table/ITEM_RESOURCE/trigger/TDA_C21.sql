create trigger TDA_C21
	after delete
	on ITEM_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "HRG_RESOURCE"
    delete HRG_RESOURCE
    where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
     and   KD_RESOURCE = :old.KD_RESOURCE;

    --  Delete all children in "VOL_RESOURCE"
    delete VOL_RESOURCE
    where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
     and   KD_RESOURCE = :old.KD_RESOURCE;

    --  Delete all children in "SIM_HRG_RESOURCE"
    delete SIM_HRG_RESOURCE
    where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE
     and   KD_RESOURCE = :old.KD_RESOURCE;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
