create trigger TUA_L3
	after update of KD_LOOKUP_GROUP
	on LOOKUP_GROUP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "LOOKUP_GROUP" for all children in "LOOKUP_ITEM"
    if (updating('KD_LOOKUP_GROUP') and :old.KD_LOOKUP_GROUP != :new.KD_LOOKUP_GROUP) then
       update LOOKUP_ITEM
        set   KD_LOOKUP_GROUP = :new.KD_LOOKUP_GROUP
       where  KD_LOOKUP_GROUP = :old.KD_LOOKUP_GROUP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
