create trigger TDA_L3
	after delete
	on LOOKUP_GROUP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "LOOKUP_ITEM"
    delete LOOKUP_ITEM
    where  KD_LOOKUP_GROUP = :old.KD_LOOKUP_GROUP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
