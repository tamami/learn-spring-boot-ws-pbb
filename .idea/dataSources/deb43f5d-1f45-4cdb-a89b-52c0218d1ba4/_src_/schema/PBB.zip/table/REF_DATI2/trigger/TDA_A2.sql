create trigger TDA_A2
	after delete
	on REF_DATI2
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DBKB_JPB3"
    delete DBKB_JPB3
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_MATERIAL"
    delete DBKB_MATERIAL
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "HRG_KEGIATAN_JPB8"
    delete HRG_KEGIATAN_JPB8
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "FAS_DEP_MIN_MAX"
    delete FAS_DEP_MIN_MAX
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "FAS_DEP_JPB_KLS_BINTANG"
    delete FAS_DEP_JPB_KLS_BINTANG
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "FAS_NON_DEP"
    delete FAS_NON_DEP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "LAPORAN_PEMBAGIAN"
    delete LAPORAN_PEMBAGIAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "PROGNOSA"
    delete PROGNOSA
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "PENERIMAAN"
    delete PENERIMAAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_MEZANIN"
    delete DBKB_MEZANIN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "HRG_RESOURCE"
    delete HRG_RESOURCE
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "NJOPTKP"
    delete NJOPTKP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "NJKP"
    delete NJKP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_STANDARD"
    delete DBKB_STANDARD
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "KAYU_ULIN"
    delete KAYU_ULIN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "HRG_KEGIATAN"
    delete HRG_KEGIATAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "HRG_SATUAN"
    delete HRG_SATUAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB9"
    delete DBKB_JPB9
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_DAYA_DUKUNG"
    delete DBKB_DAYA_DUKUNG
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB8"
    delete DBKB_JPB8
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB13"
    delete DBKB_JPB13
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB14"
    delete DBKB_JPB14
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB16"
    delete DBKB_JPB16
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB15"
    delete DBKB_JPB15
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB7"
    delete DBKB_JPB7
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB5"
    delete DBKB_JPB5
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB4"
    delete DBKB_JPB4
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB2"
    delete DBKB_JPB2
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB6"
    delete DBKB_JPB6
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "DBKB_JPB12"
    delete DBKB_JPB12
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "REF_ADM_KPPBB"
    delete REF_ADM_KPPBB
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "REF_KECAMATAN"
    delete REF_KECAMATAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SK_KANWIL"
    delete SK_KANWIL
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "REF_MATA_ANGGARAN"
    delete REF_MATA_ANGGARAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_HRG_RESOURCE"
    delete SIM_HRG_RESOURCE
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_HRG_SATUAN"
    delete SIM_HRG_SATUAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_MATERIAL"
    delete SIM_DBKB_MATERIAL
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_FAS_NON_DEP"
    delete SIM_FAS_NON_DEP
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_FAS_DEP_JPB_KLS_BINTANG"
    delete SIM_FAS_DEP_JPB_KLS_BINTANG
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_FAS_DEP_MIN_MAX"
    delete SIM_FAS_DEP_MIN_MAX
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_HRG_KEGIATAN"
    delete SIM_HRG_KEGIATAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_HRG_KEGIATAN_JPB8"
    delete SIM_HRG_KEGIATAN_JPB8
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_STANDARD"
    delete SIM_DBKB_STANDARD
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB2"
    delete SIM_DBKB_JPB2
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB16"
    delete SIM_DBKB_JPB16
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB3"
    delete SIM_DBKB_JPB3
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB15"
    delete SIM_DBKB_JPB15
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB4"
    delete SIM_DBKB_JPB4
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB14"
    delete SIM_DBKB_JPB14
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB13"
    delete SIM_DBKB_JPB13
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB12"
    delete SIM_DBKB_JPB12
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB9"
    delete SIM_DBKB_JPB9
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_MEZANIN"
    delete SIM_DBKB_MEZANIN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_DAYA_DUKUNG"
    delete SIM_DBKB_DAYA_DUKUNG
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB8"
    delete SIM_DBKB_JPB8
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB5"
    delete SIM_DBKB_JPB5
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB6"
    delete SIM_DBKB_JPB6
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_DBKB_JPB7"
    delete SIM_DBKB_JPB7
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_PBB_SUM"
    delete SIM_PBB_SUM
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "COLLECTION_RATIO"
    delete COLLECTION_RATIO
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_POTENSI_PENERIMAAN"
    delete SIM_POTENSI_PENERIMAAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;

    --  Delete all children in "SIM_TARGET"
    delete SIM_TARGET
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
