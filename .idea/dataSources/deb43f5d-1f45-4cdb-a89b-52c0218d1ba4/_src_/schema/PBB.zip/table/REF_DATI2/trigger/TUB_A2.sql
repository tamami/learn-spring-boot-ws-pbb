create trigger TUB_A2
	before update of KD_PROPINSI,KD_DATI2
	on REF_DATI2
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_PROPINSI"
    cursor cpk1_ref_dati2(var_kd_propinsi varchar) is
       select 1
       from   REF_PROPINSI
       where  KD_PROPINSI = var_kd_propinsi
        and   var_kd_propinsi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_PROPINSI" must exist when updating a child in "REF_DATI2"
    if (:new.KD_PROPINSI is not null) and (seq = 0) then
       open  cpk1_ref_dati2(:new.KD_PROPINSI);
       fetch cpk1_ref_dati2 into dummy;
       found := cpk1_ref_dati2%FOUND;
       close cpk1_ref_dati2;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_PROPINSI". Cannot update child in "REF_DATI2".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
