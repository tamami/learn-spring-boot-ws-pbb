create trigger TDA_LISTRIK
	after delete
	on LISTRIK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "REK_LISTRIK"
    delete REK_LISTRIK
    where  NO_PELANGGAN_PLN = :old.NO_PELANGGAN_PLN;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
