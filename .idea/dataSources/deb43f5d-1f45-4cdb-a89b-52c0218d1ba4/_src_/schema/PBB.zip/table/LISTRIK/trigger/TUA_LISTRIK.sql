create trigger TUA_LISTRIK
	after update of NO_PELANGGAN_PLN,KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BNG
	on LISTRIK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "LISTRIK" for all children in "REK_LISTRIK"
    if (updating('NO_PELANGGAN_PLN') and :old.NO_PELANGGAN_PLN != :new.NO_PELANGGAN_PLN) then
       update REK_LISTRIK
        set   NO_PELANGGAN_PLN = :new.NO_PELANGGAN_PLN
       where  NO_PELANGGAN_PLN = :old.NO_PELANGGAN_PLN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
