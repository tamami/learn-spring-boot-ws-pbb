create trigger TUB_A7
	before update
	on REF_ADM_KPPBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_ref_adm_kppbb(var_kd_propinsi varchar,
                              var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk2_ref_adm_kppbb(var_kd_kanwil varchar,
                              var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "REF_ADM_KPPBB"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_ref_adm_kppbb(:new.KD_PROPINSI,
                                :new.KD_DATI2);
       fetch cpk1_ref_adm_kppbb into dummy;
       found := cpk1_ref_adm_kppbb%FOUND;
       close cpk1_ref_adm_kppbb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "REF_ADM_KPPBB".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_KPPBB" must exist when updating a child in "REF_ADM_KPPBB"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk2_ref_adm_kppbb(:new.KD_KANWIL,
                                :new.KD_KPPBB);
       fetch cpk2_ref_adm_kppbb into dummy;
       found := cpk2_ref_adm_kppbb%FOUND;
       close cpk2_ref_adm_kppbb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "REF_ADM_KPPBB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
