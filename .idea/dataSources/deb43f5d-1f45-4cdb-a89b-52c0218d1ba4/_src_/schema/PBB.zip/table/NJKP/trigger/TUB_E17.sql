create trigger TUB_E17
	before update of INDEKS_RANGE,KD_JNS_RANGE,KD_PROPINSI,KD_DATI2,KD_JPB_JPT,URUTAN_NJKP
	on NJKP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_THN_NJKP_NJOPTKP_TARIF"
    cursor cpk1_njkp(var_indeks_range number,
                     var_kd_jns_range varchar) is
       select 1
       from   REF_THN_NJKP_NJOPTKP_TARIF
       where  INDEKS_RANGE = var_indeks_range
        and   KD_JNS_RANGE = var_kd_jns_range
        and   var_indeks_range is not null
        and   var_kd_jns_range is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk2_njkp(var_kd_propinsi varchar,
                     var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "JPB_JPT"
    cursor cpk3_njkp(var_kd_jpb_jpt varchar) is
       select 1
       from   JPB_JPT
       where  KD_JPB_JPT = var_kd_jpb_jpt
        and   var_kd_jpb_jpt is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_THN_NJKP_NJOPTKP_TARIF" must exist when updating a child in "NJKP"
    if (:new.INDEKS_RANGE is not null) and
       (:new.KD_JNS_RANGE is not null) and (seq = 0) then
       open  cpk1_njkp(:new.INDEKS_RANGE,
                       :new.KD_JNS_RANGE);
       fetch cpk1_njkp into dummy;
       found := cpk1_njkp%FOUND;
       close cpk1_njkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_THN_NJKP_NJOPTKP_TARIF". Cannot update child in "NJKP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_DATI2" must exist when updating a child in "NJKP"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk2_njkp(:new.KD_PROPINSI,
                       :new.KD_DATI2);
       fetch cpk2_njkp into dummy;
       found := cpk2_njkp%FOUND;
       close cpk2_njkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "NJKP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "JPB_JPT" must exist when updating a child in "NJKP"
    if (:new.KD_JPB_JPT is not null) and (seq = 0) then
       open  cpk3_njkp(:new.KD_JPB_JPT);
       fetch cpk3_njkp into dummy;
       found := cpk3_njkp%FOUND;
       close cpk3_njkp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "JPB_JPT". Cannot update child in "NJKP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
