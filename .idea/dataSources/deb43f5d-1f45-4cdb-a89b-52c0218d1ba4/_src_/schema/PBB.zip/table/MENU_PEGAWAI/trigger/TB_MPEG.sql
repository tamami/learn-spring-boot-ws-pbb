create trigger TB_MPEG
	before insert or update
	on MENU_PEGAWAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_MENU_PEGAWAI(var_nip varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip
        and   var_nip is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PEGAWAI" must exist when updating a child in "MENU_PEGAWAI"
    if (:new.NIP is not null) and (seq = 0) then
       open  cpk3_MENU_PEGAWAI(:new.NIP);
       fetch cpk3_MENU_PEGAWAI into dummy;
       found := cpk3_MENU_PEGAWAI%FOUND;
       close cpk3_MENU_PEGAWAI;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "MENU_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;

