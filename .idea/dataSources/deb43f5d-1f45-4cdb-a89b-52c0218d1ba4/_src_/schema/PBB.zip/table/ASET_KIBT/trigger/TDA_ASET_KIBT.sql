create trigger TDA_ASET_KIBT
	after delete
	on ASET_KIBT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_OP_BUMI_KIBT"
    delete DAT_OP_BUMI_KIBT
    where  KD_PEBIN = :old.KD_PEBIN
     and   KD_PBI = :old.KD_PBI
     and   KD_PPBI = :old.KD_PPBI
     and   KD_UPB = :old.KD_UPB
     and   KD_KIBT = :old.KD_KIBT;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
