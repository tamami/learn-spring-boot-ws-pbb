create trigger TUA_ASET_KIBT
	after update of KD_PEBIN,KD_PBI,KD_PPBI,KD_UPB,KD_KIBT
	on ASET_KIBT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "ASET_KIBT" for all children in "DAT_OP_BUMI_KIBT"
    if (updating('KD_PEBIN') and :old.KD_PEBIN != :new.KD_PEBIN) or
       (updating('KD_PBI') and :old.KD_PBI != :new.KD_PBI) or
       (updating('KD_PPBI') and :old.KD_PPBI != :new.KD_PPBI) or
       (updating('KD_UPB') and :old.KD_UPB != :new.KD_UPB) or
       (updating('KD_KIBT') and :old.KD_KIBT != :new.KD_KIBT) then
       update DAT_OP_BUMI_KIBT
        set   KD_PEBIN = :new.KD_PEBIN,
              KD_PBI = :new.KD_PBI,
              KD_PPBI = :new.KD_PPBI,
              KD_UPB = :new.KD_UPB,
              KD_KIBT = :new.KD_KIBT
       where  KD_PEBIN = :old.KD_PEBIN
        and   KD_PBI = :old.KD_PBI
        and   KD_PPBI = :old.KD_PPBI
        and   KD_UPB = :old.KD_UPB
        and   KD_KIBT = :old.KD_KIBT;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
