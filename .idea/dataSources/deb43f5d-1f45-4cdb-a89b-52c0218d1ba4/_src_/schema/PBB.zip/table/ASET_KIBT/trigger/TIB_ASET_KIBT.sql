create trigger TIB_ASET_KIBT
	before insert
	on ASET_KIBT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "REF_UPB"
    cursor cpk1_aset_kibt(var_kd_pebin varchar,
                          var_kd_pbi varchar,
                          var_kd_ppbi varchar,
                          var_kd_upb varchar) is
       select 1
       from   REF_UPB
       where  KD_PEBIN = var_kd_pebin
        and   KD_PBI = var_kd_pbi
        and   KD_PPBI = var_kd_ppbi
        and   KD_UPB = var_kd_upb
        and   var_kd_pebin is not null
        and   var_kd_pbi is not null
        and   var_kd_ppbi is not null
        and   var_kd_upb is not null;

begin

    --  Parent "REF_UPB" must exist when inserting a child in "ASET_KIBT"
    if :new.KD_PEBIN is not null and
       :new.KD_PBI is not null and
       :new.KD_PPBI is not null and
       :new.KD_UPB is not null then
       open  cpk1_aset_kibt(:new.KD_PEBIN,
                            :new.KD_PBI,
                            :new.KD_PPBI,
                            :new.KD_UPB);
       fetch cpk1_aset_kibt into dummy;
       found := cpk1_aset_kibt%FOUND;
       close cpk1_aset_kibt;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "REF_UPB". Cannot create child in "ASET_KIBT".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
