create trigger TUA_F11
	after update of KD_KELOMPOK_SPPT
	on KELOMPOK_SPPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "KELOMPOK_SPPT" for all children in "DAT_KELOMPOK_SPPT"
    if (updating('KD_KELOMPOK_SPPT') and :old.KD_KELOMPOK_SPPT != :new.KD_KELOMPOK_SPPT) then
       update DAT_KELOMPOK_SPPT
        set   KD_KELOMPOK_SPPT = :new.KD_KELOMPOK_SPPT
       where  KD_KELOMPOK_SPPT = :old.KD_KELOMPOK_SPPT;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
