create trigger TDA_F11
	after delete
	on KELOMPOK_SPPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_KELOMPOK_SPPT"
    delete DAT_KELOMPOK_SPPT
    where  KD_KELOMPOK_SPPT = :old.KD_KELOMPOK_SPPT;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
