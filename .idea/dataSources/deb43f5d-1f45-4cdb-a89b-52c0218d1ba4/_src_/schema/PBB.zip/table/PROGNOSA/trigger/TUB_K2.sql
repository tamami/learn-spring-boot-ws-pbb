create trigger TUB_K2
	before update of KD_SEKTOR,KD_PROPINSI,KD_DATI2,THN_ANGGARAN_PROGNOSA,NIP_REKAM_TRM_PROGNOSA
	on PROGNOSA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_prognosa(var_kd_propinsi varchar,
                         var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JNS_SEKTOR"
    cursor cpk2_prognosa(var_kd_sektor varchar) is
       select 1
       from   REF_JNS_SEKTOR
       where  KD_SEKTOR = var_kd_sektor
        and   var_kd_sektor is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_prognosa(var_nip_rekam_trm_prognosa varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_trm_prognosa
        and   var_nip_rekam_trm_prognosa is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "PROGNOSA"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_prognosa(:new.KD_PROPINSI,
                           :new.KD_DATI2);
       fetch cpk1_prognosa into dummy;
       found := cpk1_prognosa%FOUND;
       close cpk1_prognosa;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "PROGNOSA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_JNS_SEKTOR" must exist when updating a child in "PROGNOSA"
    if (:new.KD_SEKTOR is not null) and (seq = 0) then
       open  cpk2_prognosa(:new.KD_SEKTOR);
       fetch cpk2_prognosa into dummy;
       found := cpk2_prognosa%FOUND;
       close cpk2_prognosa;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JNS_SEKTOR". Cannot update child in "PROGNOSA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PROGNOSA"
    if (:new.NIP_REKAM_TRM_PROGNOSA is not null) and (seq = 0) then
       open  cpk3_prognosa(:new.NIP_REKAM_TRM_PROGNOSA);
       fetch cpk3_prognosa into dummy;
       found := cpk3_prognosa%FOUND;
       close cpk3_prognosa;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PROGNOSA".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
