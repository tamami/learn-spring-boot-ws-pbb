create trigger TDA_C15
	after delete
	on ADJ
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "ADJ_BANGUNAN_JPB8"
    delete ADJ_BANGUNAN_JPB8
    where  KD_ADJ = :old.KD_ADJ;

    --  Delete all children in "ADJ_BANGUNAN"
    delete ADJ_BANGUNAN
    where  KD_ADJ = :old.KD_ADJ;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
