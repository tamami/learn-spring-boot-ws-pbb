create trigger TUA_C15
	after update of KD_ADJ
	on ADJ
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "ADJ" for all children in "ADJ_BANGUNAN_JPB8"
    if (updating('KD_ADJ') and :old.KD_ADJ != :new.KD_ADJ) then
       update ADJ_BANGUNAN_JPB8
        set   KD_ADJ = :new.KD_ADJ
       where  KD_ADJ = :old.KD_ADJ;
    end if;

    --  Modify parent code of "ADJ" for all children in "ADJ_BANGUNAN"
    if (updating('KD_ADJ') and :old.KD_ADJ != :new.KD_ADJ) then
       update ADJ_BANGUNAN
        set   KD_ADJ = :new.KD_ADJ
       where  KD_ADJ = :old.KD_ADJ;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
