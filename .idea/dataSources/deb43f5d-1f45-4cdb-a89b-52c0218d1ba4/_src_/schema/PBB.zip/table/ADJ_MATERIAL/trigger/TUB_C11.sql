create trigger TUB_C11
	before update of KD_PEKERJAAN,KD_KEGIATAN
	on ADJ_MATERIAL
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEKERJAAN_KEGIATAN"
    cursor cpk1_adj_material(var_kd_pekerjaan varchar,
                             var_kd_kegiatan varchar) is
       select 1
       from   PEKERJAAN_KEGIATAN
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PEKERJAAN_KEGIATAN" must exist when updating a child in "ADJ_MATERIAL"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and (seq = 0) then
       open  cpk1_adj_material(:new.KD_PEKERJAAN,
                               :new.KD_KEGIATAN);
       fetch cpk1_adj_material into dummy;
       found := cpk1_adj_material%FOUND;
       close cpk1_adj_material;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEKERJAAN_KEGIATAN". Cannot update child in "ADJ_MATERIAL".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
