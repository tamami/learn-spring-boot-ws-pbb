create trigger TUB_X9
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK_PENGHAPUSAN_BNG,NO_URUT_PENGHAPUSAN_BNG,KD_JNS_OP_PENGHAPUSAN_BNG,NO_BNG_PENGHAPUSAN,INDEKS_PENGHAPUSAN_BNG,NIP_PEREKAM_PENGHAPUSAN_BNG
	on PENGHAPUSAN_BNG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KELURAHAN"
    cursor cpk1_penghapusan_bng(var_kd_propinsi varchar,
                                var_kd_dati2 varchar,
                                var_kd_kecamatan varchar,
                                var_kd_kelurahan varchar) is
       select 1
       from   REF_KELURAHAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_penghapusan_bng(var_nip_perekam_penghapusan_bn varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam_penghapusan_bn
        and   var_nip_perekam_penghapusan_bn is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KELURAHAN" must exist when updating a child in "PENGHAPUSAN_BNG"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and (seq = 0) then
       open  cpk1_penghapusan_bng(:new.KD_PROPINSI,
                                  :new.KD_DATI2,
                                  :new.KD_KECAMATAN,
                                  :new.KD_KELURAHAN);
       fetch cpk1_penghapusan_bng into dummy;
       found := cpk1_penghapusan_bng%FOUND;
       close cpk1_penghapusan_bng;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KELURAHAN". Cannot update child in "PENGHAPUSAN_BNG".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "PENGHAPUSAN_BNG"
    if (:new.NIP_PEREKAM_PENGHAPUSAN_BNG is not null) and (seq = 0) then
       open  cpk2_penghapusan_bng(:new.NIP_PEREKAM_PENGHAPUSAN_BNG);
       fetch cpk2_penghapusan_bng into dummy;
       found := cpk2_penghapusan_bng%FOUND;
       close cpk2_penghapusan_bng;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "PENGHAPUSAN_BNG".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
