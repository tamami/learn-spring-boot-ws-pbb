create trigger TUA_E24
	after update of KD_JPB_JPT
	on JPB_JPT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "JPB_JPT" for all children in "NJKP"
    if (updating('KD_JPB_JPT') and :old.KD_JPB_JPT != :new.KD_JPB_JPT) then
       update NJKP
        set   KD_JPB_JPT = :new.KD_JPB_JPT
       where  KD_JPB_JPT = :old.KD_JPB_JPT;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
