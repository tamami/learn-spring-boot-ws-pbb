create trigger TUA_B7
	after update of KD_WEWENANG
	on WEWENANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "WEWENANG" for all children in "POSISI_PEGAWAI"
    if (updating('KD_WEWENANG') and :old.KD_WEWENANG != :new.KD_WEWENANG) then
       update POSISI_PEGAWAI
        set   KD_WEWENANG = :new.KD_WEWENANG
       where  KD_WEWENANG = :old.KD_WEWENANG;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
