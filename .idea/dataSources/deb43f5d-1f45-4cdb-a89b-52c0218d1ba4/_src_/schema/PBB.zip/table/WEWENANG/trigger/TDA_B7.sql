create trigger TDA_B7
	after delete
	on WEWENANG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "POSISI_PEGAWAI"
    delete POSISI_PEGAWAI
    where  KD_WEWENANG = :old.KD_WEWENANG;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
