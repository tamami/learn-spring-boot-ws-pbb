create trigger TUA_K3
	after update of KD_PENERIMA
	on PENERIMA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PENERIMA" for all children in "TERIMA_PEMBAGIAN"
    if (updating('KD_PENERIMA') and :old.KD_PENERIMA != :new.KD_PENERIMA) then
       update TERIMA_PEMBAGIAN
        set   KD_PENERIMA = :new.KD_PENERIMA
       where  KD_PENERIMA = :old.KD_PENERIMA;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
