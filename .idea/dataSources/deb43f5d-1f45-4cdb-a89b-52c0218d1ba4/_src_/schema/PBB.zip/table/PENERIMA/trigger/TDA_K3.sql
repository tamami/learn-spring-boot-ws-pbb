create trigger TDA_K3
	after delete
	on PENERIMA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TERIMA_PEMBAGIAN"
    delete TERIMA_PEMBAGIAN
    where  KD_PENERIMA = :old.KD_PENERIMA;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
