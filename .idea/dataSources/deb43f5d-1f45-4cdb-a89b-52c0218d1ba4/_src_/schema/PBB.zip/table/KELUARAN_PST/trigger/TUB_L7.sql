create trigger TUB_L7
	before update of KD_JNS_PELAYANAN
	on KELUARAN_PST
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JNS_PELAYANAN"
    cursor cpk1_keluaran_pst(var_kd_jns_pelayanan varchar) is
       select 1
       from   REF_JNS_PELAYANAN
       where  KD_JNS_PELAYANAN = var_kd_jns_pelayanan
        and   var_kd_jns_pelayanan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_JNS_PELAYANAN" must exist when updating a child in "KELUARAN_PST"
    if (:new.KD_JNS_PELAYANAN is not null) and (seq = 0) then
       open  cpk1_keluaran_pst(:new.KD_JNS_PELAYANAN);
       fetch cpk1_keluaran_pst into dummy;
       found := cpk1_keluaran_pst%FOUND;
       close cpk1_keluaran_pst;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JNS_PELAYANAN". Cannot update child in "KELUARAN_PST".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
