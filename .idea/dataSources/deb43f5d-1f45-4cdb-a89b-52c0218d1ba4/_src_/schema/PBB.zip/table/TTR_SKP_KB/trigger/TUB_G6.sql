create trigger TUB_G6
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_SKP_KB,NIP_PEREKAM_TTR_SKP_KB
	on TTR_SKP_KB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SKP_KURANG_BAYAR"
    cursor cpk1_ttr_skp_kb(var_kd_propinsi varchar,
                           var_kd_dati2 varchar,
                           var_kd_kecamatan varchar,
                           var_kd_kelurahan varchar,
                           var_kd_blok varchar,
                           var_no_urut varchar,
                           var_kd_jns_op varchar,
                           var_thn_pajak_skp_kb varchar) is
       select 1
       from   SKP_KURANG_BAYAR
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   THN_PAJAK_SKP_KB = var_thn_pajak_skp_kb
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_thn_pajak_skp_kb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk2_ttr_skp_kb(var_nip_perekam_ttr_skp_kb varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam_ttr_skp_kb
        and   var_nip_perekam_ttr_skp_kb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SKP_KURANG_BAYAR" must exist when updating a child in "TTR_SKP_KB"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.THN_PAJAK_SKP_KB is not null) and (seq = 0) then
       open  cpk1_ttr_skp_kb(:new.KD_PROPINSI,
                             :new.KD_DATI2,
                             :new.KD_KECAMATAN,
                             :new.KD_KELURAHAN,
                             :new.KD_BLOK,
                             :new.NO_URUT,
                             :new.KD_JNS_OP,
                             :new.THN_PAJAK_SKP_KB);
       fetch cpk1_ttr_skp_kb into dummy;
       found := cpk1_ttr_skp_kb%FOUND;
       close cpk1_ttr_skp_kb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SKP_KURANG_BAYAR". Cannot update child in "TTR_SKP_KB".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "TTR_SKP_KB"
    if (:new.NIP_PEREKAM_TTR_SKP_KB is not null) and (seq = 0) then
       open  cpk2_ttr_skp_kb(:new.NIP_PEREKAM_TTR_SKP_KB);
       fetch cpk2_ttr_skp_kb into dummy;
       found := cpk2_ttr_skp_kb%FOUND;
       close cpk2_ttr_skp_kb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "TTR_SKP_KB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
