create trigger TIB_GAS
	before insert
	on GAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "DAT_OP_BANGUNAN"
    cursor cpk1_gas(var_kd_propinsi varchar,
                    var_kd_dati2 varchar,
                    var_kd_kecamatan varchar,
                    var_kd_kelurahan varchar,
                    var_kd_blok varchar,
                    var_no_urut varchar,
                    var_kd_jns_op varchar,
                    var_no_bng number) is
       select 1
       from   DAT_OP_BANGUNAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   NO_BNG = var_no_bng
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_no_bng is not null;

begin

    --  Parent "DAT_OP_BANGUNAN" must exist when inserting a child in "GAS"
    if :new.KD_PROPINSI is not null and
       :new.KD_DATI2 is not null and
       :new.KD_KECAMATAN is not null and
       :new.KD_KELURAHAN is not null and
       :new.KD_BLOK is not null and
       :new.NO_URUT is not null and
       :new.KD_JNS_OP is not null and
       :new.NO_BNG is not null then
       open  cpk1_gas(:new.KD_PROPINSI,
                      :new.KD_DATI2,
                      :new.KD_KECAMATAN,
                      :new.KD_KELURAHAN,
                      :new.KD_BLOK,
                      :new.NO_URUT,
                      :new.KD_JNS_OP,
                      :new.NO_BNG);
       fetch cpk1_gas into dummy;
       found := cpk1_gas%FOUND;
       close cpk1_gas;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "DAT_OP_BANGUNAN". Cannot create child in "GAS".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
