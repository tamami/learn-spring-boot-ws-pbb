create trigger TUA_GAS
	after update
	on GAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "GAS" for all children in "REK_GAS"
    if (updating('NO_PELANGGAN_GAS') and :old.NO_PELANGGAN_GAS != :new.NO_PELANGGAN_GAS) then
       update REK_GAS
        set   NO_PELANGGAN_GAS = :new.NO_PELANGGAN_GAS
       where  NO_PELANGGAN_GAS = :old.NO_PELANGGAN_GAS;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
