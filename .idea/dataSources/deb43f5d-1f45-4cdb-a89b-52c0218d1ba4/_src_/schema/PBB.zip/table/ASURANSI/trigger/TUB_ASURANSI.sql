create trigger TUB_ASURANSI
	before update of NO_POLIS,NO_PENDUDUK
	on ASURANSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENDUDUK"
    cursor cpk1_asuransi(var_no_penduduk varchar) is
       select 1
       from   PENDUDUK
       where  NO_PENDUDUK = var_no_penduduk
        and   var_no_penduduk is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PENDUDUK" must exist when updating a child in "ASURANSI"
    if (:new.NO_PENDUDUK is not null) and (seq = 0) then
       open  cpk1_asuransi(:new.NO_PENDUDUK);
       fetch cpk1_asuransi into dummy;
       found := cpk1_asuransi%FOUND;
       close cpk1_asuransi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENDUDUK". Cannot update child in "ASURANSI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
