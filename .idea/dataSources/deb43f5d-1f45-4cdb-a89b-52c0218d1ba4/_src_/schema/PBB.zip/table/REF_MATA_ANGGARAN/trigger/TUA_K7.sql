create trigger TUA_K7
	after update of KD_PROPINSI,KD_DATI2,JNS_MATA_ANGGARAN,KD_MATA_ANGGARAN
	on REF_MATA_ANGGARAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_MATA_ANGGARAN" for all children in "LAPORAN_PEMBAGIAN"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('JNS_MATA_ANGGARAN') and :old.JNS_MATA_ANGGARAN != :new.JNS_MATA_ANGGARAN) or
       (updating('KD_MATA_ANGGARAN') and :old.KD_MATA_ANGGARAN != :new.KD_MATA_ANGGARAN) then
       update LAPORAN_PEMBAGIAN
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              JNS_MATA_ANGGARAN = :new.JNS_MATA_ANGGARAN,
              KD_MATA_ANGGARAN = :new.KD_MATA_ANGGARAN
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   JNS_MATA_ANGGARAN = :old.JNS_MATA_ANGGARAN
        and   KD_MATA_ANGGARAN = :old.KD_MATA_ANGGARAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
