create trigger TDA_K7
	after delete
	on REF_MATA_ANGGARAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "LAPORAN_PEMBAGIAN"
    delete LAPORAN_PEMBAGIAN
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   JNS_MATA_ANGGARAN = :old.JNS_MATA_ANGGARAN
     and   KD_MATA_ANGGARAN = :old.KD_MATA_ANGGARAN;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
