create trigger TUB_J1
	before update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,KD_BANK_TUNGGAL,NIP_REKAM_SKKP
	on SKKPP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BANK_TUNGGAL"
    cursor cpk1_skkpp(var_kd_kanwil varchar,
                      var_kd_kppbb varchar,
                      var_kd_bank_tunggal varchar) is
       select 1
       from   BANK_TUNGGAL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   KD_BANK_TUNGGAL = var_kd_bank_tunggal
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_kd_bank_tunggal is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PST_DETAIL"
    cursor cpk2_skkpp(var_kd_kanwil varchar,
                      var_kd_kppbb varchar,
                      var_thn_pelayanan varchar,
                      var_bundel_pelayanan varchar,
                      var_no_urut_pelayanan varchar,
                      var_kd_propinsi_pemohon varchar,
                      var_kd_dati2_pemohon varchar,
                      var_kd_kecamatan_pemohon varchar,
                      var_kd_kelurahan_pemohon varchar,
                      var_kd_blok_pemohon varchar,
                      var_no_urut_pemohon varchar,
                      var_kd_jns_op_pemohon varchar) is
       select 1
       from   PST_DETAIL
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   THN_PELAYANAN = var_thn_pelayanan
        and   BUNDEL_PELAYANAN = var_bundel_pelayanan
        and   NO_URUT_PELAYANAN = var_no_urut_pelayanan
        and   KD_PROPINSI_PEMOHON = var_kd_propinsi_pemohon
        and   KD_DATI2_PEMOHON = var_kd_dati2_pemohon
        and   KD_KECAMATAN_PEMOHON = var_kd_kecamatan_pemohon
        and   KD_KELURAHAN_PEMOHON = var_kd_kelurahan_pemohon
        and   KD_BLOK_PEMOHON = var_kd_blok_pemohon
        and   NO_URUT_PEMOHON = var_no_urut_pemohon
        and   KD_JNS_OP_PEMOHON = var_kd_jns_op_pemohon
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_thn_pelayanan is not null
        and   var_bundel_pelayanan is not null
        and   var_no_urut_pelayanan is not null
        and   var_kd_propinsi_pemohon is not null
        and   var_kd_dati2_pemohon is not null
        and   var_kd_kecamatan_pemohon is not null
        and   var_kd_kelurahan_pemohon is not null
        and   var_kd_blok_pemohon is not null
        and   var_no_urut_pemohon is not null
        and   var_kd_jns_op_pemohon is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_skkpp(var_nip_rekam_skkp varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_skkp
        and   var_nip_rekam_skkp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk4_skkpp(var_kd_kanwil varchar,
                      var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BANK_TUNGGAL" must exist when updating a child in "SKKPP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.KD_BANK_TUNGGAL is not null) and (seq = 0) then
       open  cpk1_skkpp(:new.KD_KANWIL,
                        :new.KD_KPPBB,
                        :new.KD_BANK_TUNGGAL);
       fetch cpk1_skkpp into dummy;
       found := cpk1_skkpp%FOUND;
       close cpk1_skkpp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BANK_TUNGGAL". Cannot update child in "SKKPP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PST_DETAIL" must exist when updating a child in "SKKPP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.THN_PELAYANAN is not null) and
       (:new.BUNDEL_PELAYANAN is not null) and
       (:new.NO_URUT_PELAYANAN is not null) and
       (:new.KD_PROPINSI_PEMOHON is not null) and
       (:new.KD_DATI2_PEMOHON is not null) and
       (:new.KD_KECAMATAN_PEMOHON is not null) and
       (:new.KD_KELURAHAN_PEMOHON is not null) and
       (:new.KD_BLOK_PEMOHON is not null) and
       (:new.NO_URUT_PEMOHON is not null) and
       (:new.KD_JNS_OP_PEMOHON is not null) and (seq = 0) then
       open  cpk2_skkpp(:new.KD_KANWIL,
                        :new.KD_KPPBB,
                        :new.THN_PELAYANAN,
                        :new.BUNDEL_PELAYANAN,
                        :new.NO_URUT_PELAYANAN,
                        :new.KD_PROPINSI_PEMOHON,
                        :new.KD_DATI2_PEMOHON,
                        :new.KD_KECAMATAN_PEMOHON,
                        :new.KD_KELURAHAN_PEMOHON,
                        :new.KD_BLOK_PEMOHON,
                        :new.NO_URUT_PEMOHON,
                        :new.KD_JNS_OP_PEMOHON);
       fetch cpk2_skkpp into dummy;
       found := cpk2_skkpp%FOUND;
       close cpk2_skkpp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PST_DETAIL". Cannot update child in "SKKPP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "SKKPP"
    if (:new.NIP_REKAM_SKKP is not null) and (seq = 0) then
       open  cpk3_skkpp(:new.NIP_REKAM_SKKP);
       fetch cpk3_skkpp into dummy;
       found := cpk3_skkpp%FOUND;
       close cpk3_skkpp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "SKKPP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_KPPBB" must exist when updating a child in "SKKPP"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk4_skkpp(:new.KD_KANWIL,
                        :new.KD_KPPBB);
       fetch cpk4_skkpp into dummy;
       found := cpk4_skkpp%FOUND;
       close cpk4_skkpp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "SKKPP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
