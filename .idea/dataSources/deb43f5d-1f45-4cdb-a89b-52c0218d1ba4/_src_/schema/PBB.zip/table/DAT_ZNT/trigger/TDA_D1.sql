create trigger TDA_D1
	after delete
	on DAT_ZNT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_NIR"
    delete DAT_NIR
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_ZNT = :old.KD_ZNT;

    --  Delete all children in "DAT_PETA_ZNT"
    delete DAT_PETA_ZNT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_ZNT = :old.KD_ZNT;

    --  Delete all children in "SIM_DAT_NIR"
    delete SIM_DAT_NIR
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_ZNT = :old.KD_ZNT;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
