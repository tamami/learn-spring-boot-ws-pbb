create trigger TUA_D1
	after update
	on DAT_ZNT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_ZNT" for all children in "DAT_NIR"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_ZNT') and :old.KD_ZNT != :new.KD_ZNT) then
       update DAT_NIR
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_ZNT = :new.KD_ZNT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_ZNT = :old.KD_ZNT;
    end if;

    --  Modify parent code of "DAT_ZNT" for all children in "DAT_PETA_ZNT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_ZNT') and :old.KD_ZNT != :new.KD_ZNT) then
       update DAT_PETA_ZNT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_ZNT = :new.KD_ZNT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_ZNT = :old.KD_ZNT;
    end if;

    --  Modify parent code of "DAT_ZNT" for all children in "SIM_DAT_NIR"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_ZNT') and :old.KD_ZNT != :new.KD_ZNT) then
       update SIM_DAT_NIR
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_ZNT = :new.KD_ZNT
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_ZNT = :old.KD_ZNT;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
