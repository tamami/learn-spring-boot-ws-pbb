create trigger TUB_C9
	before update of KD_JPB,TIPE_BNG,KD_BNG_LANTAI,KD_PEKERJAAN,KD_KEGIATAN
	on VOL_KEGIATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BANGUNAN_LANTAI"
    cursor cpk1_vol_kegiatan(var_kd_jpb varchar,
                             var_tipe_bng varchar,
                             var_kd_bng_lantai varchar) is
       select 1
       from   BANGUNAN_LANTAI
       where  KD_JPB = var_kd_jpb
        and   TIPE_BNG = var_tipe_bng
        and   KD_BNG_LANTAI = var_kd_bng_lantai
        and   var_kd_jpb is not null
        and   var_tipe_bng is not null
        and   var_kd_bng_lantai is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEKERJAAN_KEGIATAN"
    cursor cpk2_vol_kegiatan(var_kd_pekerjaan varchar,
                             var_kd_kegiatan varchar) is
       select 1
       from   PEKERJAAN_KEGIATAN
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BANGUNAN_LANTAI" must exist when updating a child in "VOL_KEGIATAN"
    if (:new.KD_JPB is not null) and
       (:new.TIPE_BNG is not null) and
       (:new.KD_BNG_LANTAI is not null) and (seq = 0) then
       open  cpk1_vol_kegiatan(:new.KD_JPB,
                               :new.TIPE_BNG,
                               :new.KD_BNG_LANTAI);
       fetch cpk1_vol_kegiatan into dummy;
       found := cpk1_vol_kegiatan%FOUND;
       close cpk1_vol_kegiatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BANGUNAN_LANTAI". Cannot update child in "VOL_KEGIATAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEKERJAAN_KEGIATAN" must exist when updating a child in "VOL_KEGIATAN"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and (seq = 0) then
       open  cpk2_vol_kegiatan(:new.KD_PEKERJAAN,
                               :new.KD_KEGIATAN);
       fetch cpk2_vol_kegiatan into dummy;
       found := cpk2_vol_kegiatan%FOUND;
       close cpk2_vol_kegiatan;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEKERJAAN_KEGIATAN". Cannot update child in "VOL_KEGIATAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
