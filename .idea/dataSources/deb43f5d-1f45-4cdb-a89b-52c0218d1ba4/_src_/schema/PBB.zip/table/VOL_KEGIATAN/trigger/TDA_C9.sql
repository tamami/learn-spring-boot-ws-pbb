create trigger TDA_C9
	after delete
	on VOL_KEGIATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "HRG_KEGIATAN"
    delete HRG_KEGIATAN
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI
     and   KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;

    --  Delete all children in "SIM_HRG_KEGIATAN"
    delete SIM_HRG_KEGIATAN
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI
     and   KD_PEKERJAAN = :old.KD_PEKERJAAN
     and   KD_KEGIATAN = :old.KD_KEGIATAN;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
