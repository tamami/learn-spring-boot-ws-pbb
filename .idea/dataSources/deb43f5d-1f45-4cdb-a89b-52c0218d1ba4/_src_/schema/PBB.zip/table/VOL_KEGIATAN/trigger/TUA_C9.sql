create trigger TUA_C9
	after update of KD_JPB,TIPE_BNG,KD_BNG_LANTAI,KD_PEKERJAAN,KD_KEGIATAN
	on VOL_KEGIATAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "VOL_KEGIATAN" for all children in "HRG_KEGIATAN"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) or
       (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update HRG_KEGIATAN
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI,
              KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI
        and   KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;

    --  Modify parent code of "VOL_KEGIATAN" for all children in "SIM_HRG_KEGIATAN"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) or
       (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) or
       (updating('KD_KEGIATAN') and :old.KD_KEGIATAN != :new.KD_KEGIATAN) then
       update SIM_HRG_KEGIATAN
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI,
              KD_PEKERJAAN = :new.KD_PEKERJAAN,
              KD_KEGIATAN = :new.KD_KEGIATAN
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI
        and   KD_PEKERJAAN = :old.KD_PEKERJAAN
        and   KD_KEGIATAN = :old.KD_KEGIATAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
