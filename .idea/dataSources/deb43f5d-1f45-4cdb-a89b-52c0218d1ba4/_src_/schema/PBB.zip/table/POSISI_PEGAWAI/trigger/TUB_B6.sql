create trigger TUB_B6
	before update of KD_KANWIL,KD_KPPBB,NIP,KD_SEKSI,KD_SUBSEKSI,TGL_AWAL_BERLAKU,KD_WEWENANG,KD_JABATAN
	on POSISI_PEGAWAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk1_posisi_pegawai(var_kd_kanwil varchar,
                               var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "WEWENANG"
    cursor cpk2_posisi_pegawai(var_kd_wewenang varchar) is
       select 1
       from   WEWENANG
       where  KD_WEWENANG = var_kd_wewenang
        and   var_kd_wewenang is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_posisi_pegawai(var_nip varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip
        and   var_nip is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_SUB_SEKSI"
    cursor cpk4_posisi_pegawai(var_kd_seksi varchar,
                               var_kd_subseksi varchar) is
       select 1
       from   REF_SUB_SEKSI
       where  KD_SEKSI = var_kd_seksi
        and   KD_SUBSEKSI = var_kd_subseksi
        and   var_kd_seksi is not null
        and   var_kd_subseksi is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JABATAN"
    cursor cpk5_posisi_pegawai(var_kd_jabatan varchar) is
       select 1
       from   REF_JABATAN
       where  KD_JABATAN = var_kd_jabatan
        and   var_kd_jabatan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KPPBB" must exist when updating a child in "POSISI_PEGAWAI"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk1_posisi_pegawai(:new.KD_KANWIL,
                                 :new.KD_KPPBB);
       fetch cpk1_posisi_pegawai into dummy;
       found := cpk1_posisi_pegawai%FOUND;
       close cpk1_posisi_pegawai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "POSISI_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "WEWENANG" must exist when updating a child in "POSISI_PEGAWAI"
    if (:new.KD_WEWENANG is not null) and (seq = 0) then
       open  cpk2_posisi_pegawai(:new.KD_WEWENANG);
       fetch cpk2_posisi_pegawai into dummy;
       found := cpk2_posisi_pegawai%FOUND;
       close cpk2_posisi_pegawai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "WEWENANG". Cannot update child in "POSISI_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "POSISI_PEGAWAI"
    if (:new.NIP is not null) and (seq = 0) then
       open  cpk3_posisi_pegawai(:new.NIP);
       fetch cpk3_posisi_pegawai into dummy;
       found := cpk3_posisi_pegawai%FOUND;
       close cpk3_posisi_pegawai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "POSISI_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_SUB_SEKSI" must exist when updating a child in "POSISI_PEGAWAI"
    if (:new.KD_SEKSI is not null) and
       (:new.KD_SUBSEKSI is not null) and (seq = 0) then
       open  cpk4_posisi_pegawai(:new.KD_SEKSI,
                                 :new.KD_SUBSEKSI);
       fetch cpk4_posisi_pegawai into dummy;
       found := cpk4_posisi_pegawai%FOUND;
       close cpk4_posisi_pegawai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_SUB_SEKSI". Cannot update child in "POSISI_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_JABATAN" must exist when updating a child in "POSISI_PEGAWAI"
    if (:new.KD_JABATAN is not null) and (seq = 0) then
       open  cpk5_posisi_pegawai(:new.KD_JABATAN);
       fetch cpk5_posisi_pegawai into dummy;
       found := cpk5_posisi_pegawai%FOUND;
       close cpk5_posisi_pegawai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JABATAN". Cannot update child in "POSISI_PEGAWAI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
