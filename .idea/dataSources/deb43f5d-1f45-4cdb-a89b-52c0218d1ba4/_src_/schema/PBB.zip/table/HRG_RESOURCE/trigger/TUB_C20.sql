create trigger TUB_C20
	before update of KD_PROPINSI,KD_DATI2,THN_HRG_RESOURCE,KD_GROUP_RESOURCE,KD_RESOURCE,KD_KANWIL,KD_KPPBB,JNS_DOKUMEN,NO_DOKUMEN
	on HRG_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "DOKUMEN"
    cursor cpk1_hrg_resource(var_kd_kanwil varchar,
                             var_kd_kppbb varchar,
                             var_jns_dokumen varchar,
                             var_no_dokumen varchar) is
       select 1
       from   DOKUMEN
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   JNS_DOKUMEN = var_jns_dokumen
        and   NO_DOKUMEN = var_no_dokumen
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_jns_dokumen is not null
        and   var_no_dokumen is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk2_hrg_resource(var_kd_propinsi varchar,
                             var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "ITEM_RESOURCE"
    cursor cpk3_hrg_resource(var_kd_group_resource varchar,
                             var_kd_resource varchar) is
       select 1
       from   ITEM_RESOURCE
       where  KD_GROUP_RESOURCE = var_kd_group_resource
        and   KD_RESOURCE = var_kd_resource
        and   var_kd_group_resource is not null
        and   var_kd_resource is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "DOKUMEN" must exist when updating a child in "HRG_RESOURCE"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.JNS_DOKUMEN is not null) and
       (:new.NO_DOKUMEN is not null) and (seq = 0) then
       open  cpk1_hrg_resource(:new.KD_KANWIL,
                               :new.KD_KPPBB,
                               :new.JNS_DOKUMEN,
                               :new.NO_DOKUMEN);
       fetch cpk1_hrg_resource into dummy;
       found := cpk1_hrg_resource%FOUND;
       close cpk1_hrg_resource;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DOKUMEN". Cannot update child in "HRG_RESOURCE".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_DATI2" must exist when updating a child in "HRG_RESOURCE"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk2_hrg_resource(:new.KD_PROPINSI,
                               :new.KD_DATI2);
       fetch cpk2_hrg_resource into dummy;
       found := cpk2_hrg_resource%FOUND;
       close cpk2_hrg_resource;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "HRG_RESOURCE".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "ITEM_RESOURCE" must exist when updating a child in "HRG_RESOURCE"
    if (:new.KD_GROUP_RESOURCE is not null) and
       (:new.KD_RESOURCE is not null) and (seq = 0) then
       open  cpk3_hrg_resource(:new.KD_GROUP_RESOURCE,
                               :new.KD_RESOURCE);
       fetch cpk3_hrg_resource into dummy;
       found := cpk3_hrg_resource%FOUND;
       close cpk3_hrg_resource;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "ITEM_RESOURCE". Cannot update child in "HRG_RESOURCE".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
