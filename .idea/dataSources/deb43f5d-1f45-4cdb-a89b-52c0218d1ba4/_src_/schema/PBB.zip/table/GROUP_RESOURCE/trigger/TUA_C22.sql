create trigger TUA_C22
	after update of KD_GROUP_RESOURCE
	on GROUP_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "GROUP_RESOURCE" for all children in "ITEM_RESOURCE"
    if (updating('KD_GROUP_RESOURCE') and :old.KD_GROUP_RESOURCE != :new.KD_GROUP_RESOURCE) then
       update ITEM_RESOURCE
        set   KD_GROUP_RESOURCE = :new.KD_GROUP_RESOURCE
       where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
