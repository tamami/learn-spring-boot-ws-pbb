create trigger TDA_C22
	after delete
	on GROUP_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "ITEM_RESOURCE"
    delete ITEM_RESOURCE
    where  KD_GROUP_RESOURCE = :old.KD_GROUP_RESOURCE;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
