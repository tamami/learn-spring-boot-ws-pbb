create trigger TDA_DAT_OP_BUMI
	after delete
	on DAT_OP_BUMI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SERTIFIKAT"
    delete SERTIFIKAT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BUMI = :old.NO_BUMI;

    --  Delete all children in "DAT_OP_BUMI_KIBT"
    delete DAT_OP_BUMI_KIBT
    where  KD_PROPINSI = :old.KD_PROPINSI
     and   KD_DATI2 = :old.KD_DATI2
     and   KD_KECAMATAN = :old.KD_KECAMATAN
     and   KD_KELURAHAN = :old.KD_KELURAHAN
     and   KD_BLOK = :old.KD_BLOK
     and   NO_URUT = :old.NO_URUT
     and   KD_JNS_OP = :old.KD_JNS_OP
     and   NO_BUMI = :old.NO_BUMI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
