create trigger TUB_D6
	before update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BUMI,KD_ZNT
	on DAT_OP_BUMI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_PETA_ZNT"
    cursor cpk1_dat_op_bumi(var_kd_znt varchar,
                            var_kd_propinsi varchar,
                            var_kd_dati2 varchar,
                            var_kd_kecamatan varchar,
                            var_kd_kelurahan varchar,
                            var_kd_blok varchar) is
       select 1
       from   DAT_PETA_ZNT
       where  KD_ZNT = var_kd_znt
        and   KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   var_kd_znt is not null
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_OBJEK_PAJAK"
    cursor cpk2_dat_op_bumi(var_kd_propinsi varchar,
                            var_kd_dati2 varchar,
                            var_kd_kecamatan varchar,
                            var_kd_kelurahan varchar,
                            var_kd_blok varchar,
                            var_no_urut varchar,
                            var_kd_jns_op varchar) is
       select 1
       from   DAT_OBJEK_PAJAK
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "DAT_PETA_ZNT" must exist when updating a child in "DAT_OP_BUMI"
    if (:new.KD_ZNT is not null) and
       (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and (seq = 0) then
       open  cpk1_dat_op_bumi(:new.KD_ZNT,
                              :new.KD_PROPINSI,
                              :new.KD_DATI2,
                              :new.KD_KECAMATAN,
                              :new.KD_KELURAHAN,
                              :new.KD_BLOK);
       fetch cpk1_dat_op_bumi into dummy;
       found := cpk1_dat_op_bumi%FOUND;
       close cpk1_dat_op_bumi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_PETA_ZNT". Cannot update child in "DAT_OP_BUMI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_OBJEK_PAJAK" must exist when updating a child in "DAT_OP_BUMI"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and (seq = 0) then
       open  cpk2_dat_op_bumi(:new.KD_PROPINSI,
                              :new.KD_DATI2,
                              :new.KD_KECAMATAN,
                              :new.KD_KELURAHAN,
                              :new.KD_BLOK,
                              :new.NO_URUT,
                              :new.KD_JNS_OP);
       fetch cpk2_dat_op_bumi into dummy;
       found := cpk2_dat_op_bumi%FOUND;
       close cpk2_dat_op_bumi;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_OBJEK_PAJAK". Cannot update child in "DAT_OP_BUMI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
