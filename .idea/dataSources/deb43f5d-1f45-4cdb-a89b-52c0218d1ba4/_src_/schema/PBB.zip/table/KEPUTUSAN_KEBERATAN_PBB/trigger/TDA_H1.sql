create trigger TDA_H1
	after delete
	on KEPUTUSAN_KEBERATAN_PBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "PEMBETULAN_KEBERATAN"
    delete PEMBETULAN_KEBERATAN
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   THN_PELAYANAN_KEB_KBRT = :old.THN_PELAYANAN
     and   BUNDEL_PELAYANAN_KEP_KBRT = :old.BUNDEL_PELAYANAN
     and   NO_URUT_PELAYANAN_KEP_KBRT = :old.NO_URUT_PELAYANAN
     and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
     and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
     and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
     and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
     and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
     and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
     and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
