create trigger TUA_H1
	after update of KD_KANWIL,KD_KPPBB,THN_PELAYANAN,BUNDEL_PELAYANAN,NO_URUT_PELAYANAN,KD_PROPINSI_PEMOHON,KD_DATI2_PEMOHON,KD_KECAMATAN_PEMOHON,KD_KELURAHAN_PEMOHON,KD_BLOK_PEMOHON,NO_URUT_PEMOHON,KD_JNS_OP_PEMOHON,JNS_SK,NO_SK,KD_KLS_TANAH,THN_AWAL_KLS_TANAH,KD_KLS_BNG,THN_AWAL_KLS_BNG,NIP_PENCETAK_SK_KEBERATAN
	on KEPUTUSAN_KEBERATAN_PBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "KEPUTUSAN_KEBERATAN_PBB" for all children in "PEMBETULAN_KEBERATAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('THN_PELAYANAN') and :old.THN_PELAYANAN != :new.THN_PELAYANAN) or
       (updating('BUNDEL_PELAYANAN') and :old.BUNDEL_PELAYANAN != :new.BUNDEL_PELAYANAN) or
       (updating('NO_URUT_PELAYANAN') and :old.NO_URUT_PELAYANAN != :new.NO_URUT_PELAYANAN) or
       (updating('KD_PROPINSI_PEMOHON') and :old.KD_PROPINSI_PEMOHON != :new.KD_PROPINSI_PEMOHON) or
       (updating('KD_DATI2_PEMOHON') and :old.KD_DATI2_PEMOHON != :new.KD_DATI2_PEMOHON) or
       (updating('KD_KECAMATAN_PEMOHON') and :old.KD_KECAMATAN_PEMOHON != :new.KD_KECAMATAN_PEMOHON) or
       (updating('KD_KELURAHAN_PEMOHON') and :old.KD_KELURAHAN_PEMOHON != :new.KD_KELURAHAN_PEMOHON) or
       (updating('KD_BLOK_PEMOHON') and :old.KD_BLOK_PEMOHON != :new.KD_BLOK_PEMOHON) or
       (updating('NO_URUT_PEMOHON') and :old.NO_URUT_PEMOHON != :new.NO_URUT_PEMOHON) or
       (updating('KD_JNS_OP_PEMOHON') and :old.KD_JNS_OP_PEMOHON != :new.KD_JNS_OP_PEMOHON) then
       update PEMBETULAN_KEBERATAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              THN_PELAYANAN_KEB_KBRT = :new.THN_PELAYANAN,
              BUNDEL_PELAYANAN_KEP_KBRT = :new.BUNDEL_PELAYANAN,
              NO_URUT_PELAYANAN_KEP_KBRT = :new.NO_URUT_PELAYANAN,
              KD_PROPINSI_PEMOHON = :new.KD_PROPINSI_PEMOHON,
              KD_DATI2_PEMOHON = :new.KD_DATI2_PEMOHON,
              KD_KECAMATAN_PEMOHON = :new.KD_KECAMATAN_PEMOHON,
              KD_KELURAHAN_PEMOHON = :new.KD_KELURAHAN_PEMOHON,
              KD_BLOK_PEMOHON = :new.KD_BLOK_PEMOHON,
              NO_URUT_PEMOHON = :new.NO_URUT_PEMOHON,
              KD_JNS_OP_PEMOHON = :new.KD_JNS_OP_PEMOHON
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   THN_PELAYANAN_KEB_KBRT = :old.THN_PELAYANAN
        and   BUNDEL_PELAYANAN_KEP_KBRT = :old.BUNDEL_PELAYANAN
        and   NO_URUT_PELAYANAN_KEP_KBRT = :old.NO_URUT_PELAYANAN
        and   KD_PROPINSI_PEMOHON = :old.KD_PROPINSI_PEMOHON
        and   KD_DATI2_PEMOHON = :old.KD_DATI2_PEMOHON
        and   KD_KECAMATAN_PEMOHON = :old.KD_KECAMATAN_PEMOHON
        and   KD_KELURAHAN_PEMOHON = :old.KD_KELURAHAN_PEMOHON
        and   KD_BLOK_PEMOHON = :old.KD_BLOK_PEMOHON
        and   NO_URUT_PEMOHON = :old.NO_URUT_PEMOHON
        and   KD_JNS_OP_PEMOHON = :old.KD_JNS_OP_PEMOHON;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
