create trigger TUB_C19
	before update of KD_PROPINSI,KD_DATI2,THN_HRG_PEKERJAAN_JPB8,KD_PEKERJAAN,KD_KEGIATAN,LBR_BENT_MIN_HRG_JPB8,LBR_BENT_MAX_HRG_JPB8,TING_KOLOM_MIN_HRG_JPB8,TING_KOLOM_MAX_HRG_JPB8
	on HRG_KEGIATAN_JPB8
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_DATI2"
    cursor cpk1_hrg_kegiatan_jpb8(var_kd_propinsi varchar,
                                  var_kd_dati2 varchar) is
       select 1
       from   REF_DATI2
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "VOL_KEGIATAN_JPB8"
    cursor cpk2_hrg_kegiatan_jpb8(var_kd_pekerjaan varchar,
                                  var_kd_kegiatan varchar,
                                  var_lbr_bent_min_hrg_jpb8 number,
                                  var_lbr_bent_max_hrg_jpb8 number,
                                  var_ting_kolom_min_hrg_jpb8 number,
                                  var_ting_kolom_max_hrg_jpb8 number) is
       select 1
       from   VOL_KEGIATAN_JPB8
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   LBR_BENT_MIN_HRG_JPB8 = var_lbr_bent_min_hrg_jpb8
        and   LBR_BENT_MAX_HRG_JPB8 = var_lbr_bent_max_hrg_jpb8
        and   TING_KOLOM_MIN_HRG_JPB8 = var_ting_kolom_min_hrg_jpb8
        and   TING_KOLOM_MAX_HRG_JPB8 = var_ting_kolom_max_hrg_jpb8
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null
        and   var_lbr_bent_min_hrg_jpb8 is not null
        and   var_lbr_bent_max_hrg_jpb8 is not null
        and   var_ting_kolom_min_hrg_jpb8 is not null
        and   var_ting_kolom_max_hrg_jpb8 is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_DATI2" must exist when updating a child in "HRG_KEGIATAN_JPB8"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and (seq = 0) then
       open  cpk1_hrg_kegiatan_jpb8(:new.KD_PROPINSI,
                                    :new.KD_DATI2);
       fetch cpk1_hrg_kegiatan_jpb8 into dummy;
       found := cpk1_hrg_kegiatan_jpb8%FOUND;
       close cpk1_hrg_kegiatan_jpb8;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_DATI2". Cannot update child in "HRG_KEGIATAN_JPB8".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "VOL_KEGIATAN_JPB8" must exist when updating a child in "HRG_KEGIATAN_JPB8"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and
       (:new.LBR_BENT_MIN_HRG_JPB8 is not null) and
       (:new.LBR_BENT_MAX_HRG_JPB8 is not null) and
       (:new.TING_KOLOM_MIN_HRG_JPB8 is not null) and
       (:new.TING_KOLOM_MAX_HRG_JPB8 is not null) and (seq = 0) then
       open  cpk2_hrg_kegiatan_jpb8(:new.KD_PEKERJAAN,
                                    :new.KD_KEGIATAN,
                                    :new.LBR_BENT_MIN_HRG_JPB8,
                                    :new.LBR_BENT_MAX_HRG_JPB8,
                                    :new.TING_KOLOM_MIN_HRG_JPB8,
                                    :new.TING_KOLOM_MAX_HRG_JPB8);
       fetch cpk2_hrg_kegiatan_jpb8 into dummy;
       found := cpk2_hrg_kegiatan_jpb8%FOUND;
       close cpk2_hrg_kegiatan_jpb8;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "VOL_KEGIATAN_JPB8". Cannot update child in "HRG_KEGIATAN_JPB8".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
