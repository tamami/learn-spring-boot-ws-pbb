create trigger TIB_DAT_OP_BUMI_KIBT
	before insert
	on DAT_OP_BUMI_KIBT
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "DAT_OP_BUMI"
    cursor cpk1_dat_op_bumi_kibt(var_kd_propinsi varchar,
                                 var_kd_dati2 varchar,
                                 var_kd_kecamatan varchar,
                                 var_kd_kelurahan varchar,
                                 var_kd_blok varchar,
                                 var_no_urut varchar,
                                 var_kd_jns_op varchar,
                                 var_no_bumi number) is
       select 1
       from   DAT_OP_BUMI
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   NO_BUMI = var_no_bumi
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_no_bumi is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "ASET_KIBT"
    cursor cpk2_dat_op_bumi_kibt(var_kd_pebin varchar,
                                 var_kd_pbi varchar,
                                 var_kd_ppbi varchar,
                                 var_kd_upb varchar,
                                 var_kd_kibt varchar) is
       select 1
       from   ASET_KIBT
       where  KD_PEBIN = var_kd_pebin
        and   KD_PBI = var_kd_pbi
        and   KD_PPBI = var_kd_ppbi
        and   KD_UPB = var_kd_upb
        and   KD_KIBT = var_kd_kibt
        and   var_kd_pebin is not null
        and   var_kd_pbi is not null
        and   var_kd_ppbi is not null
        and   var_kd_upb is not null
        and   var_kd_kibt is not null;

begin

    --  Parent "DAT_OP_BUMI" must exist when inserting a child in "DAT_OP_BUMI_KIBT"
    if :new.KD_PROPINSI is not null and
       :new.KD_DATI2 is not null and
       :new.KD_KECAMATAN is not null and
       :new.KD_KELURAHAN is not null and
       :new.KD_BLOK is not null and
       :new.NO_URUT is not null and
       :new.KD_JNS_OP is not null and
       :new.NO_BUMI is not null then
       open  cpk1_dat_op_bumi_kibt(:new.KD_PROPINSI,
                                   :new.KD_DATI2,
                                   :new.KD_KECAMATAN,
                                   :new.KD_KELURAHAN,
                                   :new.KD_BLOK,
                                   :new.NO_URUT,
                                   :new.KD_JNS_OP,
                                   :new.NO_BUMI);
       fetch cpk1_dat_op_bumi_kibt into dummy;
       found := cpk1_dat_op_bumi_kibt%FOUND;
       close cpk1_dat_op_bumi_kibt;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "DAT_OP_BUMI". Cannot create child in "DAT_OP_BUMI_KIBT".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "ASET_KIBT" must exist when inserting a child in "DAT_OP_BUMI_KIBT"
    if :new.KD_PEBIN is not null and
       :new.KD_PBI is not null and
       :new.KD_PPBI is not null and
       :new.KD_UPB is not null and
       :new.KD_KIBT is not null then
       open  cpk2_dat_op_bumi_kibt(:new.KD_PEBIN,
                                   :new.KD_PBI,
                                   :new.KD_PPBI,
                                   :new.KD_UPB,
                                   :new.KD_KIBT);
       fetch cpk2_dat_op_bumi_kibt into dummy;
       found := cpk2_dat_op_bumi_kibt%FOUND;
       close cpk2_dat_op_bumi_kibt;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "ASET_KIBT". Cannot create child in "DAT_OP_BUMI_KIBT".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
