create trigger TUA_G21
	after update of KD_KANWIL,KD_KPPBB,NO_BA_SITA,NO_SPMP,NIP_PEREKAM_BA_SITA
	on BA_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "BA_SITA" for all children in "RINCIAN_BARANG_SITA"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_BA_SITA') and :old.NO_BA_SITA != :new.NO_BA_SITA) then
       update RINCIAN_BARANG_SITA
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_BA_SITA = :new.NO_BA_SITA
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_BA_SITA = :old.NO_BA_SITA;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
