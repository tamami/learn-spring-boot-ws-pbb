create trigger TUB_G21
	before update of KD_KANWIL,KD_KPPBB,NO_BA_SITA,NO_SPMP,NIP_PEREKAM_BA_SITA
	on BA_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "SRT_PERINTAH_SITA"
    cursor cpk1_ba_sita(var_kd_kanwil varchar,
                        var_kd_kppbb varchar,
                        var_no_spmp varchar) is
       select 1
       from   SRT_PERINTAH_SITA
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_SPMP = var_no_spmp
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_spmp is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KPPBB"
    cursor cpk2_ba_sita(var_kd_kanwil varchar,
                        var_kd_kppbb varchar) is
       select 1
       from   REF_KPPBB
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_ba_sita(var_nip_perekam_ba_sita varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_perekam_ba_sita
        and   var_nip_perekam_ba_sita is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "SRT_PERINTAH_SITA" must exist when updating a child in "BA_SITA"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_SPMP is not null) and (seq = 0) then
       open  cpk1_ba_sita(:new.KD_KANWIL,
                          :new.KD_KPPBB,
                          :new.NO_SPMP);
       fetch cpk1_ba_sita into dummy;
       found := cpk1_ba_sita%FOUND;
       close cpk1_ba_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "SRT_PERINTAH_SITA". Cannot update child in "BA_SITA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_KPPBB" must exist when updating a child in "BA_SITA"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and (seq = 0) then
       open  cpk2_ba_sita(:new.KD_KANWIL,
                          :new.KD_KPPBB);
       fetch cpk2_ba_sita into dummy;
       found := cpk2_ba_sita%FOUND;
       close cpk2_ba_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KPPBB". Cannot update child in "BA_SITA".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "BA_SITA"
    if (:new.NIP_PEREKAM_BA_SITA is not null) and (seq = 0) then
       open  cpk3_ba_sita(:new.NIP_PEREKAM_BA_SITA);
       fetch cpk3_ba_sita into dummy;
       found := cpk3_ba_sita%FOUND;
       close cpk3_ba_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "BA_SITA".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
