create trigger TDA_G21
	after delete
	on BA_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "RINCIAN_BARANG_SITA"
    delete RINCIAN_BARANG_SITA
    where  KD_KANWIL = :old.KD_KANWIL
     and   KD_KPPBB = :old.KD_KPPBB
     and   NO_BA_SITA = :old.NO_BA_SITA;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
