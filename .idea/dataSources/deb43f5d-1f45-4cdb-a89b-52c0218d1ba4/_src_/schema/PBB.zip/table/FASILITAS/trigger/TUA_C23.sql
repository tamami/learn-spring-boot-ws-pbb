create trigger TUA_C23
	after update of KD_FASILITAS
	on FASILITAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "FASILITAS" for all children in "DAT_FASILITAS_BANGUNAN"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update DAT_FASILITAS_BANGUNAN
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "FAS_NON_DEP"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update FAS_NON_DEP
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "FAS_DEP_JPB_KLS_BINTANG"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update FAS_DEP_JPB_KLS_BINTANG
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "FAS_DEP_MIN_MAX"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update FAS_DEP_MIN_MAX
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "SIM_FAS_NON_DEP"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update SIM_FAS_NON_DEP
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "SIM_FAS_DEP_JPB_KLS_BINTANG"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update SIM_FAS_DEP_JPB_KLS_BINTANG
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;

    --  Modify parent code of "FASILITAS" for all children in "SIM_FAS_DEP_MIN_MAX"
    if (updating('KD_FASILITAS') and :old.KD_FASILITAS != :new.KD_FASILITAS) then
       update SIM_FAS_DEP_MIN_MAX
        set   KD_FASILITAS = :new.KD_FASILITAS
       where  KD_FASILITAS = :old.KD_FASILITAS;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
