create trigger TDA_C23
	after delete
	on FASILITAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_FASILITAS_BANGUNAN"
    delete DAT_FASILITAS_BANGUNAN
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "FAS_NON_DEP"
    delete FAS_NON_DEP
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "FAS_DEP_JPB_KLS_BINTANG"
    delete FAS_DEP_JPB_KLS_BINTANG
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "FAS_DEP_MIN_MAX"
    delete FAS_DEP_MIN_MAX
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "SIM_FAS_NON_DEP"
    delete SIM_FAS_NON_DEP
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "SIM_FAS_DEP_JPB_KLS_BINTANG"
    delete SIM_FAS_DEP_JPB_KLS_BINTANG
    where  KD_FASILITAS = :old.KD_FASILITAS;

    --  Delete all children in "SIM_FAS_DEP_MIN_MAX"
    delete SIM_FAS_DEP_MIN_MAX
    where  KD_FASILITAS = :old.KD_FASILITAS;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
