create trigger TUB_C17
	before update of KD_PEKERJAAN,KD_KEGIATAN,KD_GROUP_RESOURCE,KD_RESOURCE
	on VOL_RESOURCE
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "ITEM_RESOURCE"
    cursor cpk1_vol_resource(var_kd_group_resource varchar,
                             var_kd_resource varchar) is
       select 1
       from   ITEM_RESOURCE
       where  KD_GROUP_RESOURCE = var_kd_group_resource
        and   KD_RESOURCE = var_kd_resource
        and   var_kd_group_resource is not null
        and   var_kd_resource is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEKERJAAN_KEGIATAN"
    cursor cpk2_vol_resource(var_kd_pekerjaan varchar,
                             var_kd_kegiatan varchar) is
       select 1
       from   PEKERJAAN_KEGIATAN
       where  KD_PEKERJAAN = var_kd_pekerjaan
        and   KD_KEGIATAN = var_kd_kegiatan
        and   var_kd_pekerjaan is not null
        and   var_kd_kegiatan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "ITEM_RESOURCE" must exist when updating a child in "VOL_RESOURCE"
    if (:new.KD_GROUP_RESOURCE is not null) and
       (:new.KD_RESOURCE is not null) and (seq = 0) then
       open  cpk1_vol_resource(:new.KD_GROUP_RESOURCE,
                               :new.KD_RESOURCE);
       fetch cpk1_vol_resource into dummy;
       found := cpk1_vol_resource%FOUND;
       close cpk1_vol_resource;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "ITEM_RESOURCE". Cannot update child in "VOL_RESOURCE".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEKERJAAN_KEGIATAN" must exist when updating a child in "VOL_RESOURCE"
    if (:new.KD_PEKERJAAN is not null) and
       (:new.KD_KEGIATAN is not null) and (seq = 0) then
       open  cpk2_vol_resource(:new.KD_PEKERJAAN,
                               :new.KD_KEGIATAN);
       fetch cpk2_vol_resource into dummy;
       found := cpk2_vol_resource%FOUND;
       close cpk2_vol_resource;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEKERJAAN_KEGIATAN". Cannot update child in "VOL_RESOURCE".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
