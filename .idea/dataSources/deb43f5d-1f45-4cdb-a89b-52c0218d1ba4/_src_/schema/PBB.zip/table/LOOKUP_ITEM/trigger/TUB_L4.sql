create trigger TUB_L4
	before update of KD_LOOKUP_GROUP,KD_LOOKUP_ITEM
	on LOOKUP_ITEM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "LOOKUP_GROUP"
    cursor cpk1_lookup_item(var_kd_lookup_group varchar) is
       select 1
       from   LOOKUP_GROUP
       where  KD_LOOKUP_GROUP = var_kd_lookup_group
        and   var_kd_lookup_group is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "LOOKUP_GROUP" must exist when updating a child in "LOOKUP_ITEM"
    if (:new.KD_LOOKUP_GROUP is not null) and (seq = 0) then
       open  cpk1_lookup_item(:new.KD_LOOKUP_GROUP);
       fetch cpk1_lookup_item into dummy;
       found := cpk1_lookup_item%FOUND;
       close cpk1_lookup_item;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "LOOKUP_GROUP". Cannot update child in "LOOKUP_ITEM".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
