create trigger TUA_C6
	after update of KD_PEKERJAAN
	on PEKERJAAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PEKERJAAN" for all children in "PEKERJAAN_KEGIATAN"
    if (updating('KD_PEKERJAAN') and :old.KD_PEKERJAAN != :new.KD_PEKERJAAN) then
       update PEKERJAAN_KEGIATAN
        set   KD_PEKERJAAN = :new.KD_PEKERJAAN
       where  KD_PEKERJAAN = :old.KD_PEKERJAAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
