create trigger TIB_PENDUDUK
	before insert
	on PENDUDUK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "STATUS_KELUARGA"
    cursor cpk1_penduduk(var_kd_status varchar) is
       select 1
       from   STATUS_KELUARGA
       where  KD_STATUS = var_kd_status
        and   var_kd_status is not null;

    --  Declaration of InsertChildParentExist constraint for the parent "STATUS_KAWIN"
    cursor cpk2_penduduk(var_kd_stat_kawin varchar) is
       select 1
       from   STATUS_KAWIN
       where  KD_STAT_KAWIN = var_kd_stat_kawin
        and   var_kd_stat_kawin is not null;

begin

    --  Parent "STATUS_KELUARGA" must exist when inserting a child in "PENDUDUK"
    if :new.KD_STATUS is not null then
       open  cpk1_penduduk(:new.KD_STATUS);
       fetch cpk1_penduduk into dummy;
       found := cpk1_penduduk%FOUND;
       close cpk1_penduduk;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "STATUS_KELUARGA". Cannot create child in "PENDUDUK".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "STATUS_KAWIN" must exist when inserting a child in "PENDUDUK"
    if :new.KD_STAT_KAWIN is not null then
       open  cpk2_penduduk(:new.KD_STAT_KAWIN);
       fetch cpk2_penduduk into dummy;
       found := cpk2_penduduk%FOUND;
       close cpk2_penduduk;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "STATUS_KAWIN". Cannot create child in "PENDUDUK".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
