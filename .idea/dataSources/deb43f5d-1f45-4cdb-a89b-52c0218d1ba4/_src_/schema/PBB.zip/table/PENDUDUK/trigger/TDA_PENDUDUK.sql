create trigger TDA_PENDUDUK
	after delete
	on PENDUDUK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "SIM"
    delete SIM
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "KEPEGAWAIAN"
    delete KEPEGAWAIAN
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "NPWP"
    delete NPWP
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "AKTA_NIKAH"
    delete AKTA_NIKAH
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "AKTA_LAHIR"
    delete AKTA_LAHIR
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "ASTEK"
    delete ASTEK
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "ASKES"
    delete ASKES
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "REKENING_BANK"
    delete REKENING_BANK
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "ASURANSI"
    delete ASURANSI
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "PASPOR"
    delete PASPOR
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "PENDUDUK_BNG_SIN"
    delete PENDUDUK_BNG_SIN
    where  NO_PENDUDUK = :old.NO_PENDUDUK;

    --  Delete all children in "KARTU_KREDIT"
    delete KARTU_KREDIT
    where  NO_PENDUDUK = :old.NO_PENDUDUK;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
