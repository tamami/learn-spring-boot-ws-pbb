create trigger TUA_PENDUDUK
	after update of NO_PENDUDUK,KD_STAT_KAWIN,KD_STATUS
	on PENDUDUK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PENDUDUK" for all children in "SIM"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update SIM
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "KEPEGAWAIAN"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update KEPEGAWAIAN
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "NPWP"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update NPWP
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "AKTA_NIKAH"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update AKTA_NIKAH
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "AKTA_LAHIR"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update AKTA_LAHIR
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "ASTEK"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update ASTEK
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "ASKES"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update ASKES
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "REKENING_BANK"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update REKENING_BANK
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "ASURANSI"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update ASURANSI
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "PASPOR"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update PASPOR
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "PENDUDUK_BNG_SIN"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update PENDUDUK_BNG_SIN
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;

    --  Modify parent code of "PENDUDUK" for all children in "KARTU_KREDIT"
    if (updating('NO_PENDUDUK') and :old.NO_PENDUDUK != :new.NO_PENDUDUK) then
       update KARTU_KREDIT
        set   NO_PENDUDUK = :new.NO_PENDUDUK
       where  NO_PENDUDUK = :old.NO_PENDUDUK;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
