create trigger TUA_PAM
	after update
	on PAM
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PAM" for all children in "REK_PAM"
    if (updating('NO_PELANGGAN_PAM') and :old.NO_PELANGGAN_PAM != :new.NO_PELANGGAN_PAM) then
       update REK_PAM
        set   NO_PELANGGAN_PAM = :new.NO_PELANGGAN_PAM
       where  NO_PELANGGAN_PAM = :old.NO_PELANGGAN_PAM;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
