create trigger TUA_B4
	after update of NIP
	on PEGAWAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "PEGAWAI" for all children in "TANDATANGAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TANDATANGAN
        set   NIP = :new.NIP
       where  NIP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "POSISI_PEGAWAI"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update POSISI_PEGAWAI
        set   NIP = :new.NIP
       where  NIP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_TRANSAKSI_JUAL_BELI"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_TRANSAKSI_JUAL_BELI
        set   NIP_PEREKAM = :new.NIP
       where  NIP_PEREKAM = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OBJEK_PAJAK"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OBJEK_PAJAK
        set   NIP_PEMERIKSA_OP = :new.NIP
       where  NIP_PEMERIKSA_OP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OBJEK_PAJAK"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OBJEK_PAJAK
        set   NIP_PENDATA = :new.NIP
       where  NIP_PENDATA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OBJEK_PAJAK"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OBJEK_PAJAK
        set   NIP_PEREKAM_OP = :new.NIP
       where  NIP_PEREKAM_OP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OP_BANGUNAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OP_BANGUNAN
        set   NIP_PEMERIKSA_BNG = :new.NIP
       where  NIP_PEMERIKSA_BNG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OP_BANGUNAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OP_BANGUNAN
        set   NIP_PEREKAM_BNG = :new.NIP
       where  NIP_PEREKAM_BNG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_OP_BANGUNAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_OP_BANGUNAN
        set   NIP_PENDATA_BNG = :new.NIP
       where  NIP_PENDATA_BNG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DOKUMEN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DOKUMEN
        set   NIP_PENDATA_DOK = :new.NIP
       where  NIP_PENDATA_DOK = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DOKUMEN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DOKUMEN
        set   NIP_PEMERIKSA_DOK = :new.NIP
       where  NIP_PEMERIKSA_DOK = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DOKUMEN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DOKUMEN
        set   NIP_PEREKAM_DOK = :new.NIP
       where  NIP_PEREKAM_DOK = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PERUBAHAN_NOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PERUBAHAN_NOP
        set   NIP_PERUBAH_NOP = :new.NIP
       where  NIP_PERUBAH_NOP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "NOP_MUTASI"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update NOP_MUTASI
        set   NIP_PEREKAM_NOP_MUTASI = :new.NIP
       where  NIP_PEREKAM_NOP_MUTASI = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_NILAI_INDIVIDU"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_NILAI_INDIVIDU
        set   NIP_PENILAI_INDIVIDU = :new.NIP
       where  NIP_PENILAI_INDIVIDU = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_NILAI_INDIVIDU"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_NILAI_INDIVIDU
        set   NIP_PEMERIKSA_INDIVIDU = :new.NIP
       where  NIP_PEMERIKSA_INDIVIDU = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "DAT_NILAI_INDIVIDU"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update DAT_NILAI_INDIVIDU
        set   NIP_PEREKAM_INDIVIDU = :new.NIP
       where  NIP_PEREKAM_INDIVIDU = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PST_PERMOHONAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PST_PERMOHONAN
        set   NIP_PENERIMA = :new.NIP
       where  NIP_PENERIMA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PST_DETAIL"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PST_DETAIL
        set   NIP_PENYERAH = :new.NIP
       where  NIP_PENYERAH = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "BERKAS_KIRIM"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update BERKAS_KIRIM
        set   NIP_PENGIRIM_BERKAS = :new.NIP
       where  NIP_PENGIRIM_BERKAS = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "BERKAS_TERIMA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update BERKAS_TERIMA
        set   NIP_PENERIMA_BERKAS = :new.NIP
       where  NIP_PENERIMA_BERKAS = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SK_SK"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SK_SK
        set   NIP_PENCETAK_SK = :new.NIP
       where  NIP_PENCETAK_SK = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SPPT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SPPT
        set   NIP_PENCETAK_SPPT = :new.NIP
       where  NIP_PENCETAK_SPPT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SKP_SPOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SKP_SPOP
        set   NIP_PENCETAK_SKP_SPOP = :new.NIP
       where  NIP_PENCETAK_SKP_SPOP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SKP_KURANG_BAYAR"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SKP_KURANG_BAYAR
        set   NIP_PENCETAK_SKP_KB = :new.NIP
       where  NIP_PENCETAK_SKP_KB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "KALIBRASI"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update KALIBRASI
        set   NIP_PENGKALIBRASI = :new.NIP
       where  NIP_PENGKALIBRASI = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "CETAK_MASAL"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update CETAK_MASAL
        set   NIP_PENCETAK_MASAL = :new.NIP
       where  NIP_PENCETAK_MASAL = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TTR_SPPT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TTR_SPPT
        set   NIP_REKAM_TTR_SPPT = :new.NIP
       where  NIP_REKAM_TTR_SPPT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PENGEMBALIAN_SPPT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PENGEMBALIAN_SPPT
        set   NIP_PEREKAM_KEMBALI_SPPT = :new.NIP
       where  NIP_PEREKAM_KEMBALI_SPPT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBAYARAN_SPPT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBAYARAN_SPPT
        set   NIP_REKAM_BYR_SPPT = :new.NIP
       where  NIP_REKAM_BYR_SPPT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TTR_SKP_SPOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TTR_SKP_SPOP
        set   NIP_PEREKAM_TTR_SKP_SPOP = :new.NIP
       where  NIP_PEREKAM_TTR_SKP_SPOP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBAYARAN_SKP_SPOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBAYARAN_SKP_SPOP
        set   NIP_PEREKAM_BYR_SKP_SPOP = :new.NIP
       where  NIP_PEREKAM_BYR_SKP_SPOP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBAYARAN_SKP_KB"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBAYARAN_SKP_KB
        set   NIP_PEREKAM_BYR_SKP_KB = :new.NIP
       where  NIP_PEREKAM_BYR_SKP_KB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TTR_SKP_KB"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TTR_SKP_KB
        set   NIP_PEREKAM_TTR_SKP_KB = :new.NIP
       where  NIP_PEREKAM_TTR_SKP_KB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "STP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update STP
        set   NIP_PENCETAK_STP = :new.NIP
       where  NIP_PENCETAK_STP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBAYARAN_STP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBAYARAN_STP
        set   NIP_PEREKAM_BYR_STP = :new.NIP
       where  NIP_PEREKAM_BYR_STP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TTR_STP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TTR_STP
        set   NIP_PEREKAM_TTR_STP = :new.NIP
       where  NIP_PEREKAM_TTR_STP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_HIMBAUAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_HIMBAUAN
        set   NIP_PENCETAK_SRT_HIMBAUAN = :new.NIP
       where  NIP_PENCETAK_SRT_HIMBAUAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_TEGORAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_TEGORAN
        set   NIP_PENCETAK_SRT_TEGORAN = :new.NIP
       where  NIP_PENCETAK_SRT_TEGORAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_PAKSA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_PAKSA
        set   NIP_PENCETAK_SURAT_PAKSA = :new.NIP
       where  NIP_PENCETAK_SURAT_PAKSA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TTR_SRT_TEGORAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TTR_SRT_TEGORAN
        set   NIP_REKAM_TTR_SRT_TEGORAN = :new.NIP
       where  NIP_REKAM_TTR_SRT_TEGORAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_PERINTAH_SITA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_PERINTAH_SITA
        set   NIP_PENCETAK_SPMP = :new.NIP
       where  NIP_PENCETAK_SPMP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_PERINTAH_SITA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_PERINTAH_SITA
        set   NIP_JURU_SITA = :new.NIP
       where  NIP_JURU_SITA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_CABUT_SITA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_CABUT_SITA
        set   NIP_PENCETAK_SRT_CABUT_SITA = :new.NIP
       where  NIP_PENCETAK_SRT_CABUT_SITA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PERMINTAAN_JADUAL_LELANG"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PERMINTAAN_JADUAL_LELANG
        set   NIP_PENCETAK_SRT_PMT_JDL_LLG = :new.NIP
       where  NIP_PENCETAK_SRT_PMT_JDL_LLG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SRT_BATAL_LELANG"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SRT_BATAL_LELANG
        set   NIP_PENCETAK_SRT_BATAL_LELANG = :new.NIP
       where  NIP_PENCETAK_SRT_BATAL_LELANG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SKKPP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SKKPP
        set   NIP_REKAM_SKKP = :new.NIP
       where  NIP_REKAM_SKKP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SPMKP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SPMKP
        set   NIP_REKAM_SPMKP = :new.NIP
       where  NIP_REKAM_SPMKP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SPB"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SPB
        set   NIP_REKAM_SPB = :new.NIP
       where  NIP_REKAM_SPB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PENERIMAAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PENERIMAAN
        set   NIP_REKAM_TRM_PENERIMAAN = :new.NIP
       where  NIP_REKAM_TRM_PENERIMAAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PROGNOSA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PROGNOSA
        set   NIP_REKAM_TRM_PROGNOSA = :new.NIP
       where  NIP_REKAM_TRM_PROGNOSA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "SK_KANWIL"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update SK_KANWIL
        set   NIP_PENCETAK_SK_KANWIL = :new.NIP
       where  NIP_PENCETAK_SK_KANWIL = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "LOG_DBKB"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update LOG_DBKB
        set   NIP_PEREKAM_LOG_DBKB = :new.NIP
       where  NIP_PEREKAM_LOG_DBKB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "LOG_ZNT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update LOG_ZNT
        set   NIP_PEREKAM_LOG_ZNT = :new.NIP
       where  NIP_PEREKAM_LOG_ZNT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_SPPT"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_SPPT
        set   HIS_NIP_PENCETAK_SPPT = :new.NIP
       where  HIS_NIP_PENCETAK_SPPT = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PENGHAPUSAN_PIUTANG"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PENGHAPUSAN_PIUTANG
        set   NIP_REKAM_PENGHAPUSAN_PIUTANG = :new.NIP
       where  NIP_REKAM_PENGHAPUSAN_PIUTANG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_SKP_SPOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_SKP_SPOP
        set   HIS_NIP_CETAK_SKP_SPOP = :new.NIP
       where  HIS_NIP_CETAK_SKP_SPOP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_SKP_KURANG_BAYAR"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_SKP_KURANG_BAYAR
        set   HIS_NIP_PENCETAK_SKP_KB = :new.NIP
       where  HIS_NIP_PENCETAK_SKP_KB = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_STP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_STP
        set   HIS_NIP_PENCETAK_STP = :new.NIP
       where  HIS_NIP_PENCETAK_STP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBATALAN_SPMKP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBATALAN_SPMKP
        set   NIP_PENCETAK_PEMBATALAN_SPMKP = :new.NIP
       where  NIP_PENCETAK_PEMBATALAN_SPMKP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TERIMA_PEMBAGIAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TERIMA_PEMBAGIAN
        set   NIP_REKAM_TRM_BAGI = :new.NIP
       where  NIP_REKAM_TRM_BAGI = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "LAPORAN_PEMBAGIAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update LAPORAN_PEMBAGIAN
        set   NIP_REKAM_LAP_PEMBAGIAN = :new.NIP
       where  NIP_REKAM_LAP_PEMBAGIAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PENGHAPUSAN_OP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PENGHAPUSAN_OP
        set   NIP_PEREKAM_PENGHAPUSAN_OP = :new.NIP
       where  NIP_PEREKAM_PENGHAPUSAN_OP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PENGHAPUSAN_BNG"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PENGHAPUSAN_BNG
        set   NIP_PEREKAM_PENGHAPUSAN_BNG = :new.NIP
       where  NIP_PEREKAM_PENGHAPUSAN_BNG = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "BA_SITA"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update BA_SITA
        set   NIP_PEREKAM_BA_SITA = :new.NIP
       where  NIP_PEREKAM_BA_SITA = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "KEPUTUSAN_KEBERATAN_PBB"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update KEPUTUSAN_KEBERATAN_PBB
        set   NIP_PENCETAK_SK_KEBERATAN = :new.NIP
       where  NIP_PENCETAK_SK_KEBERATAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "PEMBETULAN_KEBERATAN"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update PEMBETULAN_KEBERATAN
        set   NIP_PENCETAK_PEMBETULAN = :new.NIP
       where  NIP_PENCETAK_PEMBETULAN = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_OBJEK_PAJAK"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_OBJEK_PAJAK
        set   HIS_NIP_PEREKAM_OP = :new.NIP
       where  HIS_NIP_PEREKAM_OP = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_OP_BNG"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_OP_BNG
        set   HIS_NIP_PEREKAM_BNG_AWAL = :new.NIP
       where  HIS_NIP_PEREKAM_BNG_AWAL = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_NILAI_INDIVIDU"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_NILAI_INDIVIDU
        set   HIS_NIP_PEREKAM_INDIVIDU = :new.NIP
       where  HIS_NIP_PEREKAM_INDIVIDU = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "HIS_NILAI_INDIVIDU"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update HIS_NILAI_INDIVIDU
        set   HIS_NIP_PENILAI_INDIVIDU = :new.NIP
       where  HIS_NIP_PENILAI_INDIVIDU = :old.NIP;
    end if;

    --  Modify parent code of "PEGAWAI" for all children in "TEMP_SPOP_LSPOP"
    if (updating('NIP') and :old.NIP != :new.NIP) then
       update TEMP_SPOP_LSPOP
        set   NIP_TRANSAKSI_TEMP = :new.NIP
       where  NIP_TRANSAKSI_TEMP = :old.NIP;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
