create trigger TDA_B4
	after delete
	on PEGAWAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "TANDATANGAN"
    delete TANDATANGAN
    where  NIP = :old.NIP;

    --  Delete all children in "POSISI_PEGAWAI"
    delete POSISI_PEGAWAI
    where  NIP = :old.NIP;

    --  Delete all children in "DAT_TRANSAKSI_JUAL_BELI"
    delete DAT_TRANSAKSI_JUAL_BELI
    where  NIP_PEREKAM = :old.NIP;

    --  Delete all children in "DAT_OBJEK_PAJAK"
    delete DAT_OBJEK_PAJAK
    where  NIP_PEMERIKSA_OP = :old.NIP;

    --  Delete all children in "DAT_OBJEK_PAJAK"
    delete DAT_OBJEK_PAJAK
    where  NIP_PENDATA = :old.NIP;

    --  Delete all children in "DAT_OBJEK_PAJAK"
    delete DAT_OBJEK_PAJAK
    where  NIP_PEREKAM_OP = :old.NIP;

    --  Delete all children in "DAT_OP_BANGUNAN"
    delete DAT_OP_BANGUNAN
    where  NIP_PEMERIKSA_BNG = :old.NIP;

    --  Delete all children in "DAT_OP_BANGUNAN"
    delete DAT_OP_BANGUNAN
    where  NIP_PEREKAM_BNG = :old.NIP;

    --  Delete all children in "DAT_OP_BANGUNAN"
    delete DAT_OP_BANGUNAN
    where  NIP_PENDATA_BNG = :old.NIP;

    --  Delete all children in "DOKUMEN"
    delete DOKUMEN
    where  NIP_PENDATA_DOK = :old.NIP;

    --  Delete all children in "DOKUMEN"
    delete DOKUMEN
    where  NIP_PEMERIKSA_DOK = :old.NIP;

    --  Delete all children in "DOKUMEN"
    delete DOKUMEN
    where  NIP_PEREKAM_DOK = :old.NIP;

    --  Delete all children in "PERUBAHAN_NOP"
    delete PERUBAHAN_NOP
    where  NIP_PERUBAH_NOP = :old.NIP;

    --  Delete all children in "NOP_MUTASI"
    delete NOP_MUTASI
    where  NIP_PEREKAM_NOP_MUTASI = :old.NIP;

    --  Delete all children in "DAT_NILAI_INDIVIDU"
    delete DAT_NILAI_INDIVIDU
    where  NIP_PENILAI_INDIVIDU = :old.NIP;

    --  Delete all children in "DAT_NILAI_INDIVIDU"
    delete DAT_NILAI_INDIVIDU
    where  NIP_PEMERIKSA_INDIVIDU = :old.NIP;

    --  Delete all children in "DAT_NILAI_INDIVIDU"
    delete DAT_NILAI_INDIVIDU
    where  NIP_PEREKAM_INDIVIDU = :old.NIP;

    --  Delete all children in "PST_PERMOHONAN"
    delete PST_PERMOHONAN
    where  NIP_PENERIMA = :old.NIP;

    --  Delete all children in "PST_DETAIL"
    delete PST_DETAIL
    where  NIP_PENYERAH = :old.NIP;

    --  Delete all children in "BERKAS_KIRIM"
    delete BERKAS_KIRIM
    where  NIP_PENGIRIM_BERKAS = :old.NIP;

    --  Delete all children in "BERKAS_TERIMA"
    delete BERKAS_TERIMA
    where  NIP_PENERIMA_BERKAS = :old.NIP;

    --  Delete all children in "SK_SK"
    delete SK_SK
    where  NIP_PENCETAK_SK = :old.NIP;

    --  Delete all children in "SPPT"
    delete SPPT
    where  NIP_PENCETAK_SPPT = :old.NIP;

    --  Delete all children in "SKP_SPOP"
    delete SKP_SPOP
    where  NIP_PENCETAK_SKP_SPOP = :old.NIP;

    --  Delete all children in "SKP_KURANG_BAYAR"
    delete SKP_KURANG_BAYAR
    where  NIP_PENCETAK_SKP_KB = :old.NIP;

    --  Delete all children in "KALIBRASI"
    delete KALIBRASI
    where  NIP_PENGKALIBRASI = :old.NIP;

    --  Delete all children in "CETAK_MASAL"
    delete CETAK_MASAL
    where  NIP_PENCETAK_MASAL = :old.NIP;

    --  Delete all children in "TTR_SPPT"
    delete TTR_SPPT
    where  NIP_REKAM_TTR_SPPT = :old.NIP;

    --  Delete all children in "PENGEMBALIAN_SPPT"
    delete PENGEMBALIAN_SPPT
    where  NIP_PEREKAM_KEMBALI_SPPT = :old.NIP;

    --  Delete all children in "PEMBAYARAN_SPPT"
    delete PEMBAYARAN_SPPT
    where  NIP_REKAM_BYR_SPPT = :old.NIP;

    --  Delete all children in "TTR_SKP_SPOP"
    delete TTR_SKP_SPOP
    where  NIP_PEREKAM_TTR_SKP_SPOP = :old.NIP;

    --  Delete all children in "PEMBAYARAN_SKP_SPOP"
    delete PEMBAYARAN_SKP_SPOP
    where  NIP_PEREKAM_BYR_SKP_SPOP = :old.NIP;

    --  Delete all children in "PEMBAYARAN_SKP_KB"
    delete PEMBAYARAN_SKP_KB
    where  NIP_PEREKAM_BYR_SKP_KB = :old.NIP;

    --  Delete all children in "TTR_SKP_KB"
    delete TTR_SKP_KB
    where  NIP_PEREKAM_TTR_SKP_KB = :old.NIP;

    --  Delete all children in "STP"
    delete STP
    where  NIP_PENCETAK_STP = :old.NIP;

    --  Delete all children in "PEMBAYARAN_STP"
    delete PEMBAYARAN_STP
    where  NIP_PEREKAM_BYR_STP = :old.NIP;

    --  Delete all children in "TTR_STP"
    delete TTR_STP
    where  NIP_PEREKAM_TTR_STP = :old.NIP;

    --  Delete all children in "SRT_HIMBAUAN"
    delete SRT_HIMBAUAN
    where  NIP_PENCETAK_SRT_HIMBAUAN = :old.NIP;

    --  Delete all children in "SRT_TEGORAN"
    delete SRT_TEGORAN
    where  NIP_PENCETAK_SRT_TEGORAN = :old.NIP;

    --  Delete all children in "SRT_PAKSA"
    delete SRT_PAKSA
    where  NIP_PENCETAK_SURAT_PAKSA = :old.NIP;

    --  Delete all children in "TTR_SRT_TEGORAN"
    delete TTR_SRT_TEGORAN
    where  NIP_REKAM_TTR_SRT_TEGORAN = :old.NIP;

    --  Delete all children in "SRT_PERINTAH_SITA"
    delete SRT_PERINTAH_SITA
    where  NIP_PENCETAK_SPMP = :old.NIP;

    --  Delete all children in "SRT_PERINTAH_SITA"
    delete SRT_PERINTAH_SITA
    where  NIP_JURU_SITA = :old.NIP;

    --  Delete all children in "SRT_CABUT_SITA"
    delete SRT_CABUT_SITA
    where  NIP_PENCETAK_SRT_CABUT_SITA = :old.NIP;

    --  Delete all children in "PERMINTAAN_JADUAL_LELANG"
    delete PERMINTAAN_JADUAL_LELANG
    where  NIP_PENCETAK_SRT_PMT_JDL_LLG = :old.NIP;

    --  Delete all children in "SRT_BATAL_LELANG"
    delete SRT_BATAL_LELANG
    where  NIP_PENCETAK_SRT_BATAL_LELANG = :old.NIP;

    --  Delete all children in "SKKPP"
    delete SKKPP
    where  NIP_REKAM_SKKP = :old.NIP;

    --  Delete all children in "SPMKP"
    delete SPMKP
    where  NIP_REKAM_SPMKP = :old.NIP;

    --  Delete all children in "SPB"
    delete SPB
    where  NIP_REKAM_SPB = :old.NIP;

    --  Delete all children in "PENERIMAAN"
    delete PENERIMAAN
    where  NIP_REKAM_TRM_PENERIMAAN = :old.NIP;

    --  Delete all children in "PROGNOSA"
    delete PROGNOSA
    where  NIP_REKAM_TRM_PROGNOSA = :old.NIP;

    --  Delete all children in "SK_KANWIL"
    delete SK_KANWIL
    where  NIP_PENCETAK_SK_KANWIL = :old.NIP;

    --  Delete all children in "LOG_DBKB"
    delete LOG_DBKB
    where  NIP_PEREKAM_LOG_DBKB = :old.NIP;

    --  Delete all children in "LOG_ZNT"
    delete LOG_ZNT
    where  NIP_PEREKAM_LOG_ZNT = :old.NIP;

    --  Delete all children in "HIS_SPPT"
    delete HIS_SPPT
    where  HIS_NIP_PENCETAK_SPPT = :old.NIP;

    --  Delete all children in "PENGHAPUSAN_PIUTANG"
    delete PENGHAPUSAN_PIUTANG
    where  NIP_REKAM_PENGHAPUSAN_PIUTANG = :old.NIP;

    --  Delete all children in "HIS_SKP_SPOP"
    delete HIS_SKP_SPOP
    where  HIS_NIP_CETAK_SKP_SPOP = :old.NIP;

    --  Delete all children in "HIS_SKP_KURANG_BAYAR"
    delete HIS_SKP_KURANG_BAYAR
    where  HIS_NIP_PENCETAK_SKP_KB = :old.NIP;

    --  Delete all children in "HIS_STP"
    delete HIS_STP
    where  HIS_NIP_PENCETAK_STP = :old.NIP;

    --  Delete all children in "PEMBATALAN_SPMKP"
    delete PEMBATALAN_SPMKP
    where  NIP_PENCETAK_PEMBATALAN_SPMKP = :old.NIP;

    --  Delete all children in "TERIMA_PEMBAGIAN"
    delete TERIMA_PEMBAGIAN
    where  NIP_REKAM_TRM_BAGI = :old.NIP;

    --  Delete all children in "LAPORAN_PEMBAGIAN"
    delete LAPORAN_PEMBAGIAN
    where  NIP_REKAM_LAP_PEMBAGIAN = :old.NIP;

    --  Delete all children in "PENGHAPUSAN_OP"
    delete PENGHAPUSAN_OP
    where  NIP_PEREKAM_PENGHAPUSAN_OP = :old.NIP;

    --  Delete all children in "PENGHAPUSAN_BNG"
    delete PENGHAPUSAN_BNG
    where  NIP_PEREKAM_PENGHAPUSAN_BNG = :old.NIP;

    --  Delete all children in "BA_SITA"
    delete BA_SITA
    where  NIP_PEREKAM_BA_SITA = :old.NIP;

    --  Delete all children in "KEPUTUSAN_KEBERATAN_PBB"
    delete KEPUTUSAN_KEBERATAN_PBB
    where  NIP_PENCETAK_SK_KEBERATAN = :old.NIP;

    --  Delete all children in "PEMBETULAN_KEBERATAN"
    delete PEMBETULAN_KEBERATAN
    where  NIP_PENCETAK_PEMBETULAN = :old.NIP;

    --  Delete all children in "HIS_OBJEK_PAJAK"
    delete HIS_OBJEK_PAJAK
    where  HIS_NIP_PEREKAM_OP = :old.NIP;

    --  Delete all children in "HIS_OP_BNG"
    delete HIS_OP_BNG
    where  HIS_NIP_PEREKAM_BNG_AWAL = :old.NIP;

    --  Delete all children in "HIS_NILAI_INDIVIDU"
    delete HIS_NILAI_INDIVIDU
    where  HIS_NIP_PEREKAM_INDIVIDU = :old.NIP;

    --  Delete all children in "HIS_NILAI_INDIVIDU"
    delete HIS_NILAI_INDIVIDU
    where  HIS_NIP_PENILAI_INDIVIDU = :old.NIP;

    --  Delete all children in "TEMP_SPOP_LSPOP"
    delete TEMP_SPOP_LSPOP
    where  NIP_TRANSAKSI_TEMP = :old.NIP;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
