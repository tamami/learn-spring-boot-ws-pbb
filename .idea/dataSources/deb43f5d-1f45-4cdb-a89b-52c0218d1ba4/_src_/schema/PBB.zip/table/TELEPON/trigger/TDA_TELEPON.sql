create trigger TDA_TELEPON
	after delete
	on TELEPON
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "REK_TELEPON"
    delete REK_TELEPON
    where  KD_AREA = :old.KD_AREA
     and   NO_TELEPON = :old.NO_TELEPON;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
