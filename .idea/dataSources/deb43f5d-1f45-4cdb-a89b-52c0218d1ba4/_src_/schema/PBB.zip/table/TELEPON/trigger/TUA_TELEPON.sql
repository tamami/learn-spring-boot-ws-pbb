create trigger TUA_TELEPON
	after update
	on TELEPON
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "TELEPON" for all children in "REK_TELEPON"
    if (updating('KD_AREA') and :old.KD_AREA != :new.KD_AREA) or
       (updating('NO_TELEPON') and :old.NO_TELEPON != :new.NO_TELEPON) then
       update REK_TELEPON
        set   KD_AREA = :new.KD_AREA,
              NO_TELEPON = :new.NO_TELEPON
       where  KD_AREA = :old.KD_AREA
        and   NO_TELEPON = :old.NO_TELEPON;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
