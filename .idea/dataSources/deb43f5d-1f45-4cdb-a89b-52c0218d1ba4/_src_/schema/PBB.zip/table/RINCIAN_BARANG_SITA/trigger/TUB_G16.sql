create trigger TUB_G16
	before update of KD_KANWIL,KD_KPPBB,NO_BA_SITA,NO_URUT_BARANG_SITA
	on RINCIAN_BARANG_SITA
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "BA_SITA"
    cursor cpk1_rincian_barang_sita(var_kd_kanwil varchar,
                                    var_kd_kppbb varchar,
                                    var_no_ba_sita varchar) is
       select 1
       from   BA_SITA
       where  KD_KANWIL = var_kd_kanwil
        and   KD_KPPBB = var_kd_kppbb
        and   NO_BA_SITA = var_no_ba_sita
        and   var_kd_kanwil is not null
        and   var_kd_kppbb is not null
        and   var_no_ba_sita is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "BA_SITA" must exist when updating a child in "RINCIAN_BARANG_SITA"
    if (:new.KD_KANWIL is not null) and
       (:new.KD_KPPBB is not null) and
       (:new.NO_BA_SITA is not null) and (seq = 0) then
       open  cpk1_rincian_barang_sita(:new.KD_KANWIL,
                                      :new.KD_KPPBB,
                                      :new.NO_BA_SITA);
       fetch cpk1_rincian_barang_sita into dummy;
       found := cpk1_rincian_barang_sita%FOUND;
       close cpk1_rincian_barang_sita;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "BA_SITA". Cannot update child in "RINCIAN_BARANG_SITA".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
