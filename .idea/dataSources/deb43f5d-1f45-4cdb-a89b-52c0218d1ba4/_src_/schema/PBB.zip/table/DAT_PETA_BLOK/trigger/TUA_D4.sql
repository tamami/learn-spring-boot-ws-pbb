create trigger TUA_D4
	after update of KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK
	on DAT_PETA_BLOK
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAT_PETA_BLOK" for all children in "DAT_OBJEK_PAJAK"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) then
       update DAT_OBJEK_PAJAK
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK;
    end if;

    --  Modify parent code of "DAT_PETA_BLOK" for all children in "DAT_PETA_ZNT"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) then
       update DAT_PETA_ZNT
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK;
    end if;

    --  Modify parent code of "DAT_PETA_BLOK" for all children in "TEMP_ZNT_MASSAL"
    if (updating('KD_PROPINSI') and :old.KD_PROPINSI != :new.KD_PROPINSI) or
       (updating('KD_DATI2') and :old.KD_DATI2 != :new.KD_DATI2) or
       (updating('KD_KECAMATAN') and :old.KD_KECAMATAN != :new.KD_KECAMATAN) or
       (updating('KD_KELURAHAN') and :old.KD_KELURAHAN != :new.KD_KELURAHAN) or
       (updating('KD_BLOK') and :old.KD_BLOK != :new.KD_BLOK) then
       update TEMP_ZNT_MASSAL
        set   KD_PROPINSI = :new.KD_PROPINSI,
              KD_DATI2 = :new.KD_DATI2,
              KD_KECAMATAN = :new.KD_KECAMATAN,
              KD_KELURAHAN = :new.KD_KELURAHAN,
              KD_BLOK = :new.KD_BLOK
       where  KD_PROPINSI = :old.KD_PROPINSI
        and   KD_DATI2 = :old.KD_DATI2
        and   KD_KECAMATAN = :old.KD_KECAMATAN
        and   KD_KELURAHAN = :old.KD_KELURAHAN
        and   KD_BLOK = :old.KD_BLOK;
    end if;


    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
