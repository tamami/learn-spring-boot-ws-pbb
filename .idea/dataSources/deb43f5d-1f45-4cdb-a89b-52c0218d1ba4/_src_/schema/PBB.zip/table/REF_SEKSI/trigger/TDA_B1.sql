create trigger TDA_B1
	after delete
	on REF_SEKSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "BERKAS_TERIMA"
    delete BERKAS_TERIMA
    where  KD_SEKSI_TERIMA = :old.KD_SEKSI;

    --  Delete all children in "BERKAS_KIRIM"
    delete BERKAS_KIRIM
    where  KD_SEKSI = :old.KD_SEKSI;

    --  Delete all children in "REF_SUB_SEKSI"
    delete REF_SUB_SEKSI
    where  KD_SEKSI = :old.KD_SEKSI;

    --  Delete all children in "PST_DETAIL"
    delete PST_DETAIL
    where  KD_SEKSI_BERKAS = :old.KD_SEKSI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
