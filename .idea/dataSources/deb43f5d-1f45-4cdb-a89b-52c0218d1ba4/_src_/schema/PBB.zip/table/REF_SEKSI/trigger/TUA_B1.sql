create trigger TUA_B1
	after update of KD_SEKSI
	on REF_SEKSI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_SEKSI" for all children in "BERKAS_TERIMA"
    if (updating('KD_SEKSI') and :old.KD_SEKSI != :new.KD_SEKSI) then
       update BERKAS_TERIMA
        set   KD_SEKSI_TERIMA = :new.KD_SEKSI
       where  KD_SEKSI_TERIMA = :old.KD_SEKSI;
    end if;

    --  Modify parent code of "REF_SEKSI" for all children in "BERKAS_KIRIM"
    if (updating('KD_SEKSI') and :old.KD_SEKSI != :new.KD_SEKSI) then
       update BERKAS_KIRIM
        set   KD_SEKSI = :new.KD_SEKSI
       where  KD_SEKSI = :old.KD_SEKSI;
    end if;

    --  Modify parent code of "REF_SEKSI" for all children in "REF_SUB_SEKSI"
    if (updating('KD_SEKSI') and :old.KD_SEKSI != :new.KD_SEKSI) then
       update REF_SUB_SEKSI
        set   KD_SEKSI = :new.KD_SEKSI
       where  KD_SEKSI = :old.KD_SEKSI;
    end if;

    --  Modify parent code of "REF_SEKSI" for all children in "PST_DETAIL"
    if (updating('KD_SEKSI') and :old.KD_SEKSI != :new.KD_SEKSI) then
       update PST_DETAIL
        set   KD_SEKSI_BERKAS = :new.KD_SEKSI
       where  KD_SEKSI_BERKAS = :old.KD_SEKSI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
