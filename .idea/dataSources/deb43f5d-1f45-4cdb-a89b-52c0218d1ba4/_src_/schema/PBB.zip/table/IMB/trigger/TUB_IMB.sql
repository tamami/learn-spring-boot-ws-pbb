create trigger TUB_IMB
	before update of NO_IMB,KD_JNS_IMB,KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,NO_BNG
	on IMB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "JENIS_IMB"
    cursor cpk1_imb(var_kd_jns_imb varchar) is
       select 1
       from   JENIS_IMB
       where  KD_JNS_IMB = var_kd_jns_imb
        and   var_kd_jns_imb is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "DAT_OP_BANGUNAN"
    cursor cpk2_imb(var_kd_propinsi varchar,
                    var_kd_dati2 varchar,
                    var_kd_kecamatan varchar,
                    var_kd_kelurahan varchar,
                    var_kd_blok varchar,
                    var_no_urut varchar,
                    var_kd_jns_op varchar,
                    var_no_bng number) is
       select 1
       from   DAT_OP_BANGUNAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   KD_BLOK = var_kd_blok
        and   NO_URUT = var_no_urut
        and   KD_JNS_OP = var_kd_jns_op
        and   NO_BNG = var_no_bng
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null
        and   var_kd_blok is not null
        and   var_no_urut is not null
        and   var_kd_jns_op is not null
        and   var_no_bng is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "JENIS_IMB" must exist when updating a child in "IMB"
    if (:new.KD_JNS_IMB is not null) and (seq = 0) then
       open  cpk1_imb(:new.KD_JNS_IMB);
       fetch cpk1_imb into dummy;
       found := cpk1_imb%FOUND;
       close cpk1_imb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "JENIS_IMB". Cannot update child in "IMB".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "DAT_OP_BANGUNAN" must exist when updating a child in "IMB"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and
       (:new.KD_BLOK is not null) and
       (:new.NO_URUT is not null) and
       (:new.KD_JNS_OP is not null) and
       (:new.NO_BNG is not null) and (seq = 0) then
       open  cpk2_imb(:new.KD_PROPINSI,
                      :new.KD_DATI2,
                      :new.KD_KECAMATAN,
                      :new.KD_KELURAHAN,
                      :new.KD_BLOK,
                      :new.NO_URUT,
                      :new.KD_JNS_OP,
                      :new.NO_BNG);
       fetch cpk2_imb into dummy;
       found := cpk2_imb%FOUND;
       close cpk2_imb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "DAT_OP_BANGUNAN". Cannot update child in "IMB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
