create trigger TUA_C36
	after update of TYPE_KONSTRUKSI
	on DAYA_DUKUNG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "DAYA_DUKUNG" for all children in "DAT_JPB8"
    if (updating('TYPE_KONSTRUKSI') and :old.TYPE_KONSTRUKSI != :new.TYPE_KONSTRUKSI) then
       update DAT_JPB8
        set   TYPE_KONSTRUKSI = :new.TYPE_KONSTRUKSI
       where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;
    end if;

    --  Modify parent code of "DAYA_DUKUNG" for all children in "DAT_JPB3"
    if (updating('TYPE_KONSTRUKSI') and :old.TYPE_KONSTRUKSI != :new.TYPE_KONSTRUKSI) then
       update DAT_JPB3
        set   TYPE_KONSTRUKSI = :new.TYPE_KONSTRUKSI
       where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;
    end if;

    --  Modify parent code of "DAYA_DUKUNG" for all children in "DBKB_DAYA_DUKUNG"
    if (updating('TYPE_KONSTRUKSI') and :old.TYPE_KONSTRUKSI != :new.TYPE_KONSTRUKSI) then
       update DBKB_DAYA_DUKUNG
        set   TYPE_KONSTRUKSI = :new.TYPE_KONSTRUKSI
       where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;
    end if;

    --  Modify parent code of "DAYA_DUKUNG" for all children in "SIM_DBKB_DAYA_DUKUNG"
    if (updating('TYPE_KONSTRUKSI') and :old.TYPE_KONSTRUKSI != :new.TYPE_KONSTRUKSI) then
       update SIM_DBKB_DAYA_DUKUNG
        set   TYPE_KONSTRUKSI = :new.TYPE_KONSTRUKSI
       where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
