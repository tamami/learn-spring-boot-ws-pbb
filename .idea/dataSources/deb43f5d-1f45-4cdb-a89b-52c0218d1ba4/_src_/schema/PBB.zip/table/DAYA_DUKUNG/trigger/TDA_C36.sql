create trigger TDA_C36
	after delete
	on DAYA_DUKUNG
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "DAT_JPB8"
    delete DAT_JPB8
    where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;

    --  Delete all children in "DAT_JPB3"
    delete DAT_JPB3
    where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;

    --  Delete all children in "DBKB_DAYA_DUKUNG"
    delete DBKB_DAYA_DUKUNG
    where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;

    --  Delete all children in "SIM_DBKB_DAYA_DUKUNG"
    delete SIM_DBKB_DAYA_DUKUNG
    where  TYPE_KONSTRUKSI = :old.TYPE_KONSTRUKSI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
