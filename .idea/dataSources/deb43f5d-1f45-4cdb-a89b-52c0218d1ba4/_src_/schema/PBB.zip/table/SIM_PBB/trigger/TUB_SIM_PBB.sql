create trigger TUB_SIM_PBB
	before update
	on SIM_PBB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_KELURAHAN"
    cursor cpk1_sim_pbb(var_kd_propinsi varchar,
                        var_kd_dati2 varchar,
                        var_kd_kecamatan varchar,
                        var_kd_kelurahan varchar) is
       select 1
       from   REF_KELURAHAN
       where  KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   KD_KECAMATAN = var_kd_kecamatan
        and   KD_KELURAHAN = var_kd_kelurahan
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_kd_kecamatan is not null
        and   var_kd_kelurahan is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "REF_KELURAHAN" must exist when updating a child in "SIM_PBB"
    if (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.KD_KECAMATAN is not null) and
       (:new.KD_KELURAHAN is not null) and (seq = 0) then
       open  cpk1_sim_pbb(:new.KD_PROPINSI,
                          :new.KD_DATI2,
                          :new.KD_KECAMATAN,
                          :new.KD_KELURAHAN);
       fetch cpk1_sim_pbb into dummy;
       found := cpk1_sim_pbb%FOUND;
       close cpk1_sim_pbb;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_KELURAHAN". Cannot update child in "SIM_PBB".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;

