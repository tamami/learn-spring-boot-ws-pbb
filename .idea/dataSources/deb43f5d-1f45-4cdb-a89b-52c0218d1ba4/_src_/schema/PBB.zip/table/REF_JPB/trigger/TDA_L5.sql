create trigger TDA_L5
	after delete
	on REF_JPB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "BANGUNAN_LANTAI"
    delete BANGUNAN_LANTAI
    where  KD_JPB = :old.KD_JPB;

    --  Delete all children in "FAS_DEP_JPB_KLS_BINTANG"
    delete FAS_DEP_JPB_KLS_BINTANG
    where  KD_JPB = :old.KD_JPB;

    --  Delete all children in "DAT_OP_BANGUNAN"
    delete DAT_OP_BANGUNAN
    where  KD_JPB = :old.KD_JPB;

    --  Delete all children in "HIS_OP_BNG"
    delete HIS_OP_BNG
    where  KD_JPB = :old.KD_JPB;

    --  Delete all children in "SIM_FAS_DEP_JPB_KLS_BINTANG"
    delete SIM_FAS_DEP_JPB_KLS_BINTANG
    where  KD_JPB = :old.KD_JPB;

    --  Delete all children in "STA_NJOP_BNG"
    delete STA_NJOP_BNG
    where  KD_JPB = :old.KD_JPB;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
