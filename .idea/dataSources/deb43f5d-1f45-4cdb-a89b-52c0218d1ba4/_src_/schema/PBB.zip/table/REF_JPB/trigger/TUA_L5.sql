create trigger TUA_L5
	after update of KD_JPB
	on REF_JPB
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "REF_JPB" for all children in "BANGUNAN_LANTAI"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update BANGUNAN_LANTAI
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;

    --  Modify parent code of "REF_JPB" for all children in "FAS_DEP_JPB_KLS_BINTANG"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update FAS_DEP_JPB_KLS_BINTANG
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;

    --  Modify parent code of "REF_JPB" for all children in "DAT_OP_BANGUNAN"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update DAT_OP_BANGUNAN
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;

    --  Modify parent code of "REF_JPB" for all children in "HIS_OP_BNG"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update HIS_OP_BNG
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;

    --  Modify parent code of "REF_JPB" for all children in "SIM_FAS_DEP_JPB_KLS_BINTANG"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update SIM_FAS_DEP_JPB_KLS_BINTANG
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;

    --  Modify parent code of "REF_JPB" for all children in "STA_NJOP_BNG"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) then
       update STA_NJOP_BNG
        set   KD_JPB = :new.KD_JPB
       where  KD_JPB = :old.KD_JPB;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
