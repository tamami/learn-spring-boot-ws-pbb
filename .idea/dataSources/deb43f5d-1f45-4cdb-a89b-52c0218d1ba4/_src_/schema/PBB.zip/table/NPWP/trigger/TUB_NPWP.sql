create trigger TUB_NPWP
	before update
	on NPWP
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENDUDUK"
    cursor cpk1_npwp(var_no_penduduk varchar) is
       select 1
       from   PENDUDUK
       where  NO_PENDUDUK = var_no_penduduk
        and   var_no_penduduk is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "JENIS_KLU"
    cursor cpk2_npwp(var_kd_klu varchar) is
       select 1
       from   JENIS_KLU
       where  KD_KLU = var_kd_klu
        and   var_kd_klu is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PENDUDUK" must exist when updating a child in "NPWP"
    if (:new.NO_PENDUDUK is not null) and (seq = 0) then
       open  cpk1_npwp(:new.NO_PENDUDUK);
       fetch cpk1_npwp into dummy;
       found := cpk1_npwp%FOUND;
       close cpk1_npwp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENDUDUK". Cannot update child in "NPWP".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "JENIS_KLU" must exist when updating a child in "NPWP"
    if (:new.KD_KLU is not null) and (seq = 0) then
       open  cpk2_npwp(:new.KD_KLU);
       fetch cpk2_npwp into dummy;
       found := cpk2_npwp%FOUND;
       close cpk2_npwp;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "JENIS_KLU". Cannot update child in "NPWP".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
