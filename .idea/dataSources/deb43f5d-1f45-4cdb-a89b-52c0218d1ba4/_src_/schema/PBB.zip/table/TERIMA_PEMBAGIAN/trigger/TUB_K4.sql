create trigger TUB_K4
	before update of KD_SEKTOR,KD_PROPINSI,KD_DATI2,TAHUN_PEMBAGIAN,BULAN_PEMBAGIAN,MINGGU_KE_PEMBAGIAN,PEMBAGIAN_KE,KD_PENERIMA,NIP_REKAM_TRM_BAGI
	on TERIMA_PEMBAGIAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENERIMAAN"
    cursor cpk1_terima_pembagian(var_kd_sektor varchar,
                                 var_kd_propinsi varchar,
                                 var_kd_dati2 varchar,
                                 var_tahun_pembagian varchar,
                                 var_bulan_pembagian varchar,
                                 var_minggu_ke_pembagian varchar,
                                 var_pembagian_ke number) is
       select 1
       from   PENERIMAAN
       where  KD_SEKTOR = var_kd_sektor
        and   KD_PROPINSI = var_kd_propinsi
        and   KD_DATI2 = var_kd_dati2
        and   TAHUN_PENERIMAAN = var_tahun_pembagian
        and   BULAN_PENERIMAAN = var_bulan_pembagian
        and   MINGGU_KE_PENERIMAAN = var_minggu_ke_pembagian
        and   PENERIMAAN_KE = var_pembagian_ke
        and   var_kd_sektor is not null
        and   var_kd_propinsi is not null
        and   var_kd_dati2 is not null
        and   var_tahun_pembagian is not null
        and   var_bulan_pembagian is not null
        and   var_minggu_ke_pembagian is not null
        and   var_pembagian_ke is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PENERIMA"
    cursor cpk2_terima_pembagian(var_kd_penerima varchar) is
       select 1
       from   PENERIMA
       where  KD_PENERIMA = var_kd_penerima
        and   var_kd_penerima is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "PEGAWAI"
    cursor cpk3_terima_pembagian(var_nip_rekam_trm_bagi varchar) is
       select 1
       from   PEGAWAI
       where  NIP = var_nip_rekam_trm_bagi
        and   var_nip_rekam_trm_bagi is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "PENERIMAAN" must exist when updating a child in "TERIMA_PEMBAGIAN"
    if (:new.KD_SEKTOR is not null) and
       (:new.KD_PROPINSI is not null) and
       (:new.KD_DATI2 is not null) and
       (:new.TAHUN_PEMBAGIAN is not null) and
       (:new.BULAN_PEMBAGIAN is not null) and
       (:new.MINGGU_KE_PEMBAGIAN is not null) and
       (:new.PEMBAGIAN_KE is not null) and (seq = 0) then
       open  cpk1_terima_pembagian(:new.KD_SEKTOR,
                                   :new.KD_PROPINSI,
                                   :new.KD_DATI2,
                                   :new.TAHUN_PEMBAGIAN,
                                   :new.BULAN_PEMBAGIAN,
                                   :new.MINGGU_KE_PEMBAGIAN,
                                   :new.PEMBAGIAN_KE);
       fetch cpk1_terima_pembagian into dummy;
       found := cpk1_terima_pembagian%FOUND;
       close cpk1_terima_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENERIMAAN". Cannot update child in "TERIMA_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PENERIMA" must exist when updating a child in "TERIMA_PEMBAGIAN"
    if (:new.KD_PENERIMA is not null) and (seq = 0) then
       open  cpk2_terima_pembagian(:new.KD_PENERIMA);
       fetch cpk2_terima_pembagian into dummy;
       found := cpk2_terima_pembagian%FOUND;
       close cpk2_terima_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PENERIMA". Cannot update child in "TERIMA_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "PEGAWAI" must exist when updating a child in "TERIMA_PEMBAGIAN"
    if (:new.NIP_REKAM_TRM_BAGI is not null) and (seq = 0) then
       open  cpk3_terima_pembagian(:new.NIP_REKAM_TRM_BAGI);
       fetch cpk3_terima_pembagian into dummy;
       found := cpk3_terima_pembagian%FOUND;
       close cpk3_terima_pembagian;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "PEGAWAI". Cannot update child in "TERIMA_PEMBAGIAN".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
