create trigger TUA_G12
	after update of KD_KANWIL,KD_KPPBB,NO_SRT_TEGORAN,KD_PROPINSI,KD_DATI2,KD_KECAMATAN,KD_KELURAHAN,KD_BLOK,NO_URUT,KD_JNS_OP,THN_PAJAK_STP,NIP_PENCETAK_SRT_TEGORAN
	on SRT_TEGORAN
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "SRT_TEGORAN" for all children in "TTR_SRT_TEGORAN"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SRT_TEGORAN') and :old.NO_SRT_TEGORAN != :new.NO_SRT_TEGORAN) then
       update TTR_SRT_TEGORAN
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SRT_TEGORAN = :new.NO_SRT_TEGORAN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SRT_TEGORAN = :old.NO_SRT_TEGORAN;
    end if;

    --  Modify parent code of "SRT_TEGORAN" for all children in "SRT_PAKSA"
    if (updating('KD_KANWIL') and :old.KD_KANWIL != :new.KD_KANWIL) or
       (updating('KD_KPPBB') and :old.KD_KPPBB != :new.KD_KPPBB) or
       (updating('NO_SRT_TEGORAN') and :old.NO_SRT_TEGORAN != :new.NO_SRT_TEGORAN) then
       update SRT_PAKSA
        set   KD_KANWIL = :new.KD_KANWIL,
              KD_KPPBB = :new.KD_KPPBB,
              NO_SRT_TEGORAN = :new.NO_SRT_TEGORAN
       where  KD_KANWIL = :old.KD_KANWIL
        and   KD_KPPBB = :old.KD_KPPBB
        and   NO_SRT_TEGORAN = :old.NO_SRT_TEGORAN;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
