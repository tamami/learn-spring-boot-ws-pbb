create trigger TIB_REK_GAS
	before insert
	on REK_GAS
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

    --  Declaration of InsertChildParentExist constraint for the parent "GAS"
    cursor cpk1_rek_gas(var_no_pelanggan_gas varchar) is
       select 1
       from   GAS
       where  NO_PELANGGAN_GAS = var_no_pelanggan_gas
        and   var_no_pelanggan_gas is not null;

begin

    --  Parent "GAS" must exist when inserting a child in "REK_GAS"
    if :new.NO_PELANGGAN_GAS is not null then
       open  cpk1_rek_gas(:new.NO_PELANGGAN_GAS);
       fetch cpk1_rek_gas into dummy;
       found := cpk1_rek_gas%FOUND;
       close cpk1_rek_gas;
       if not found then
          errno  := -20002;
          errmsg := 'Parent does not exist in "GAS". Cannot create child in "REK_GAS".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
