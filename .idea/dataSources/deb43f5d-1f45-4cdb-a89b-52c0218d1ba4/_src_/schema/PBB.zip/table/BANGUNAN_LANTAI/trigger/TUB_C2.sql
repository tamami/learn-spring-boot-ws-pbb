create trigger TUB_C2
	before update of KD_JPB,TIPE_BNG,KD_BNG_LANTAI
	on BANGUNAN_LANTAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    seq NUMBER;

    --  Declaration of UpdateChildParentExist constraint for the parent "TIPE_BANGUNAN"
    cursor cpk1_bangunan_lantai(var_tipe_bng varchar) is
       select 1
       from   TIPE_BANGUNAN
       where  TIPE_BNG = var_tipe_bng
        and   var_tipe_bng is not null;

    --  Declaration of UpdateChildParentExist constraint for the parent "REF_JPB"
    cursor cpk2_bangunan_lantai(var_kd_jpb varchar) is
       select 1
       from   REF_JPB
       where  KD_JPB = var_kd_jpb
        and   var_kd_jpb is not null;

begin
    seq := IntegrityPackage.GetNestLevel;

    --  Parent "TIPE_BANGUNAN" must exist when updating a child in "BANGUNAN_LANTAI"
    if (:new.TIPE_BNG is not null) and (seq = 0) then
       open  cpk1_bangunan_lantai(:new.TIPE_BNG);
       fetch cpk1_bangunan_lantai into dummy;
       found := cpk1_bangunan_lantai%FOUND;
       close cpk1_bangunan_lantai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "TIPE_BANGUNAN". Cannot update child in "BANGUNAN_LANTAI".';
          raise integrity_error;
       end if;
    end if;

    --  Parent "REF_JPB" must exist when updating a child in "BANGUNAN_LANTAI"
    if (:new.KD_JPB is not null) and (seq = 0) then
       open  cpk2_bangunan_lantai(:new.KD_JPB);
       fetch cpk2_bangunan_lantai into dummy;
       found := cpk2_bangunan_lantai%FOUND;
       close cpk2_bangunan_lantai;
       if not found then
          errno  := -20003;
          errmsg := 'Parent does not exist in "REF_JPB". Cannot update child in "BANGUNAN_LANTAI".';
          raise integrity_error;
       end if;
    end if;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
