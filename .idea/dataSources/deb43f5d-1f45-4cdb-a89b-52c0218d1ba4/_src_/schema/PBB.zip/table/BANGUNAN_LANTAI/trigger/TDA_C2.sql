create trigger TDA_C2
	after delete
	on BANGUNAN_LANTAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    IntegrityPackage.NextNestLevel;

    --  Delete all children in "ADJ_LUAS"
    delete ADJ_LUAS
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;

    --  Delete all children in "ADJ_BANGUNAN"
    delete ADJ_BANGUNAN
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;

    --  Delete all children in "VOL_KEGIATAN"
    delete VOL_KEGIATAN
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;

    --  Delete all children in "DBKB_STANDARD"
    delete DBKB_STANDARD
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;

    --  Delete all children in "SIM_DBKB_STANDARD"
    delete SIM_DBKB_STANDARD
    where  KD_JPB = :old.KD_JPB
     and   TIPE_BNG = :old.TIPE_BNG
     and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
