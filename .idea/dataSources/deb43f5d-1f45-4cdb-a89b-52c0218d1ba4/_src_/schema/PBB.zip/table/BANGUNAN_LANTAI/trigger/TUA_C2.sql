create trigger TUA_C2
	after update of KD_JPB,TIPE_BNG,KD_BNG_LANTAI
	on BANGUNAN_LANTAI
	for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    IntegrityPackage.NextNestLevel;

    --  Modify parent code of "BANGUNAN_LANTAI" for all children in "ADJ_LUAS"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) then
       update ADJ_LUAS
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    end if;

    --  Modify parent code of "BANGUNAN_LANTAI" for all children in "ADJ_BANGUNAN"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) then
       update ADJ_BANGUNAN
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    end if;

    --  Modify parent code of "BANGUNAN_LANTAI" for all children in "VOL_KEGIATAN"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) then
       update VOL_KEGIATAN
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    end if;

    --  Modify parent code of "BANGUNAN_LANTAI" for all children in "DBKB_STANDARD"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) then
       update DBKB_STANDARD
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    end if;

    --  Modify parent code of "BANGUNAN_LANTAI" for all children in "SIM_DBKB_STANDARD"
    if (updating('KD_JPB') and :old.KD_JPB != :new.KD_JPB) or
       (updating('TIPE_BNG') and :old.TIPE_BNG != :new.TIPE_BNG) or
       (updating('KD_BNG_LANTAI') and :old.KD_BNG_LANTAI != :new.KD_BNG_LANTAI) then
       update SIM_DBKB_STANDARD
        set   KD_JPB = :new.KD_JPB,
              TIPE_BNG = :new.TIPE_BNG,
              KD_BNG_LANTAI = :new.KD_BNG_LANTAI
       where  KD_JPB = :old.KD_JPB
        and   TIPE_BNG = :old.TIPE_BNG
        and   KD_BNG_LANTAI = :old.KD_BNG_LANTAI;
    end if;
    IntegrityPackage.PreviousNestLevel;

--  Errors handling
exception
    when integrity_error then
       begin
       IntegrityPackage.InitNestLevel;
       raise_application_error(errno, errmsg);
       end;
end;
