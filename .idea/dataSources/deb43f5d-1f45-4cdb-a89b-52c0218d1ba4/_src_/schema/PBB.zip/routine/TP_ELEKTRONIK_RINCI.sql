create FUNCTION     tp_elektronik_rinci RETURN CHAR IS  
CURSOR c1 IS  
    SELECT a.kd_tp, a.nm_tp, b.atm, b.teller, b.internet, b.phone  
    FROM tempat_pembayaran a, tempat_pembayaran_elektronik b  
    WHERE a.kd_kanwil = b.kd_kanwil  
     AND a.kd_kppbb = b.kd_kppbb  
     AND a.kd_bank_tunggal = b.kd_bank_tunggal  
     AND a.kd_bank_persepsi = b.kd_bank_persepsi  
     AND a.kd_tp = b.kd_tp  
     AND b.kd_tampil = '1'  
    ORDER BY b.kd_urut_tampil;  
 
    hasil_atm VARCHAR2(255);  
    hasil_teller VARCHAR2(255);  
    hasil_internet VARCHAR2(255);  
    hasil_phone VARCHAR2(255);  
    hasil VARCHAR2(255);  
    hasil_sementara VARCHAR2(255);  
    hasil_akhir VARCHAR2(255);  
 
    nm_bank VARCHAR2(30);  
    v_atm CHAR(1);  
    v_teller CHAR(1);  
    v_internet CHAR(1); 
    v_phone CHAR(1); 
    v_kd_tp CHAR(2);  
    v_kd_prop CHAR(2);  
 
    v_hitung NUMBER;  
    v_total_length NUMBER; 
    v_posisi_koma NUMBER; 
    v_baris_length NUMBER; 
    v_cur_length NUMBER; 
    v_baris_ke NUMBER; 
 
    v_potong_baris1 NUMBER; 
    v_potong_baris2 NUMBER; 
    v_potong_baris3 NUMBER; 
    v_potong_baris4 NUMBER; 
    v_potong_baris5 NUMBER; 
    v_potong_baris6 NUMBER; 
    v_cur_char CHAR(1); 
 
BEGIN  
  hasil_atm := '';   
  hasil_teller := '';   
  hasil_internet := '';   
  hasil_phone := '';   
  hasil := '';  
  hasil_sementara := '';  
  hasil_akhir := '';  
 
  v_hitung := 0;  
  v_total_length := 0;  
  v_posisi_koma := 0;  
  v_baris_length := 0;  
  v_cur_length := 0;  
  v_baris_ke := 0;  
 
  v_potong_baris1 := 0; 
  v_potong_baris2 := 0; 
  v_potong_baris3 := 0; 
  v_potong_baris4 := 0; 
  v_potong_baris5 := 0; 
  v_potong_baris6 := 0; 
 
  SELECT DISTINCT kd_propinsi  
  INTO v_kd_prop  
  FROM ref_adm_kppbb;  
  
  OPEN c1;  
   
  LOOP  
    FETCH c1  
    INTO v_kd_tp, nm_bank, v_atm, v_teller, v_internet, v_phone;  
    EXIT WHEN c1 % NOTFOUND;  
  
  IF v_hitung = 0 THEN  
    IF v_atm <> '0' THEN hasil_atm := nm_bank;  END IF; 
    IF v_teller <> '0' THEN hasil_teller := nm_bank;  END IF; 
    IF v_internet <> '0' THEN hasil_internet := nm_bank;  END IF; 
    IF v_phone <> '0' THEN hasil_phone := nm_bank;  END IF; 
  ELSE  
  
    IF v_kd_prop = '35' THEN  
  
      IF v_kd_tp <> '05' AND v_kd_tp <> '08' THEN  
        IF v_atm <> '0' THEN  
            IF length(hasil_atm) > 1 THEN hasil_atm := hasil_atm || ','|| nm_bank;  
            ELSE hasil_atm := nm_bank; END IF; 
        END IF;  
        IF v_teller <> '0' THEN  
            IF length(hasil_teller) > 1 THEN hasil_teller := hasil_teller || ','|| nm_bank;  
            ELSE hasil_teller := nm_bank; END IF;  
        END IF; 
        IF v_internet <> '0' THEN  
            IF length(hasil_internet) > 1 THEN hasil_internet := hasil_internet || ','|| nm_bank;   
            ELSE hasil_internet := nm_bank; END IF;  
        END IF; 
        IF v_phone <> '0' THEN  
            IF length(hasil_phone) > 1 THEN hasil_phone := hasil_phone || ','|| nm_bank;   
            ELSE hasil_phone := nm_bank; END IF;  
        END IF; 
      END IF;  
  
      ELSIF v_kd_prop = '51' THEN  
  
        IF v_kd_tp <> '04' AND v_kd_tp <> '08' THEN  
            IF v_atm <> '0' THEN  
                IF length(hasil_atm) > 1 THEN hasil_atm := hasil_atm || ','|| nm_bank;  
                ELSE hasil_atm := nm_bank; END IF; 
            END IF;  
            IF v_teller <> '0' THEN  
                IF length(hasil_teller) > 1 THEN hasil_teller := hasil_teller || ','|| nm_bank;  
                ELSE hasil_teller := nm_bank; END IF; 
            END IF; 
            IF v_internet <> '0' THEN  
                IF length(hasil_internet) > 1 THEN hasil_internet := hasil_internet || ','|| nm_bank;   
                ELSE hasil_internet := nm_bank; END IF; 
            END IF; 
            IF v_phone <> '0' THEN  
                IF length(hasil_phone) > 1 THEN hasil_phone := hasil_phone || ','|| nm_bank;   
                ELSE hasil_phone := nm_bank; END IF; 
            END IF; 
        END IF;  
          
	  ELSIF v_kd_prop = '31' Then  
		  
         IF v_kd_tp <> '04' AND v_kd_tp <> '05' THEN  
            IF v_atm <> '0' THEN  
                IF length(hasil_atm) > 1 THEN hasil_atm := hasil_atm || ','|| nm_bank;  
                ELSE hasil_atm := nm_bank; END IF; 
            END IF;  
            IF v_teller <> '0' THEN  
                IF length(hasil_teller) > 1 THEN hasil_teller := hasil_teller || ','|| nm_bank;  
                ELSE hasil_teller := nm_bank; END IF; 
            END IF; 
            IF v_internet <> '0' THEN  
                IF length(hasil_internet) > 1 THEN hasil_internet := hasil_internet || ','|| nm_bank;   
                ELSE hasil_internet := nm_bank; END IF; 
            END IF; 
            IF v_phone <> '0' THEN  
                IF length(hasil_phone) > 1 THEN hasil_phone := hasil_phone || ','|| nm_bank;   
                ELSE hasil_phone := nm_bank; END IF; 
            END IF; 
         END IF;  
  
      ELSE  
  
        IF v_kd_tp <> '04' AND v_kd_tp <> '05' AND v_kd_tp <> '08' THEN  
            IF v_atm <> '0' THEN  
                IF length(hasil_atm) > 1 THEN hasil_atm := hasil_atm || ','|| nm_bank;  
                ELSE hasil_atm := nm_bank; END IF; 
            END IF;  
            IF v_teller <> '0' THEN  
                IF length(hasil_teller) > 1 THEN hasil_teller := hasil_teller || ','|| nm_bank;  
                ELSE hasil_teller := nm_bank; END IF; 
            END IF; 
            IF v_internet <> '0' THEN  
                IF length(hasil_internet) > 1 THEN hasil_internet := hasil_internet || ','|| nm_bank;   
                ELSE hasil_internet := nm_bank; END IF; 
            END IF; 
            IF v_phone <> '0' THEN  
                IF length(hasil_phone) > 1 THEN hasil_phone := hasil_phone || ','|| nm_bank;   
                ELSE hasil_phone := nm_bank; END IF; 
            END IF; 
        END IF;  
  
      END IF;  
  
    END IF;  
  
    v_hitung := v_hitung + 1;  
  END LOOP;  
  
  CLOSE c1;  
   
  IF length(hasil_atm) > 1 THEN hasil := 'ATM:'|| hasil_atm; END IF; 
  IF length(hasil_teller) > 1 THEN  
     IF length(hasil) > 1 THEN hasil := hasil || '; '; END IF; 
     hasil := hasil || 'TELLER:'|| hasil_teller;  
  END IF; 
  IF length(hasil_internet) > 1 THEN  
     IF length(hasil) > 1 THEN hasil := hasil || '; '; END IF; 
     hasil := hasil || 'INTERNET:'|| hasil_internet;  
  END IF; 
  IF length(hasil_phone) > 1 THEN  
     IF length(hasil) > 1 THEN hasil := hasil || '; '; END IF; 
     hasil := hasil || 'PHONE:'|| hasil_phone;  
  END IF; 
 
  v_total_length := length(hasil); 
   
  IF v_total_length > 0 THEN 
      
     v_hitung := 1; 
     v_baris_ke := 1; 
      
     LOOP 
      
        v_cur_char := substr(hasil, v_hitung, 1); 
         
        IF v_cur_char IN (',', ' ', ':', ';') THEN 
           v_posisi_koma := v_baris_length;  
        END IF; 
         
        IF v_hitung = v_total_length THEN 
           --dbms_output.put_line('akhir'); 
           --IF v_potong_baris6 = 0 THEN v_cur_length := v_potong_baris5; END IF; 
           IF v_potong_baris5 = 0 THEN v_cur_length := v_potong_baris4; END IF; 
           IF v_potong_baris4 = 0 THEN v_cur_length := v_potong_baris3; END IF; 
           IF v_potong_baris3 = 0 THEN v_cur_length := v_potong_baris2; END IF; 
           IF v_potong_baris2 = 0 THEN v_cur_length := v_potong_baris1; END IF; 
           --dbms_output.put_line(v_cur_length); 
           --dbms_output.put_line(v_baris_length); 
           IF v_baris_length < 7 THEN  
              hasil_akhir := hasil_akhir || '       ' || substr(hasil, v_total_length - v_baris_length + 1, v_baris_length); 
           ELSE 
              hasil_akhir := hasil_akhir || substr(hasil, v_total_length - v_baris_length + 1, v_baris_length); 
           END IF; 
        ELSE 
           IF v_baris_length > 32 then 
              --dbms_output.put_line('baris ke-'||v_baris_ke); 
               IF v_baris_ke = 1 THEN  
                  v_potong_baris1 := v_posisi_koma + 1;  
                  hasil_akhir := substr(hasil, 1, v_posisi_koma+1) || ' '; 
                  --dbms_output.put_line(hasil_akhir); 
               END IF; 
 
               IF v_baris_ke = 2 THEN  
                  v_potong_baris2 := v_potong_baris1 + v_posisi_koma;  
                  hasil_akhir := hasil_akhir || substr(hasil, v_potong_baris1+1, v_posisi_koma) || ' '; 
                  --dbms_output.put_line(hasil_akhir); 
               END IF; 
 
               IF v_baris_ke = 3 THEN  
                  v_potong_baris3 := v_potong_baris2 + v_posisi_koma + 1;  
                  hasil_akhir := hasil_akhir || substr(hasil, v_potong_baris2+1, v_posisi_koma) || ' '; 
                  --dbms_output.put_line(hasil_akhir); 
               END IF; 
 
               IF v_baris_ke = 4 THEN  
                  v_potong_baris4 := v_potong_baris3 + v_posisi_koma;  
                  hasil_akhir := hasil_akhir || substr(hasil, v_potong_baris3, v_posisi_koma) || ' '; 
                  --dbms_output.put_line(hasil_akhir); 
               END IF; 
 
               IF v_baris_ke = 5 THEN  
                  v_potong_baris5 := v_potong_baris4 + v_posisi_koma + 1;  
                  hasil_akhir := hasil_akhir || substr(hasil, v_potong_baris4, v_posisi_koma); 
                  --dbms_output.put_line(hasil_akhir); 
               END IF; 
 
               --IF v_baris_ke = 6 THEN  
               --   v_potong_baris6 := v_potong_baris5 + v_posisi_koma + 1;  
               --   hasil_akhir := hasil_akhir || substr(hasil, v_potong_baris5, v_posisi_koma) || ' '; 
               --   dbms_output.put_line(hasil_akhir); 
               --END IF; 
 
               v_hitung := v_hitung - (v_baris_length - v_posisi_koma); 
               v_baris_length := 0; 
               v_baris_ke := v_baris_ke + 1; 
                
            END IF; 
             
            v_baris_length := v_baris_length + 1; 
             
        END IF; 
         
        --hasil_sementara := hasil_sementara || v_cur_char; 
 
        EXIT WHEN v_hitung = v_total_length; 
        v_hitung := v_hitung + 1; 
      
     END LOOP; 
   
  END IF; 
  
  RETURN hasil_akhir;  
END; 