create procedure catat_pasca_pembatalan_sppt
  (VIN_TAHUN_PELAYANAN IN HIS_PERUBAHAN_SPPT.TAHUN_PELAYANAN%TYPE,
   VIN_BUNDEL_PELAYANAN IN HIS_PERUBAHAN_SPPT.TAHUN_PELAYANAN%TYPE,
   VIN_NO_URUT_PELAYANAN IN HIS_PERUBAHAN_SPPT.TAHUN_PELAYANAN%TYPE,
   VIN_KD_PROPINSI_lama IN HIS_PERUBAHAN_SPPT.KD_PROPINSI_BARU%TYPE,
   VIN_KD_DATI2_lama IN HIS_PERUBAHAN_SPPT.KD_DATI2_BARU%TYPE,
   VIN_KD_KECAMATAN_lama IN HIS_PERUBAHAN_SPPT.KD_KECAMATAN_BARU%TYPE,
   VIN_KD_KELURAHAN_lama IN HIS_PERUBAHAN_SPPT.KD_KELURAHAN_BARU%TYPE,
   VIN_KD_BLOK_lama IN HIS_PERUBAHAN_SPPT.KD_BLOK_BARU%TYPE,
   VIN_NO_URUT_lama IN HIS_PERUBAHAN_SPPT.NO_URUT_BARU%TYPE,
   VIN_KD_JNS_OP_lama IN HIS_PERUBAHAN_SPPT.KD_JNS_OP_BARU%TYPE,
   VIN_THN_PAJAK IN HIS_PERUBAHAN_SPPT.THN_PAJAK%TYPE) is
  
begin
    
  -- catat perubahannya ke tabel his_perubahan_sppt yuks.. 
  begin
    update his_perubahan_sppt
    set nama_wp_baru = '-', alamat_wp_baru = '-', pbb_baru = 0
    where kd_propinsi_lama = vin_kd_propinsi_lama
      and kd_dati2_lama = vin_kd_dati2_lama
      and kd_kecamatan_lama = vin_kd_kecamatan_lama
      and kd_kelurahan_lama = vin_kd_kelurahan_lama
      and kd_blok_lama = vin_kd_blok_lama
      and no_urut_lama = vin_no_urut_lama
      and kd_jns_op_lama = vin_kd_jns_op_lama
      and thn_pajak = vin_thn_pajak
      and tahun_pelayanan = vin_tahun_pelayanan
      and bundel_pelayanan = vin_bundel_pelayanan
      and no_urut_pelayanan = vin_no_urut_pelayanan;
    commit;
  end;
end catat_pasca_pembatalan_sppt;