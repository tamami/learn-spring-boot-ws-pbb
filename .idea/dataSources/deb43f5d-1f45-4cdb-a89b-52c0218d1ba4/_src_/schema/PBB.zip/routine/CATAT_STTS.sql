create procedure catat_stts
    (v_kd_propinsi in    char,
	 v_kd_dati2    in   char,
	 v_kd_kecamatan in  char,
	 v_kd_kelurahan  in char,
	 v_thn_pajak_sppt in char,
	 v_tgl_bayar       in date,
	 vln_totap_pbb_out    out number) IS
     cursor c_nop is
	   select kd_propinsi,
	          kd_dati2,
	          kd_kecamatan,
              kd_kelurahan,
              kd_blok,no_urut,
              kd_jns_op,
              thn_pajak_sppt,
              to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt)
       from   sppt
       where  kd_propinsi    = v_kd_propinsi  and
              kd_dati2       = v_kd_dati2     and
              kd_kecamatan   = v_kd_kecamatan and
              kd_kelurahan   = v_kd_kelurahan and
              thn_pajak_sppt = substr((to_char(v_tgl_bayar,
                                       'DD/MM/YYYY')),7,4) and
              status_pembayaran_sppt = '0';

	vlc_kd_propinsi        sppt.kd_propinsi%type;
    vlc_kd_dati2           sppt.kd_dati2%type;
    vlc_kd_kecamatan       sppt.kd_kecamatan%type;
    vlc_kd_kelurahan       sppt.kd_kelurahan%type;
    vlc_kd_blok            sppt.kd_blok%type;
    vlc_no_urut            sppt.no_urut%type;
    vlc_kd_jns_op          sppt.kd_jns_op%type;
    vlc_thn_pajak_sppt     sppt.thn_pajak_sppt%type;
	vln_beda_tgl           number;

	cursor c_nop_tanpa_denda is
	   select kd_propinsi,
	          kd_dati2,
	          kd_kecamatan,
              kd_kelurahan,
              kd_blok,no_urut,
              kd_jns_op,
              thn_pajak_sppt,
              to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt)
       from   sppt
       where  kd_propinsi    = vlc_kd_propinsi  and
              kd_dati2       = vlc_kd_dati2     and
              kd_kecamatan   = vlc_kd_kecamatan and
              kd_kelurahan   = vlc_kd_kelurahan and
              thn_pajak_sppt = substr((to_char(v_tgl_bayar,
                                       'DD/MM/YYYY')),7,4) and
              status_pembayaran_sppt = '0'          and
              to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt) <= 0;

    vlc_kd_propinsi1        sppt.kd_propinsi%type;
    vlc_kd_dati21           sppt.kd_dati2%type;
    vlc_kd_kecamatan1       sppt.kd_kecamatan%type;
    vlc_kd_kelurahan1       sppt.kd_kelurahan%type;
    vlc_kd_blok1            sppt.kd_blok%type;
    vlc_no_urut1            sppt.no_urut%type;
    vlc_kd_jns_op1          sppt.kd_jns_op%type;
    vlc_thn_pajak_sppt1     sppt.thn_pajak_sppt%type;
    vln_beda_tgl1           number;

    cursor c_nop_dengan_denda is
       select kd_propinsi,
	          kd_dati2,
	          kd_kecamatan,
              kd_kelurahan,
              kd_blok,no_urut,
              kd_jns_op,
              thn_pajak_sppt,
              to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt)
       from   sppt
       where  kd_propinsi    = vlc_kd_propinsi  and
              kd_dati2       = vlc_kd_dati2     and
              kd_kecamatan   = vlc_kd_kecamatan and
              kd_kelurahan   = vlc_kd_kelurahan and
              thn_pajak_sppt = substr((to_char(v_tgl_bayar,
                                     'DD/MM/YYYY')),7,4) and
              status_pembayaran_sppt = '0'          and
              to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt) > 0;

    vlc_kd_propinsi2        sppt.kd_propinsi%type;
    vlc_kd_dati22           sppt.kd_dati2%type;
    vlc_kd_kecamatan2       sppt.kd_kecamatan%type;
    vlc_kd_kelurahan2       sppt.kd_kelurahan%type;
    vlc_kd_blok2            sppt.kd_blok%type;
    vlc_no_urut2            sppt.no_urut%type;
    vlc_kd_jns_op2          sppt.kd_jns_op%type;
    vlc_thn_pajak_sppt2     sppt.thn_pajak_sppt%type;
    vln_beda_tgl2           number;

    cursor c_pbb_tanpa_denda is
       select pbb_terhutang_sppt
       from sppt
       where kd_propinsi    = vlc_kd_propinsi1  and
             kd_dati2       = vlc_kd_dati21     and
             kd_kecamatan   = vlc_kd_kecamatan1 and
             kd_kelurahan   = vlc_kd_kelurahan1 and
             kd_blok        = vlc_kd_blok1      and
             no_urut        = vlc_no_urut1      and
             kd_jns_op      = vlc_kd_jns_op1    and
             thn_pajak_sppt = substr((to_char(v_tgl_bayar,
                                      'DD/MM/YYYY')),7,4) and
             status_pembayaran_sppt = '0'       and
             to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt) <= 0;

    vln_pbb_tanpa_denda       sppt.pbb_terhutang_sppt%type;
    vln_total_pbb_tanpa_denda sppt.pbb_terhutang_sppt%type;

    vln_sisa_bln_denda_sppt     number;
    vln_bln_denda_sppt          number;

    cursor c_pbb_dengan_denda is
       select pbb_terhutang_sppt + (vln_bln_denda_sppt *
                                    pbb_terhutang_sppt)
       from sppt
       where kd_propinsi    = vlc_kd_propinsi2  and
             kd_dati2       = vlc_kd_dati22     and
             kd_kecamatan   = vlc_kd_kecamatan2 and
             kd_kelurahan   = vlc_kd_kelurahan2 and
             kd_blok        = vlc_kd_blok2      and
             no_urut        = vlc_no_urut2      and
             kd_jns_op      = vlc_kd_jns_op2    and
             thn_pajak_sppt = substr((to_char(v_tgl_bayar,
                                     'DD/MM/YYYY')),7,4) and
             status_pembayaran_sppt = '0'       and
             to_number(v_tgl_bayar-tgl_jatuh_tempo_sppt) > 0;

    vln_pbb_dengan_denda        sppt.pbb_terhutang_sppt%type;
    vln_total_pbb_dengan_denda  sppt.pbb_terhutang_sppt%type;

    vln_totap_pbb               sppt.pbb_terhutang_sppt%type;

BEGIN
  --cari nop apakah telah jatuh tempo atau belum
  open c_nop;
  loop
  	fetch c_nop
    into vlc_kd_propinsi,
		     vlc_kd_dati2,
		     vlc_kd_kecamatan,
		     vlc_kd_kelurahan,
		     vlc_kd_blok,
		     vlc_no_urut,
		     vlc_kd_jns_op,
		     vlc_thn_pajak_sppt,
	       vln_beda_tgl;

		--cari nop yang belum jatuh tempo
		if vln_beda_tgl <= 0 then
		begin
			open c_nop_tanpa_denda;
			loop
				fetch c_nop_tanpa_denda
				into vlc_kd_propinsi1,
				     vlc_kd_dati21,
				     vlc_kd_kecamatan1,
				     vlc_kd_kelurahan1,
				     vlc_kd_blok1,
				     vlc_no_urut1,
				     vlc_kd_jns_op1,
				     vlc_thn_pajak_sppt1,
			         vln_beda_tgl1;

			  --jumlah pbb tanpa denda
			  vln_total_pbb_tanpa_denda := 0;
			  open c_pbb_tanpa_denda;
			  loop
			  	fetch c_pbb_tanpa_denda
			  	into vln_pbb_tanpa_denda;

          vln_total_pbb_tanpa_denda := vln_total_pbb_tanpa_denda +
                                       vln_pbb_tanpa_denda;

			  exit when c_pbb_tanpa_denda%notfound;
			  end loop;
			  close c_pbb_tanpa_denda;

			exit when c_pbb_tanpa_denda%notfound;
			end loop;
			close c_nop_tanpa_denda;
		end;
		end if;

		--cari nop yang telah jatuh tempo
		if vln_beda_tgl > 0 then
		begin
			open c_nop_dengan_denda;
			loop
				fetch c_nop_dengan_denda
				into vlc_kd_propinsi2,
				     vlc_kd_dati22,
				     vlc_kd_kecamatan2,
				     vlc_kd_kelurahan2,
				     vlc_kd_blok2,
				     vlc_no_urut2,
				     vlc_kd_jns_op2,
				     vlc_thn_pajak_sppt2,
			       vln_beda_tgl2;

			  vln_sisa_bln_denda_sppt := mod(vln_beda_tgl2,30);
			  if vln_sisa_bln_denda_sppt > 0 then
			  	 vln_bln_denda_sppt := round(vln_beda_tgl2/30) + 1;
			  else
			     vln_bln_denda_sppt := round(vln_beda_tgl2/30);
			  end if;

			  --jumlah pbb dengan denda
			  vln_total_pbb_dengan_denda := 0;
			  open c_pbb_dengan_denda;
			  loop
			  	fetch c_pbb_dengan_denda
			  	into vln_pbb_dengan_denda;

			    vln_total_pbb_dengan_denda := vln_total_pbb_dengan_denda +
			                                  vln_pbb_dengan_denda;

			    exit when c_pbb_dengan_denda%notfound;
			  end loop;
			  close c_pbb_dengan_denda;

			exit when c_nop_dengan_denda%notfound;
			end loop;
			close c_nop_dengan_denda;
		end;
		end if;

		vln_totap_pbb := vln_total_pbb_tanpa_denda +
		                 vln_total_pbb_dengan_denda;

		exit when c_nop%notfound;
  end loop;
  vln_totap_pbb_out := vln_totap_pbb;
 -- dbms_output.put_line('Nilai : '||vln_totap_pbb_out);
  close c_nop;


  exception
      when no_data_found then vln_totap_pbb_out := 0;


END catat_stts;
