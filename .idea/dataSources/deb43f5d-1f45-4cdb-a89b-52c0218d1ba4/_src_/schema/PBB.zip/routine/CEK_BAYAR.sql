create PROCEDURE     cek_bayar (vlc_nop IN CHAR,
 vlc_tahun IN CHAR,
 vln_nilai_skkpp OUT NUMBER)IS
vln_pbb_sppt     sppt.pbb_yg_harus_dibayar_sppt%type;
vln_total_pajak  sppt.pbb_yg_harus_dibayar_sppt%type;
vln_bayar_sppt   pembayaran_sppt.jml_sppt_yg_dibayar%type;
vln_bayar_stp    pembayaran_stp.jml_stp_yg_dibayar%type;
vln_bayar_skp_kb pembayaran_skp_kb.jml_skp_kb_yg_dibayar%type;
vln_total_bayar  sppt.pbb_yg_harus_dibayar_sppt%type;
--vln_nilai_skkpp  sppt.pbb_yg_harus_dibayar_sppt%type;


BEGIN
 --cari jumlah pbb yg harus_dibayar
 BEGIN
		SELECT pbb_yg_harus_dibayar_sppt
		INTO vln_pbb_sppt
		FROM sppt p
		WHERE p.kd_propinsi 		= substr(vlc_nop,1,2) AND
			p.kd_dati2 		= substr(vlc_nop,3,2) AND
			p.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			P.kd_kelurahan 		= substr(vlc_nop,8,3) AND
			p.kd_blok 		= substr(vlc_nop,11,3) AND
			p.no_urut 		= substr(vlc_nop,14,4) AND
			p.kd_jns_op 		= substr(vlc_nop,18,1) AND
			p.thn_pajak_sppt 	= vlc_tahun;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
			vln_pbb_sppt    := 0;
	END;
	-- DBMS_OUTPUT.PUT_LINE('Pajak yang harus di bayar : '||to_char(vln_pbb_sppt));
  --akhir cari jumlah pbb yg harus_dibayar

  --cek jumlah pemabayaran
  BEGIN

			BEGIN
				SELECT sum(jml_sppt_yg_dibayar)
				INTO vln_bayar_sppt
				FROM pembayaran_sppt a
				WHERE   a.kd_propinsi 		= substr(vlc_nop,1,2) AND
						a.kd_dati2 		= substr(vlc_nop,3,2) AND
						a.kd_kecamatan   	= substr(vlc_nop,5,3) AND
						a.kd_kelurahan 		= substr(vlc_nop,8,3) AND
						a.kd_blok 		= substr(vlc_nop,11,3) AND
						a.no_urut 		= substr(vlc_nop,14,4) AND
						a.kd_jns_op 		= substr(vlc_nop,18,1) AND
						a.thn_pajak_sppt 	= vlc_tahun;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
					vln_bayar_sppt    := 0;
			END;

			BEGIN
				SELECT sum(jml_stp_yg_dibayar)
				INTO vln_bayar_stp
				FROM pembayaran_stp b
				WHERE   b.kd_propinsi 		= substr(vlc_nop,1,2) AND
						b.kd_dati2 		= substr(vlc_nop,3,2) AND
						b.kd_kecamatan   	= substr(vlc_nop,5,3) AND
						b.kd_kelurahan 		= substr(vlc_nop,8,3) AND
						b.kd_blok 		= substr(vlc_nop,11,3) AND
						b.no_urut 		= substr(vlc_nop,14,4) AND
						b.kd_jns_op 		= substr(vlc_nop,18,1);
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
					vln_bayar_stp := 0;
			END;

			BEGIN
				SELECT sum(jml_skp_kb_yg_dibayar)
				INTO vln_bayar_skp_kb
				FROM pembayaran_skp_kb c
				WHERE   c.kd_propinsi 		= substr(vlc_nop,1,2) AND
					    c.kd_dati2 		= substr(vlc_nop,3,2) AND
						c.kd_kecamatan   	= substr(vlc_nop,5,3) AND
						c.kd_kelurahan 		= substr(vlc_nop,8,3) AND
						c.kd_blok 		= substr(vlc_nop,11,3) AND
						c.no_urut 		= substr(vlc_nop,14,4) AND
						c.kd_jns_op 		= substr(vlc_nop,18,1) AND
						c.thn_pajak_skp_kb 	= vlc_tahun;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
					vln_bayar_skp_kb := 0;
			END;
      vln_total_bayar := nvl(vln_bayar_sppt,0) +
						nvl(vln_bayar_stp,0) +
						nvl(vln_bayar_skp_kb,0);
  -- DBMS_OUTPUT.PUT_LINE('Pajak yang telah di bayar : '||to_char(vln_total_bayar));
  END;
    -- akhir cari total pembayaran
	vln_nilai_skkpp := (vln_total_bayar - vln_pbb_sppt);

EXCEPTION
	WHEN OTHERS THEN
	vln_nilai_skkpp := 0;

---- DBMS_OUTPUT.PUT_LINE('Selisih Pajak yang di bayar : '||to_char(vln_nilai_skkpp));
END cek_bayar;