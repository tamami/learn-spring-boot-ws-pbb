create FUNCTION conv_n10
(v_input VARCHAR2, v_base NUMBER) RETURN NUMBER IS
v_error_code   NUMBER;
v_error_text   VARCHAR2(200);
v_input1 	   VARCHAR2(11) := v_input;
v_panjang 	   NUMBER ;
v_hasil		   NUMBER:= 0;
v_digit1  	   VARCHAR2(30);
v_digit2       VARCHAR2(2):= '  ';
v_putaran	   NUMBER := 0;

BEGIN

v_panjang := length(v_input1);
v_putaran := v_panjang - 1;

FOR	v_loop IN REVERSE 0..v_putaran LOOP
		v_digit1	:= substr(v_input1,(v_panjang - v_loop),1);

		IF v_digit1 IN ('0','1','2','3','4','5','6','7','8','9') THEN
		   v_digit2 := (v_digit1);
		ELSE
			BEGIN
			 SELECT bilangan_10
			 INTO v_digit2
			 FROM konversi_desimal
			 WHERE  bilangan_62 =  v_digit1;
		   END;
		END IF;

		v_hasil	 :=  (v_hasil) + (to_number(v_digit2) * (POWER( v_base, v_loop)));

END LOOP;

RETURN (V_HASIL);

EXCEPTION
   WHEN OTHERS THEN
      v_error_code := SQLCODE;
	  v_error_text := substr(SQLERRM, 1, 200);

END;
