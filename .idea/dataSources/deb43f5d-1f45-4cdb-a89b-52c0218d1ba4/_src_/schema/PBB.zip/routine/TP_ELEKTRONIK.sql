create FUNCTION tp_elektronik RETURN CHAR IS CURSOR c1 IS 
SELECT a.kd_tp, 
  a.nm_tp 
FROM tempat_pembayaran a, 
  tempat_pembayaran_elektronik b 
WHERE a.kd_kanwil = b.kd_kanwil 
 AND a.kd_kppbb = b.kd_kppbb 
 AND a.kd_bank_tunggal = b.kd_bank_tunggal 
 AND a.kd_bank_persepsi = b.kd_bank_persepsi 
 AND a.kd_tp = b.kd_tp 
 AND b.kd_tampil = '1' 
ORDER BY b.kd_urut_tampil; 
hasil VARCHAR2(255); 
nm_bank VARCHAR2(30); 
v_kd_tp CHAR(2); 
v_kd_prop CHAR(2); 
v_hitung NUMBER(2); 
BEGIN 
  hasil := ''; 
  v_hitung := 0; 
  SELECT DISTINCT kd_propinsi 
  INTO v_kd_prop 
  FROM ref_adm_kppbb; 
 
  OPEN c1; 
  LOOP 
    FETCH c1 
    INTO v_kd_tp, 
      nm_bank; 
    EXIT 
  WHEN c1 % NOTFOUND; 
 
  IF v_hitung = 0 THEN 
    hasil := nm_bank; 
  ELSE 
 
    IF v_kd_prop = '35' THEN 
 
      IF v_kd_tp <> '05' AND v_kd_tp <> '08' THEN 
        hasil := hasil || ', ' || nm_bank; 
      END IF; 
 
      ELSIF v_kd_prop = '51' THEN 
 
        IF v_kd_tp <> '04' AND v_kd_tp <> '08' THEN 
          hasil := hasil || ', ' || nm_bank; 
        END IF; 
         
	  ELSIF v_kd_prop = '31' Then 
		 
         IF v_kd_tp <> '04' AND v_kd_tp <> '05' THEN 
          hasil := hasil || ', ' || nm_bank; 
         END IF; 
 
      ELSE 
 
        IF v_kd_tp <> '04' AND v_kd_tp <> '05' AND v_kd_tp <> '08' THEN 
          hasil := hasil || ', ' || nm_bank; 
        END IF; 
 
      END IF; 
 
    END IF; 
 
    v_hitung := v_hitung + 1; 
  END LOOP; 
 
  CLOSE c1; 
  RETURN hasil; 
END; 
