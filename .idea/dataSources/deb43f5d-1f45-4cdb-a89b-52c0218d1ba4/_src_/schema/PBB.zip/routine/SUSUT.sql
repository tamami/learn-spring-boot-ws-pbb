create FUNCTION SUSUT
   (vlc_tahun 	  	   IN VARCHAR2,
    vlc_tahun_dibangun IN VARCHAR2,
    vlc_tahun_renovasi IN VARCHAR2,
	vlc_kondisi_bng    IN VARCHAR2,
	vln_nilai 		   IN NUMBER,
	vln_luas_bng 	   IN NUMBER,
	vln_flag_standard  IN NUMBER) -- 1 = bangunan standart, 0 = non standart
	RETURN NUMBER IS

	VLN_LUAS_BANGUNAN         NUMBER(12);
	vln_umur_efektif  	   	  NUMBER(4);
	vln_biaya_pengganti_baru  NUMBER(15);
	vln_persentase_susut 	  NUMBER(2);
	vln_tahun 				  NUMBER(4) := NVL(TO_NUMBER(vlc_tahun), 0);
	vln_tahun_dibangun 		  NUMBER(4) := NVL(TO_NUMBER(vlc_tahun_dibangun), 0);
	vln_tahun_renovasi 		  NUMBER(4) := NVL(TO_NUMBER(vlc_tahun_renovasi), 0);
	vlc_kd_range_penyusutan   range_penyusutan.kd_range_penyusutan%type;

/*-----------------------------
 DIBUAT OLEH : MADE
 TANGGAL     :
 REVISI KE   : 2
 DIREVISI    : TEGUH, RAHMAT, RUSLAN
 TGL. REVISI : 19-10-2000
*/-----------------------------

BEGIN
  ------------------------------------------------------------
  --- mencari umur efektif
  ------------------------------------------------------------
  IF vln_flag_standard = 0 THEN
    ------------------------------------------------------------
    -- jika bangunan non standart
    ------------------------------------------------------------
	IF vln_tahun_dibangun > 0 THEN
  	   ------------------------------------------------------------
	   -- jika tahun dibangun ada
  	   ------------------------------------------------------------
	   IF vln_tahun_renovasi > 0 THEN
  	   	  ------------------------------------------------------------
		  -- jika tahun renovasi ada
  		  ------------------------------------------------------------
		  IF (vln_tahun - vln_tahun_renovasi) > 10 THEN
  		  	 ------------------------------------------------------------
			 -- (jika tahun pajak - tahun renovasi) > 10
  		  	 ------------------------------------------------------------
			 vln_umur_efektif := ROUND(((vln_tahun - vln_tahun_dibangun) +	(2*10)) / 3);
		  ELSE
  		  	 ------------------------------------------------------------
             -- (jika tahun pajak - tahun renovasi) <= 10
  		  	 ------------------------------------------------------------
			  vln_umur_efektif := ROUND(((vln_tahun - vln_tahun_dibangun) +
								  (2*(vln_tahun - vln_tahun_renovasi))) / 3);
		  END IF;
		ELSE
			------------------------------------------------------------
			-- tahun renovasi kosong
			------------------------------------------------------------
			IF (vln_tahun - vln_tahun_dibangun) > 10 THEN
			   vln_umur_efektif := ROUND(((vln_tahun - vln_tahun_dibangun) + (2*10)) / 3);
			ELSE
				vln_umur_efektif := vln_tahun - vln_tahun_dibangun;
			END IF;
		END IF;

	ELSE
       RETURN 0;
	END IF;
  ELSE
    ------------------------------------------------------------
    -- jika bangunan standart
    ------------------------------------------------------------
    IF vln_tahun_renovasi > 0 THEN
	   vln_umur_efektif := vln_tahun - vln_tahun_renovasi;
	ELSE
	   vln_umur_efektif := vln_tahun - vln_tahun_dibangun;
	END IF;
  END IF;

	IF vln_umur_efektif > 40 THEN
	   vln_umur_efektif := 40;
	END IF;

    ------------------------------------------------------------
	--- mencari biaya pengganti baru / m2
    ------------------------------------------------------------
	IF vln_luas_bng = 0 THEN
	   VLN_LUAS_BANGUNAN := 1;
	ELSE
	   VLN_LUAS_BANGUNAN := vln_luas_bng;
	END IF;

	vln_biaya_pengganti_baru := (NVL(vln_nilai,0) * 1000) / VLN_LUAS_BANGUNAN;

    ------------------------------------------------------------
	--- mencari kode range penyusutan
    ------------------------------------------------------------
	BEGIN
		SELECT kd_range_penyusutan
		INTO   vlc_kd_range_penyusutan
		FROM   range_penyusutan
		WHERE  nilai_min_penyusutan <  vln_biaya_pengganti_baru AND
			   nilai_max_penyusutan >= vln_biaya_pengganti_baru;
	EXCEPTION
		WHEN OTHERS THEN RETURN 0;
	END;

    ------------------------------------------------------------
	--- mencari prosentase penyusutan
    ------------------------------------------------------------
	BEGIN
	 SELECT NVL(nilai_penyusutan, 0)
	 INTO 	vln_persentase_susut
	 FROM 	penyusutan
	 WHERE  umur_efektif        = vln_umur_efektif        AND
	   	    kd_range_penyusutan = vlc_kd_range_penyusutan AND
	   	    kondisi_bng_susut   = vlc_kondisi_bng;
	EXCEPTION
		WHEN OTHERS THEN RETURN 0;
	END;

	RETURN vln_persentase_susut;
END;
