create function cek_kel_sig (v_prop in char, v_dati2 in char, v_kec in char,
v_kel in char)return number is
v_ada number(1);
v_status_peta number(1);
begin
	begin
		select count(*) into v_ada from peta_sig
		where kd_propinsi=v_prop and kd_dati2=v_dati2 and
		kd_kecamatan=v_kec and kd_kelurahan=v_kel;
		exception when others then v_ada:=0;
	end;
	if v_ada = 1 then
	   v_status_peta:=0;
	   else
	   v_status_peta:=1;
	   end if;
	return v_status_peta;
end;
