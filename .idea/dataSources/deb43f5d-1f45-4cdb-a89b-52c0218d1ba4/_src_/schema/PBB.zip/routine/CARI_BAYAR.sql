create PROCEDURE     cari_bayar (vlc_nop IN CHAR, vlc_tahun IN CHAR) IS
	   	  		  			--vln_nilai OUT NUMBER) IS
cursor c_tagihan_sppt IS
  	   SELECT s.status_tagihan_sppt
	   FROM sppt s
	   WHERE s.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 s.kd_dati2 		= substr(vlc_nop,3,2) AND
		     s.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			 s.kd_kelurahan 	= substr(vlc_nop,8,3) AND
			 s.kd_blok 			= substr(vlc_nop,11,3) AND
			 s.no_urut 			= substr(vlc_nop,14,4) AND
			 s.kd_jns_op		= substr(vlc_nop,18,1);

cursor c_tagihan_skp_spop IS
  	   SELECT s.status_tagihan_skp_spop
	   FROM skp_spop s
	   WHERE s.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 s.kd_dati2 		= substr(vlc_nop,3,2) AND
		     s.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			 s.kd_kelurahan		= substr(vlc_nop,8,3) AND
			 s.kd_blok 			= substr(vlc_nop,11,3) AND
			 s.no_urut 			= substr(vlc_nop,14,4) AND
			 s.kd_jns_op 		= substr(vlc_nop,18,1) AND
			 s.thn_pajak_skp_spop 	= vlc_tahun;

cursor c_bayar_sppt IS
	   SELECT  p.jml_sppt_yg_dibayar nilai,
			   p.pembayaran_sppt_ke ke,
			   p.tgl_pembayaran_sppt tgl
	   FROM pembayaran_sppt p
	   WHERE p.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 p.kd_dati2 		= substr(vlc_nop,3,2) AND
		     p.kd_kecamatan  	= substr(vlc_nop,5,3) AND
			 P.kd_kelurahan 	= substr(vlc_nop,8,3) AND
			 p.kd_blok 			= substr(vlc_nop,11,3) AND
			 p.no_urut 			= substr(vlc_nop,14,4) AND
			 p.kd_jns_op 		= substr(vlc_nop,18,1) AND
			 p.thn_pajak_sppt 	= vlc_tahun;

cursor c_bayar_skp_spop IS
	   SELECT  p.jml_skp_spop_yg_dibayar nilai,
			   p.pembayaran_skp_spop_ke ke,
			   p.tgl_pembayaran_skp_spop tgl
	   FROM pembayaran_skp_spop p
	   WHERE p.kd_propinsi 		 	= substr(vlc_nop,1,2) AND
			 p.kd_dati2 			= substr(vlc_nop,3,2) AND
		     p.kd_kecamatan   		= substr(vlc_nop,5,3) AND
			 P.kd_kelurahan 		= substr(vlc_nop,8,3) AND
			 p.kd_blok 				= substr(vlc_nop,11,3) AND
			 p.no_urut 				= substr(vlc_nop,14,4) AND
			 p.kd_jns_op 			= substr(vlc_nop,18,1) AND
			 p.thn_pajak_skp_spop 	= vlc_tahun;

cursor c_bayar_stp IS
	   SELECT p.jml_stp_yg_dibayar nilai,
	   		  p.tgl_pembayaran_stp tgl
	   FROM pembayaran_stp p
	   WHERE p.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 p.kd_dati2 		= substr(vlc_nop,3,2) AND
		     p.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			 P.kd_kelurahan 	= substr(vlc_nop,8,3) AND
			 p.kd_blok 			= substr(vlc_nop,11,3) AND
			 p.no_urut 			= substr(vlc_nop,14,4) AND
			 p.kd_jns_op 		= substr(vlc_nop,18,1);

cursor c_bayar_skp_kb IS
	   SELECT  p.jml_skp_kb_yg_dibayar nilai,
			   p.pembayaran_skp_kb_ke ke,
			   p.tgl_pembayaran_skp_kb tgl
	   FROM pembayaran_skp_kb p
	   WHERE p.kd_propinsi 			= substr(vlc_nop,1,2) AND
			 p.kd_dati2 			= substr(vlc_nop,3,2) AND
		     p.kd_kecamatan   	    = substr(vlc_nop,5,3) AND
			 P.kd_kelurahan 		= substr(vlc_nop,8,3) AND
			 p.kd_blok 				= substr(vlc_nop,11,3) AND
			 p.no_urut 				= substr(vlc_nop,14,4) AND
			 p.kd_jns_op 			= substr(vlc_nop,18,1) AND
			 p.thn_pajak_skp_kb 	= vlc_tahun;


vln_tagihan NUMBER(1);  -- Variabel untuk menentukan tagihan (SPPT atau SKP_SPOP)
vlc_status_tagihan sppt.status_tagihan_sppt%type; -- Variabel untuk menentukan jenis tagihan (SPPT, STP,SKP_KB, SKP_SPOP)
vln_bayar		   pembayaran_sppt.jml_sppt_yg_dibayar%type;
vln_bayar_ke	   pembayaran_sppt.pembayaran_sppt_ke%type;
vld_tanggal 	   pembayaran_sppt.tgl_pembayaran_sppt%type;

BEGIN
   BEGIN
   SELECT count (*)
   INTO vln_tagihan
   FROM skp_spop s
   WHERE s.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 s.kd_dati2 				= substr(vlc_nop,3,2) AND
		     s.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			 s.kd_kelurahan 		= substr(vlc_nop,8,3) AND
			 s.kd_blok 				= substr(vlc_nop,11,3) AND
			 s.no_urut 				= substr(vlc_nop,14,4) AND
			 s.kd_jns_op 			= substr(vlc_nop,18,1) AND
			 s.thn_pajak_skp_spop 	= vlc_tahun;
   EXCEPTION
	   WHEN NO_DATA_FOUND THEN
	   vln_tagihan := 0;
   END;

   IF vln_tagihan >=1 THEN
      OPEN c_tagihan_skp_spop;
	  FETCH c_tagihan_skp_spop INTO vlc_status_tagihan;
	     IF vlc_status_tagihan = '1' THEN
		   -- DBMS_OUTPUT.PUT_LINE('pembayaran SKP_SPOP');
		    BEGIN
			    FOR rec_bayar IN c_bayar_skp_spop LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= rec_bayar.ke;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('pembayaran      ke '|| to_char(vln_bayar_ke));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			 END;
		 ELSIF vlc_status_tagihan = '2' THEN
		  --  DBMS_OUTPUT.PUT_LINE('pembayaran SKP_KB');
		    BEGIN
			    FOR rec_bayar IN c_bayar_skp_kb LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= rec_bayar.ke;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('pembayaran      ke '|| to_char(vln_bayar_ke));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			END;
		 ELSIF vlc_status_tagihan = '4' THEN
		  --  DBMS_OUTPUT.PUT_LINE('pembayaran STP');
			    BEGIN
			    FOR rec_bayar IN c_bayar_stp LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= 0;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			END;
		 ELSE
		    DBMS_OUTPUT.PUT_LINE('Tidak ada status tagihan pada SKP_SPOP');
		 END IF;
	  CLOSE c_tagihan_skp_spop;
   ELSIF vln_tagihan = 0 THEN
      OPEN c_tagihan_sppt;
	  FETCH c_tagihan_sppt INTO vlc_status_tagihan;
	     IF vlc_status_tagihan = '0' THEN
		  --  DBMS_OUTPUT.PUT_LINE('pembayaran SPPT');
		    BEGIN
			    FOR rec_bayar IN c_bayar_sppt LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= rec_bayar.ke;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('pembayaran      ke '|| to_char(vln_bayar_ke));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			END;
		 ELSIF vlc_status_tagihan = '2' THEN
		--    DBMS_OUTPUT.PUT_LINE('pembayaran SKP_KB');
		    BEGIN
			    FOR rec_bayar IN c_bayar_skp_kb LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= rec_bayar.ke;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('pembayaran      ke '|| to_char(vln_bayar_ke));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			END;
		 ELSIF vlc_status_tagihan = '4' THEN
		 --   DBMS_OUTPUT.PUT_LINE('pembayaran STP');
		    BEGIN
			    FOR rec_bayar IN c_bayar_stp LOOP
				 vln_bayar   := rec_bayar.nilai;
				 vln_bayar_ke:= 0;
				 vld_tanggal := rec_bayar.tgl;
				-- DBMS_OUTPUT.PUT_LINE('jumlah  pembayaran '|| to_char(vln_bayar));
				-- DBMS_OUTPUT.PUT_LINE('tanggal pembayaran '|| to_char(vld_tanggal, 'dd-mm-yyyy'));
				END LOOP;
			END;
		 ELSE
		    DBMS_OUTPUT.PUT_LINE('Tidak ada status tagihan pada SPPT');
		 END IF;
	  CLOSE c_tagihan_sppt;

   ELSE
       DBMS_OUTPUT.PUT_LINE('Tidak ada pajak terhutang pada SPPT atau SKP_SPOP');
   END IF;

END cari_bayar;