create function GetTglLunas(v_kd_propinsi char, v_kd_dati2 char, v_kd_kecamatan char, 
  v_kd_kelurahan char, v_kd_blok char, v_no_urut char, v_kd_jns_op char, v_thn_pajak_sppt char) return date
is
  v_tgl_bayar date;
begin
  select tgl_pembayaran_sppt
  into v_tgl_bayar
  from ( select tgl_pembayaran_sppt 
         from pembayaran_sppt
         where kd_propinsi = v_kd_propinsi
           and kd_dati2 = v_kd_dati2
           and kd_kecamatan = v_kd_kecamatan
           and kd_kelurahan = v_kd_kelurahan
           and kd_blok = v_kd_blok
           and no_urut = v_no_urut
           and kd_jns_op = v_kd_jns_op
           and thn_pajak_sppt = v_thn_pajak_sppt
         order by tgl_pembayaran_sppt desc
  ) where rownum = 1;
       
  return v_tgl_bayar;
end;