create FUNCTION tambah(a in number, b in number) return number IS
 BEGIN
   Return a+b;
END;
