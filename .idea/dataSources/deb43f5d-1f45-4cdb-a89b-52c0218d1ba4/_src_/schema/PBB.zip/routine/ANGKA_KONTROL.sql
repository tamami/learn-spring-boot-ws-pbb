create FUNCTION ANGKA_KONTROL(V_NOP CHAR, V_SIKLUS NUMBER, V_TAHUN CHAR) RETURN CHAR IS
  vgi_digit number(6);
  vgs_digit Varchar2(5);
  vgs_siklus varchar2(4);
BEGIN
  vgi_digit := 3 * to_number(substr(v_nop,1,1));
  vgi_digit := vgi_digit + (5 * to_number(substr(v_nop,2,1)));
  vgi_digit := vgi_digit + (7 * to_number(substr(v_nop,3,1)));
  vgi_digit := vgi_digit + (13 * to_number(substr(v_nop,4,1)));
  vgi_digit := vgi_digit + (17 * to_number(substr(v_nop,5,1)));
  vgi_digit := vgi_digit + (19 * to_number(substr(v_nop,6,1)));
  vgi_digit := vgi_digit + (23 * to_number(substr(v_nop,7,1)));
  vgi_digit := vgi_digit + (29 * to_number(substr(v_nop,8,1)));
  vgi_digit := vgi_digit + (31 * to_number(substr(v_nop,9,1)));
  vgi_digit := vgi_digit + (37 * to_number(substr(v_nop,10,1)));
  vgi_digit := vgi_digit + (41 * to_number(substr(v_nop,11,1)));
  vgi_digit := vgi_digit + (43 * to_number(substr(v_nop,12,1)));
  vgi_digit := vgi_digit + (47 * to_number(substr(v_nop,13,1)));
  vgi_digit := vgi_digit + (53 * to_number(substr(v_nop,14,1)));
  vgi_digit := vgi_digit + (59 * to_number(substr(v_nop,15,1)));
  vgi_digit := vgi_digit + (61 * to_number(substr(v_nop,16,1)));
  vgi_digit := vgi_digit + (67 * to_number(substr(v_nop,17,1)));
  vgi_digit := vgi_digit + (71 * to_number(substr(v_tahun,4,1)));

  vgs_siklus := to_char(v_siklus);

  if length(vgs_siklus) = 1 then vgs_siklus := '0'||vgs_siklus;
  elsif length(vgs_siklus) > 1 then vgs_siklus := substr(vgs_siklus,length(vgs_siklus)-1,2);
  end if;

  vgi_digit := vgi_digit + (73 * to_number(substr(vgs_siklus,1,1)));
  vgi_digit := vgi_digit + (79 * to_number(substr(vgs_siklus,2,1)));

  vgi_digit := vgi_digit mod 11;

  vgs_digit := to_char(vgi_digit);
  if length(vgs_digit) > 1 then vgs_digit := substr(vgs_digit,length(vgs_digit),1);
  end if;

  vgs_digit := vgs_siklus||vgs_digit;
  Return vgs_digit;
END;
