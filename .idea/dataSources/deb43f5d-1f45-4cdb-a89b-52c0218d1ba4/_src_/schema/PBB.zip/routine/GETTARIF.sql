create FUNCTION GETTARIF (v_thn CHAR, vli_njop NUMBER) RETURN NUMBER IS
vli_tarif NUMBER(3,3);
BEGIN
    begin
      select nilai_tarif into vli_tarif
      from tarif
      where v_thn between thn_awal and thn_akhir and
      vli_njop between njop_min and njop_max;
    exception when others then vli_tarif:= 100;
    end;
   RETURN VLI_TARIF;
END GETTARIF; 