create FUNCTION FMT_BLN (vlc_bln IN CHAR) RETURN CHAR  IS
vlc_bulan VARCHAR2(10);
BEGIN
 IF vlc_bln = '01' THEN
 	vlc_bulan := 'JANUARI';
 ELSIF vlc_bln = '02' THEN
 	vlc_bulan := 'PEBRUARI';
 ELSIF vlc_bln = '03' THEN
 	vlc_bulan := 'MARET';
 ELSIF vlc_bln = '04' THEN
 	vlc_bulan := 'APRIL';
 ELSIF vlc_bln = '05' THEN
 	vlc_bulan := 'MEI';
 ELSIF vlc_bln = '06' THEN
 	vlc_bulan := 'JUNI';
 ELSIF vlc_bln = '07' THEN
 	vlc_bulan := 'JULI';
 ELSIF vlc_bln = '08' THEN
 	vlc_bulan := 'AGUSTUS';
 ELSIF vlc_bln = '09' THEN
 	vlc_bulan := 'SEPTEMBER';
 ELSIF vlc_bln = '10' THEN
 	vlc_bulan := 'OKTOBER';
 ELSIF vlc_bln = '11' THEN
 	vlc_bulan := 'NOVEMBER';
 ELSIF vlc_bln = '12' THEN
 	vlc_bulan := 'DESEMBER';
 END IF;
 RETURN (vlc_bulan);
END;
