create function coding_sppt(v_prop char, v_dat char, v_kec char,
v_kel char, v_blok char, v_urut char, v_jns char, v_tahun char, v_kwil char,
v_kppbb char, v_wp_nama varchar2, v_hrsbyr number, v_kdsal varchar2)
return char is
 vls_znt char(2);
 vls_nir varchar2(13);
 vls_jptb char(2);
 v_c1  char(1);
 v_c2  char(12);
 v_c3  char(1);
 v_c4  char(1);
 v_c5  char(1);
 v_c6  char(1);
 v_c7  char(1);
 v_c8  char(1);
 v_c9  char(1);
 v_c10 varchar(2);
 v_c11 char(2);
 v_c12 char(2);
 v_pbb_hrsbyr varchar2(15);
begin
  begin
    Select kd_znt into vls_znt from dat_op_bumi
	Where kd_propinsi = v_prop and
	  kd_dati2 = v_dat and
	  kd_kecamatan = v_kec and
	  kd_kelurahan = v_kel and
	  kd_blok = v_blok and
	  no_urut = v_urut and
	  kd_jns_op = v_jns;
  exception when others then null;
  end;

  -- cari kode ZNT
  begin
    Select to_char(nir) into vls_nir from dat_nir
	Where kd_propinsi = v_prop and
	  kd_dati2 = v_dat and
	  kd_kecamatan = v_kec and
	  kd_kelurahan = v_kel and
	  kd_znt = vls_znt and
	  thn_nir_znt = v_tahun and
	  kd_kanwil = v_kwil and
	  kd_kppbb = v_kppbb;
  exception when others then null;
  end;

  -- cari NIR
  begin
    Select kd_jpb into vls_jptb from dat_op_bangunan
	Where kd_propinsi = v_prop and
	  kd_dati2 = v_dat and
	  kd_kecamatan = v_kec and
	  kd_kelurahan = v_kel and
	  kd_blok = v_blok and
	  no_urut = v_urut and
	  kd_jns_op = v_jns and
	  no_bng = 1;
  exception when no_data_found then
    begin
      Select '0'||jns_bumi into vls_jptb from dat_op_bumi
	  Where kd_propinsi = v_prop and
	    kd_dati2 = v_dat and
	    kd_kecamatan = v_kec and
	    kd_kelurahan = v_kel and
	    kd_blok = v_blok and
	    no_urut = v_urut and
	    kd_jns_op = v_jns and
	    no_bumi = 1;
    exception when others then null;
    end;
  end;

  -- coding
  v_pbb_hrsbyr := to_char(v_hrsbyr);
  v_c1 := substr(vls_nir,1,1);
  v_c2 := to_char(sysdate,'ddmmyyhhmiss');
  v_c3 := substr(v_pbb_hrsbyr,1,1);
  v_c4 := substr(v_wp_nama,1,1);
  v_c5 := substr(vls_znt,1,1);
  v_c6 := substr(v_wp_nama,length(v_wp_nama),1);
  v_c7 := to_char(abs(length(abs(v_pbb_hrsbyr)) - 3));
  v_c8 := substr(vls_znt,2,1);
  v_c9 := to_char(length(vls_nir));
  v_c10:= to_char(length(v_pbb_hrsbyr));
  v_c11:= vls_jptb;
  v_c12:= v_kdsal;
  Return v_c1||v_c2||v_c3||v_c4||v_c5||v_c6||v_c7||v_c8||v_c9||v_c10||v_c11||v_c12;
end;
