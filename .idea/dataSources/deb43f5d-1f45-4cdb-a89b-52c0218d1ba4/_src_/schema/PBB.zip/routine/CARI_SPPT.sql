create PROCEDURE cari_sppt (vlc_nop IN CHAR, vlc_tahun IN CHAR,
	   	  		  			vln_nilai OUT NUMBER) IS
cursor c_bayar IS
	   SELECT p.JML_SPPT_YG_DIBAYAR nilai, pembayaran_sppt_ke ke
	   FROM pembayaran_sppt p
	   WHERE p.kd_propinsi 		= substr(vlc_nop,1,2) AND
			 p.kd_dati2 				= substr(vlc_nop,3,2) AND
		     p.kd_kecamatan   	= substr(vlc_nop,5,3) AND
			 P.kd_kelurahan 		= substr(vlc_nop,8,3) AND
			 p.kd_blok 				= substr(vlc_nop,11,3) AND
			 p.no_urut 				= substr(vlc_nop,14,4) AND
			 p.kd_jns_op 			= substr(vlc_nop,18,1) AND
			 p.thn_pajak_sppt 	= vlc_tahun;
BEGIN
FOR i  IN c_bayar LOOP
   vln_nilai := i.nilai;
 -- DBMS_OUTPUT.PUT_LINE('Pembayaran    Ke  '|| to_char(i.ke));
 --  DBMS_OUTPUT.PUT_LINE('Jumlah Pembayaran  '|| to_char(vln_nilai));

END LOOP;

END cari_sppt;
