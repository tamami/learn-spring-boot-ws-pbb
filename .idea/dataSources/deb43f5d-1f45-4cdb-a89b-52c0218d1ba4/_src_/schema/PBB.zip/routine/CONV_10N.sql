create function conv_10n
(v_input IN NUMBER, v_panjang IN NUMBER, v_base IN NUMBER) RETURN CHAR IS
v_error_code NUMBER;
v_error_text VARCHAR2(200);
v_sisa   NUMBER := 0;
v_input1 NUMBER := v_input;
v_digmax NUMBER := 0;
v_loop   NUMBER := 0;
v_temp   VARCHAR2(50):= ' ';
v_temp1  VARCHAR2(50);
v_hasil  VARCHAR2(10);

BEGIN
   IF v_base > 69 OR v_base < 1 THEN
      SELECT lpad('', v_panjang, '*')
	  INTO v_temp FROM DUAL;
	  v_hasil := v_temp;
   END IF;

   IF v_input1 > 999999 THEN
      SELECT lpad('', v_panjang, '*')
	  INTO v_temp FROM DUAL;
	  v_hasil := v_temp;
   END IF;

   v_sisa := v_input1;

   LOOP
      v_sisa := v_input1 - power(v_base, v_digmax);
	  IF v_sisa > 0 THEN
	     v_digmax := v_digmax + 1 ;
	  ELSIF v_sisa = 0 THEN
	     EXIT;
	  ELSE
	     v_digmax := v_digmax - 1;
	     EXIT;
	  END IF;
	END LOOP;

   -- Periksa panjang keluran
   IF v_digmax >= v_panjang THEN
      SELECT lpad('', v_panjang, '*')
	  INTO v_temp FROM DUAL;
	  v_hasil := v_temp;
   END IF;

   WHILE v_digmax >  0 LOOP
      v_loop   := 0;
	   v_sisa  := v_input1 ;
	  LOOP
	     v_sisa := v_input1 - (v_loop * (power(v_base, v_digmax)));
		 IF v_sisa > 0  THEN
		    v_loop := v_loop + 1;
		 ELSIF v_sisa = 0 THEN
		    EXIT;
		 ELSE
		    v_loop := v_loop - 1;
		    EXIT;
		 END IF;

	 END LOOP;

	 IF v_loop < 10 THEN
	     v_temp1 := ltrim(rtrim(to_char(v_loop)));
	 ELSE
	   BEGIN
		 SELECT bilangan_62
			INTO v_temp1
			 FROM konversi_desimal
			 WHERE  bilangan_10 = to_char(v_loop);
		END;
	 END IF;

	v_temp := v_temp || v_temp1;
	v_input1 := to_number(to_char(v_input1 - v_loop * power(v_base, v_digmax)));
	v_digmax := v_digmax - 1;

  END LOOP;

	IF v_input1  < 10 THEN
	    v_temp1 := ltrim(rtrim(to_char(v_input1)));
	 ELSE
	   BEGIN
	     SELECT bilangan_62
		 INTO v_temp1
		 FROM konversi_desimal
		 WHERE  bilangan_10 =  to_char(v_input1);
	   END;
	 END IF;

    v_temp  := (ltrim(rtrim(v_temp))||ltrim(rtrim(v_temp1))) ;
	v_hasil := lpad(v_temp, v_panjang, '0');

 RETURN (v_hasil);

 EXCEPTION
    WHEN OTHERS THEN
	    v_error_code := SQLCODE;
		v_error_text := substr(SQLERRM, 1, 200);
		dbms_output.put_line(v_error_text);
END ;
